import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ArrowLeft, Gamepad2, Shield, Zap, MapPin, Mail, User, MessageCircle, Crown, Star, Users, TrendingUp, Calculator } from 'lucide-react';
import { UserData } from '../App';

interface SignUpPageProps {
  userData: UserData;
  onUserDataUpdate: (data: Partial<UserData>) => void;
  onNext: () => void;
  onBack: () => void;
}

export default function SignUpPage({ userData, onUserDataUpdate, onNext, onBack }: SignUpPageProps) {
  const [formData, setFormData] = useState({
    ...userData,
    socialPlatform: '',
    followerCount: '',
    estimatedEarnings: 0
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  const calculateEarnings = (followers: string, platform: string) => {
    const count = parseInt(followers) || 0;
    let baseRate = 20;
    let bonusRate = 0.02;
    let platformMultiplier = 1;

    // Platform multipliers
    switch(platform) {
      case 'tiktok':
        platformMultiplier = 1.2;
        break;
      case 'instagram':
        platformMultiplier = 1.1;
        break;
      case 'youtube':
        platformMultiplier = 1.3;
        break;
      case 'twitch':
        platformMultiplier = 1.25;
        break;
      default:
        platformMultiplier = 1;
    }

    // Tier calculation
    if (count >= 200000) {
      baseRate = 100;
      bonusRate = 0.12;
    } else if (count >= 50000) {
      baseRate = 60;
      bonusRate = 0.08;
    } else if (count >= 10000) {
      baseRate = 35;
      bonusRate = 0.05;
    }

    const followerBonus = count * bonusRate;
    const totalEarnings = (baseRate + followerBonus) * platformMultiplier;
    
    return Math.round(totalEarnings);
  };

  const handleInputChange = (field: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = field === 'agreedToTerms' ? (e.target as HTMLInputElement).checked : e.target.value;
    const newFormData = { ...formData, [field]: value };
    
    // Recalculate earnings when follower count or platform changes
    if (field === 'followerCount' || field === 'socialPlatform') {
      newFormData.estimatedEarnings = calculateEarnings(
        field === 'followerCount' ? value as string : formData.followerCount,
        field === 'socialPlatform' ? value as string : formData.socialPlatform
      );
    }
    
    setFormData(newFormData);
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handlePlatformChange = (value: string) => {
    const newFormData = { ...formData, socialPlatform: value };
    newFormData.estimatedEarnings = calculateEarnings(formData.followerCount, value);
    setFormData(newFormData);
    if (errors.socialPlatform) {
      setErrors(prev => ({ ...prev, socialPlatform: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }

    if (!formData.age || parseInt(formData.age) < 18) {
      newErrors.age = 'You must be 18 or older to participate';
    } else if (parseInt(formData.age) > 99) {
      newErrors.age = 'Please enter a valid age';
    }

    if (!formData.location.trim()) {
      newErrors.location = 'Location is required';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.agreedToTerms) {
      newErrors.agreedToTerms = 'You must accept the terms and conditions';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      setIsLoading(true);
      await new Promise(resolve => setTimeout(resolve, 1500));
      onUserDataUpdate(formData);
      onNext();
      setIsLoading(false);
    }
  };

  const getTierInfo = () => {
    const followers = parseInt(formData.followerCount) || 0;
    if (followers >= 200000) return { tier: 'Diamond Elite', icon: '💎', color: 'from-purple-500 to-pink-600' };
    if (followers >= 50000) return { tier: 'Gold Creator', icon: '🥇', color: 'from-yellow-500 to-orange-600' };
    if (followers >= 10000) return { tier: 'Rising Star', icon: '⭐', color: 'from-blue-500 to-cyan-600' };
    return { tier: 'Starter', icon: '🥉', color: 'from-gray-500 to-slate-600' };
  };

  const tierInfo = getTierInfo();

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Enhanced Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20"></div>
        
        {/* Animated particles */}
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.7}s`,
              animationDuration: `${8 + Math.random() * 4}s`
            }}
          >
            <div className="w-3 h-3 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-40 blur-sm"></div>
          </div>
        ))}

        {/* Floating gaming elements */}
        <div className="absolute top-20 right-10 text-6xl animate-bounce delay-100 opacity-30">🎰</div>
        <div className="absolute bottom-32 left-10 text-7xl animate-pulse delay-300 opacity-30">💰</div>
        <div className="absolute top-60 left-20 text-5xl animate-bounce delay-500 opacity-30">🎮</div>
        <div className="absolute bottom-60 right-20 text-4xl animate-pulse delay-700 opacity-30">👑</div>
      </div>

      {/* Header */}
      <header className="relative z-10 p-4 lg:p-6 mb-6 lg:mb-8">
        <Button
          variant="ghost"
          onClick={onBack}
          className="text-white hover:text-purple-400 hover:bg-purple-500/10 mb-4 lg:mb-6 text-lg group"
        >
          <ArrowLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform" />
          Back to Home
        </Button>
        
        <div className="text-center">
          <div className="flex items-center justify-center space-x-4 mb-3">
            <span className="text-4xl lg:text-5xl animate-pulse">🎮</span>
            <div className="text-3xl lg:text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              UGC Creators
            </div>
          </div>
          <div className="text-sm text-gray-300 uppercase tracking-wider">Performance-Based Gaming Platform • UK's #1</div>
        </div>
      </header>

      {/* Enhanced Progress Indicator */}
      <div className="relative z-10 max-w-2xl mx-auto px-4 lg:px-6 mb-8 lg:mb-12">
        <div className="flex items-center justify-center space-x-4 mb-6">
          <div className="flex items-center">
            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold shadow-lg">
              1
            </div>
            <div className="text-white ml-3 font-semibold text-sm lg:text-base">Registration</div>
          </div>
          <div className="w-12 lg:w-16 h-1 bg-gradient-to-r from-purple-500 to-transparent rounded-full"></div>
          <div className="flex items-center">
            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-gray-700 rounded-full flex items-center justify-center text-gray-400 font-bold">
              2
            </div>
            <div className="text-gray-400 ml-3 text-sm lg:text-base">Character</div>
          </div>
          <div className="w-12 lg:w-16 h-1 bg-gray-700 rounded-full"></div>
          <div className="flex items-center">
            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-gray-700 rounded-full flex items-center justify-center text-gray-400 font-bold">
              3
            </div>
            <div className="text-gray-400 ml-3 text-sm lg:text-base">Content</div>
          </div>
        </div>
        <div className="w-full bg-gray-800 rounded-full h-3 shadow-inner">
          <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-3 rounded-full w-1/3 transition-all duration-500 shadow-lg"></div>
        </div>
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 lg:px-6">
        <div className="grid lg:grid-cols-3 gap-6 lg:gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2">
            <Card className="bg-gradient-to-br from-purple-900/40 to-pink-900/30 border-purple-500/30 backdrop-blur-xl shadow-2xl">
              <CardHeader className="text-center pb-6 lg:pb-8">
                <div className="flex justify-center mb-6">
                  <div className="relative">
                    <div className="w-16 h-16 lg:w-20 lg:h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-3xl lg:text-4xl shadow-2xl">
                      🎮
                    </div>
                    <Badge className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-2 py-1 animate-pulse">
                      LIVE
                    </Badge>
                    <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2">
                      <Crown className="w-6 h-6 lg:w-8 lg:h-8 text-yellow-400" />
                    </div>
                  </div>
                </div>
                
                <CardTitle className="text-2xl lg:text-3xl text-white mb-3">Create Your Creator Account!</CardTitle>
                <p className="text-gray-400 text-lg">Join the performance-based gaming revolution</p>
              </CardHeader>
              
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Basic Info */}
                  <div className="grid md:grid-cols-2 gap-4 lg:gap-6">
                    <div>
                      <Label htmlFor="fullName" className="text-white flex items-center text-base lg:text-lg mb-3">
                        <User className="w-5 h-5 mr-3 text-purple-400" />
                        Full Name
                      </Label>
                      <Input
                        id="fullName"
                        type="text"
                        value={formData.fullName}
                        onChange={handleInputChange('fullName')}
                        className="bg-black/60 border-purple-500/40 text-white placeholder:text-gray-400 text-base lg:text-lg py-3 lg:py-4 rounded-xl backdrop-blur-sm"
                        placeholder="Your real name"
                      />
                      {errors.fullName && (
                        <p className="text-pink-400 text-sm mt-2 flex items-center">
                          <Zap className="w-4 h-4 mr-1" />
                          {errors.fullName}
                        </p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="age" className="text-white flex items-center text-base lg:text-lg mb-3">
                        <Shield className="w-5 h-5 mr-3 text-green-400" />
                        Age
                      </Label>
                      <Input
                        id="age"
                        type="number"
                        value={formData.age}
                        onChange={handleInputChange('age')}
                        className="bg-black/60 border-purple-500/40 text-white placeholder:text-gray-400 text-base lg:text-lg py-3 lg:py-4 rounded-xl backdrop-blur-sm"
                        placeholder="18+"
                        min="18"
                        max="99"
                      />
                      {errors.age && (
                        <p className="text-pink-400 text-sm mt-2 flex items-center">
                          <Zap className="w-4 h-4 mr-1" />
                          {errors.age}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 lg:gap-6">
                    <div>
                      <Label htmlFor="location" className="text-white flex items-center text-base lg:text-lg mb-3">
                        <MapPin className="w-5 h-5 mr-3 text-blue-400" />
                        Location
                      </Label>
                      <Input
                        id="location"
                        type="text"
                        value={formData.location}
                        onChange={handleInputChange('location')}
                        className="bg-black/60 border-purple-500/40 text-white placeholder:text-gray-400 text-base lg:text-lg py-3 lg:py-4 rounded-xl backdrop-blur-sm"
                        placeholder="London, UK"
                      />
                      {errors.location && (
                        <p className="text-pink-400 text-sm mt-2 flex items-center">
                          <Zap className="w-4 h-4 mr-1" />
                          {errors.location}
                        </p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="email" className="text-white flex items-center text-base lg:text-lg mb-3">
                        <Mail className="w-5 h-5 mr-3 text-yellow-400" />
                        Email Address
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange('email')}
                        className="bg-black/60 border-purple-500/40 text-white placeholder:text-gray-400 text-base lg:text-lg py-3 lg:py-4 rounded-xl backdrop-blur-sm"
                        placeholder="your.email@example.com"
                      />
                      {errors.email && (
                        <p className="text-pink-400 text-sm mt-2 flex items-center">
                          <Zap className="w-4 h-4 mr-1" />
                          {errors.email}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Social Media Performance Section */}
                  <div className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 border border-blue-400/30 rounded-xl p-6 backdrop-blur-sm">
                    <h3 className="text-xl lg:text-2xl font-bold text-blue-400 mb-4 flex items-center">
                      <TrendingUp className="w-6 h-6 mr-3" />
                      Social Media for Performance Tracking
                    </h3>
                    
                    <div className="grid md:grid-cols-2 gap-4 lg:gap-6">
                      <div>
                        <Label className="text-white flex items-center text-base lg:text-lg mb-3">
                          <Gamepad2 className="w-5 h-5 mr-3 text-purple-400" />
                          Primary Platform
                        </Label>
                        <Select onValueChange={handlePlatformChange} value={formData.socialPlatform}>
                          <SelectTrigger className="bg-black/60 border-purple-500/40 text-white text-base lg:text-lg py-3 lg:py-4 rounded-xl backdrop-blur-sm">
                            <SelectValue placeholder="Select your main platform" />
                          </SelectTrigger>
                          <SelectContent className="bg-black border-purple-500/40 text-white">
                            <SelectItem value="tiktok">TikTok (1.2x multiplier)</SelectItem>
                            <SelectItem value="instagram">Instagram (1.1x multiplier)</SelectItem>
                            <SelectItem value="youtube">YouTube (1.3x multiplier)</SelectItem>
                            <SelectItem value="twitch">Twitch (1.25x multiplier)</SelectItem>
                            <SelectItem value="other">Other platform</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="followerCount" className="text-white flex items-center text-base lg:text-lg mb-3">
                          <Users className="w-5 h-5 mr-3 text-green-400" />
                          Follower Count
                        </Label>
                        <Input
                          id="followerCount"
                          type="number"
                          value={formData.followerCount}
                          onChange={handleInputChange('followerCount')}
                          className="bg-black/60 border-purple-500/40 text-white placeholder:text-gray-400 text-base lg:text-lg py-3 lg:py-4 rounded-xl backdrop-blur-sm"
                          placeholder="Enter your follower count"
                          min="0"
                        />
                      </div>
                    </div>

                    <div className="mt-4">
                      <Label htmlFor="socialHandle" className="text-white flex items-center text-base lg:text-lg mb-3">
                        <Star className="w-5 h-5 mr-3 text-purple-400" />
                        Social Handle (Optional)
                      </Label>
                      <Input
                        id="socialHandle"
                        type="text"
                        value={formData.socialHandle || ''}
                        onChange={handleInputChange('socialHandle')}
                        className="bg-black/60 border-purple-500/40 text-white placeholder:text-gray-400 text-base lg:text-lg py-3 lg:py-4 rounded-xl backdrop-blur-sm"
                        placeholder="@your_gaming_username"
                      />
                      <p className="text-xs text-gray-500 mt-2 flex items-center">
                        <Star className="w-3 h-3 mr-1" />
                        This helps us verify your follower count for accurate earnings calculation
                      </p>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="whatsappDiscord" className="text-white flex items-center text-base lg:text-lg mb-3">
                      <MessageCircle className="w-5 h-5 mr-3 text-green-400" />
                      WhatsApp or Discord (Optional)
                    </Label>
                    <Input
                      id="whatsappDiscord"
                      type="text"
                      value={formData.whatsappDiscord || ''}
                      onChange={handleInputChange('whatsappDiscord')}
                      className="bg-black/60 border-purple-500/40 text-white placeholder:text-gray-400 text-base lg:text-lg py-3 lg:py-4 rounded-xl backdrop-blur-sm"
                      placeholder="+44 7XXX XXXXXX"
                    />
                    <p className="text-xs text-gray-500 mt-2 flex items-center">
                      <Zap className="w-3 h-3 mr-1" />
                      For instant updates about payments, performance bonuses, and new opportunities
                    </p>
                  </div>

                  <div className="flex items-start space-x-4 pt-4">
                    <Checkbox
                      id="terms"
                      checked={formData.agreedToTerms}
                      onCheckedChange={(checked) => 
                        setFormData(prev => ({ ...prev, agreedToTerms: checked as boolean }))
                      }
                      className="border-purple-500/50 data-[state=checked]:bg-purple-500 mt-1 w-5 h-5"
                    />
                    <Label htmlFor="terms" className="text-sm text-gray-300 leading-relaxed">
                      I accept the{' '}
                      <a href="#" className="text-purple-400 hover:text-purple-300 underline font-medium">
                        terms & conditions
                      </a>{' '}
                      and confirm I'm 18+ years old to participate in performance-based gaming content creation. 
                      I understand this involves promoting gambling platforms and my earnings are based on my social media performance.
                    </Label>
                  </div>
                  {errors.agreedToTerms && (
                    <p className="text-pink-400 text-sm flex items-center">
                      <Zap className="w-4 h-4 mr-1" />
                      {errors.agreedToTerms}
                    </p>
                  )}

                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500 hover:from-purple-600 hover:via-pink-600 hover:to-yellow-600 text-white py-6 lg:py-8 text-xl lg:text-2xl rounded-xl shadow-2xl shadow-purple-500/30 transform transition-all hover:scale-105 disabled:opacity-50 disabled:transform-none mt-8 relative overflow-hidden group"
                  >
                    {isLoading ? (
                      <>
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white mr-3"></div>
                        Creating Your Performance Account...
                      </>
                    ) : (
                      <>
                        <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 to-pink-400/20 animate-pulse"></div>
                        <Zap className="w-6 h-6 mr-3 relative z-10" />
                        <span className="relative z-10">Next: Get My Gaming Character</span>
                      </>
                    )}
                  </Button>

                  {/* Enhanced trust indicators */}
                  <div className="flex items-center justify-center space-x-4 lg:space-x-6 pt-6 text-sm text-gray-400">
                    <div className="flex items-center">
                      <Shield className="w-4 h-4 mr-2 text-green-400" />
                      256-bit SSL
                    </div>
                    <span>•</span>
                    <div className="flex items-center">
                      <span className="text-green-400">✓</span>
                      <span className="ml-1">GDPR Compliant</span>
                    </div>
                    <span>•</span>
                    <div className="flex items-center">
                      🇬🇧 UK Based
                    </div>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Earnings Calculator Sidebar */}
          <div className="space-y-6">
            {/* Earnings Preview */}
            <Card className="bg-gradient-to-br from-green-900/50 to-emerald-900/40 border-green-500/30 backdrop-blur-sm sticky top-6">
              <CardContent className="p-6 lg:p-8">
                <h3 className="text-xl lg:text-2xl font-bold text-green-400 mb-6 flex items-center">
                  <Calculator className="w-6 h-6 mr-3" />
                  Your Earnings Preview
                </h3>
                
                {formData.followerCount ? (
                  <>
                    <div className="text-center mb-6">
                      <div className="text-4xl lg:text-5xl font-bold text-white mb-2">
                        £{formData.estimatedEarnings}
                      </div>
                      <div className="text-green-400 text-base lg:text-lg">per video</div>
                    </div>

                    <div className="space-y-4">
                      <div className={`bg-gradient-to-r ${tierInfo.color} bg-opacity-20 border border-opacity-30 rounded-lg p-4 text-center`}>
                        <div className="text-3xl mb-2">{tierInfo.icon}</div>
                        <div className="text-white font-bold">{tierInfo.tier}</div>
                        <div className="text-sm text-gray-300">{parseInt(formData.followerCount).toLocaleString()} followers</div>
                      </div>

                      {formData.socialPlatform && (
                        <div className="bg-blue-900/30 border border-blue-400/30 rounded-lg p-4">
                          <div className="text-blue-400 font-semibold mb-2">Platform Bonus</div>
                          <div className="text-white">
                            {formData.socialPlatform === 'youtube' && '🎥 YouTube: 1.3x multiplier'}
                            {formData.socialPlatform === 'twitch' && '🎮 Twitch: 1.25x multiplier'}
                            {formData.socialPlatform === 'tiktok' && '📱 TikTok: 1.2x multiplier'}
                            {formData.socialPlatform === 'instagram' && '📸 Instagram: 1.1x multiplier'}
                            {formData.socialPlatform === 'other' && '🌟 Other: 1.0x multiplier'}
                          </div>
                        </div>
                      )}

                      <div className="text-sm text-gray-400 space-y-2">
                        <div>💰 Base rate: £20-£100</div>
                        <div>📈 Follower bonus: £0.02-£0.12 each</div>
                        <div>🎁 Platform multiplier applied</div>
                        <div>🔥 Plus promo code commissions!</div>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <div className="text-6xl mb-4">📊</div>
                    <div className="text-gray-400 mb-4">Enter your follower count to see your potential earnings!</div>
                    <div className="text-sm text-gray-500">The more followers, the more you earn</div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Why Join */}
            <Card className="bg-gradient-to-r from-gray-900/60 to-gray-800/40 border-gray-600/30 backdrop-blur-sm">
              <CardContent className="p-6">
                <h3 className="text-white font-semibold mb-4 flex items-center">
                  <Crown className="w-5 h-5 mr-2 text-yellow-400" />
                  Why Join UGC Creators?
                </h3>
                <div className="space-y-3 text-sm">
                  <div className="text-green-400">✓ Performance-based earnings</div>
                  <div className="text-blue-400">✓ Personal promo codes</div>
                  <div className="text-purple-400">✓ No earnings ceiling</div>
                  <div className="text-pink-400">✓ 24/7 creator support</div>
                  <div className="text-yellow-400">✓ Real-time analytics</div>
                  <div className="text-green-400">✓ Fastest payouts in UK</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Custom animations */}
      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-15px) rotate(180deg); }
        }
        
        .animate-float {
          animation: float 8s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}