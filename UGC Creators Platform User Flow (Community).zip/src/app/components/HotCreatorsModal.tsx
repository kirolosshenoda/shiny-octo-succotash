import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Users, DollarSign, Trophy, TrendingUp, Star, Crown, Target, Zap, X } from 'lucide-react';
import { Button } from './ui/button';

interface HotCreatorsModalProps {
  children: React.ReactNode;
}

export default function HotCreatorsModal({ children }: HotCreatorsModalProps) {
  const topCreators = [
    {
      rank: 1,
      name: "CasinoKing_Alex",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
      location: "London",
      followers: "892K",
      totalEarnings: "£47,650",
      monthlyEarnings: "£8,920",
      conversionRate: "12.4%",
      speciality: "High Stakes Casino",
      promoCode: "ALEX20",
      codeUses: 15420,
      badgeColor: "from-yellow-500 to-orange-500",
      crownIcon: true
    },
    {
      rank: 2,
      name: "SlotQueen_Bella",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
      location: "Manchester",
      followers: "756K",
      totalEarnings: "£41,230",
      monthlyEarnings: "£7,680",
      conversionRate: "11.8%",
      speciality: "Progressive Slots",
      promoCode: "BELLA15",
      codeUses: 12890,
      badgeColor: "from-gray-400 to-gray-600"
    },
    {
      rank: 3,
      name: "LuckyLads_Tom",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
      location: "Birmingham",
      followers: "634K",
      totalEarnings: "£38,910",
      monthlyEarnings: "£6,540",
      conversionRate: "10.9%",
      speciality: "Sports Betting",
      promoCode: "TOM25",
      codeUses: 11250,
      badgeColor: "from-amber-600 to-orange-700"
    },
    {
      rank: 4,
      name: "RoyalFlush_Emma",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
      location: "Edinburgh",
      followers: "589K",
      totalEarnings: "£35,670",
      monthlyEarnings: "£5,890",
      conversionRate: "9.7%",
      speciality: "Live Poker",
      promoCode: "EMMA30",
      codeUses: 9870,
      badgeColor: "from-slate-400 to-slate-600"
    },
    {
      rank: 5,
      name: "BigWins_Charlie",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
      location: "Bristol",
      followers: "523K",
      totalEarnings: "£32,450",
      monthlyEarnings: "£5,120",
      conversionRate: "9.2%",
      speciality: "Blackjack Pro",
      promoCode: "CHARLIE10",
      codeUses: 8640,
      badgeColor: "from-stone-400 to-stone-600"
    }
  ];

  return (
    <Dialog>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-[95vw] sm:max-w-[90vw] md:max-w-4xl lg:max-w-6xl max-h-[95vh] bg-gradient-to-br from-black via-purple-950/50 to-pink-950/30 border-purple-500/30 text-white p-0 overflow-hidden">
        <ScrollArea className="max-h-[95vh]">
          <div className="p-4 sm:p-6 lg:p-8">
            <DialogHeader className="mb-6">
              <DialogTitle className="text-2xl sm:text-3xl lg:text-4xl font-bold text-center">
                <div className="flex items-center justify-center space-x-3">
                  <div className="text-3xl sm:text-4xl animate-bounce">🔥</div>
                  <span className="bg-gradient-to-r from-orange-400 via-red-400 to-pink-400 bg-clip-text text-transparent">
                    HOTTEST CREATORS
                  </span>
                  <div className="text-3xl sm:text-4xl animate-bounce">🔥</div>
                </div>
              </DialogTitle>
              <p className="text-center text-gray-400 text-base sm:text-lg lg:text-xl mt-4">
                The UK's top 5 gaming creators by performance & earnings
              </p>
            </DialogHeader>

            <div className="space-y-4 lg:space-y-6">
              {topCreators.map((creator, index) => (
                <Card key={creator.rank} className={`bg-gradient-to-r from-purple-900/50 to-pink-900/40 border-purple-500/40 backdrop-blur-sm hover:scale-[1.02] transition-all duration-300 relative overflow-hidden ${
                  creator.rank === 1 ? 'ring-2 ring-yellow-400/50 shadow-2xl shadow-yellow-400/20' : ''
                }`}>
                  {creator.rank === 1 && (
                    <div className="absolute top-0 right-0 bg-gradient-to-l from-yellow-500 to-orange-500 text-black px-3 py-1 text-xs sm:text-sm font-bold">
                      👑 #1 CREATOR
                    </div>
                  )}
                  
                  <CardContent className="p-4 sm:p-6 lg:p-8">
                    <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 mb-4 lg:mb-6">
                      {/* Rank & Avatar Section */}
                      <div className="flex items-center gap-4 sm:gap-6 flex-shrink-0">
                        {/* Rank Badge */}
                        <div className={`w-12 h-12 sm:w-14 sm:h-14 lg:w-16 lg:h-16 rounded-full bg-gradient-to-r ${creator.badgeColor} flex items-center justify-center text-lg sm:text-xl lg:text-2xl font-bold text-white shadow-lg flex-shrink-0`}>
                          {creator.rank === 1 && creator.crownIcon ? (
                            <Crown className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8" />
                          ) : (
                            `#${creator.rank}`
                          )}
                        </div>
                        
                        {/* Creator Avatar */}
                        <div className="relative flex-shrink-0">
                          <ImageWithFallback
                            src={creator.avatar}
                            alt={creator.name}
                            className="w-16 h-16 sm:w-18 sm:h-18 lg:w-20 lg:h-20 rounded-full object-cover border-3 border-purple-400 shadow-xl"
                          />
                          {creator.rank <= 3 && (
                            <div className="absolute -top-2 -right-2">
                              <Trophy className={`w-5 h-5 sm:w-6 sm:h-6 ${
                                creator.rank === 1 ? 'text-yellow-400' : 
                                creator.rank === 2 ? 'text-gray-400' : 'text-amber-600'
                              }`} />
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Creator Info */}
                      <div className="flex-grow text-center sm:text-left">
                        <h3 className="text-lg sm:text-xl lg:text-2xl font-bold text-white mb-2">{creator.name}</h3>
                        <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 sm:gap-4 text-gray-400 mb-2 text-sm lg:text-base">
                          <span>📍 {creator.location}</span>
                          <span className="flex items-center">
                            <Users className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                            {creator.followers}
                          </span>
                        </div>
                        <Badge className="bg-blue-500/20 text-blue-300 border-blue-400/30 text-xs sm:text-sm">
                          {creator.speciality}
                        </Badge>
                      </div>

                      {/* Earnings Display */}
                      <div className="text-center flex-shrink-0">
                        <div className="text-2xl sm:text-3xl lg:text-4xl font-bold text-green-400 mb-1">
                          {creator.totalEarnings}
                        </div>
                        <div className="text-xs sm:text-sm text-gray-400 mb-2">total earnings</div>
                        <div className="text-sm sm:text-base lg:text-lg font-semibold text-yellow-400">
                          {creator.monthlyEarnings}/month
                        </div>
                      </div>
                    </div>

                    {/* Stats Grid - Responsive */}
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3 lg:gap-4 mb-4 lg:mb-6">
                      <div className="bg-black/30 rounded-lg p-2 sm:p-3 text-center">
                        <Target className="w-4 h-4 sm:w-5 sm:h-5 mx-auto mb-1 text-green-400" />
                        <div className="text-sm sm:text-base lg:text-lg font-bold text-green-400">{creator.conversionRate}</div>
                        <div className="text-xs text-gray-400">Conversion</div>
                      </div>
                      
                      <div className="bg-black/30 rounded-lg p-2 sm:p-3 text-center">
                        <Star className="w-4 h-4 sm:w-5 sm:h-5 mx-auto mb-1 text-yellow-400" />
                        <div className="text-sm sm:text-base lg:text-lg font-bold text-yellow-400">{creator.codeUses.toLocaleString()}</div>
                        <div className="text-xs text-gray-400">Code Uses</div>
                      </div>
                      
                      <div className="bg-black/30 rounded-lg p-2 sm:p-3 text-center">
                        <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 mx-auto mb-1 text-purple-400" />
                        <div className="text-sm sm:text-base lg:text-lg font-bold text-purple-400">+{Math.floor(Math.random() * 20 + 15)}%</div>
                        <div className="text-xs text-gray-400">Growth</div>
                      </div>
                      
                      <div className="bg-black/30 rounded-lg p-2 sm:p-3 text-center">
                        <Zap className="w-4 h-4 sm:w-5 sm:h-5 mx-auto mb-1 text-orange-400" />
                        <div className="text-sm sm:text-base lg:text-lg font-bold text-orange-400">{Math.floor(Math.random() * 5 + 3)}.{Math.floor(Math.random() * 10)}</div>
                        <div className="text-xs text-gray-400">Rating</div>
                      </div>
                    </div>

                    {/* Promo Code Section - Responsive */}
                    <div className="bg-gradient-to-r from-green-900/40 to-emerald-900/30 border border-green-400/30 rounded-xl p-3 sm:p-4">
                      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                        <div className="text-center sm:text-left">
                          <h4 className="text-green-400 font-bold text-base sm:text-lg mb-1">
                            🎁 Exclusive Promo Code
                          </h4>
                          <p className="text-gray-400 text-xs sm:text-sm">Use this code for 20% off + track conversions</p>
                        </div>
                        <div className="text-center">
                          <div className="text-xl sm:text-2xl font-bold text-white bg-green-600/20 px-3 sm:px-4 py-2 rounded-lg border border-green-400/40 mb-1">
                            {creator.promoCode}
                          </div>
                          <div className="text-xs text-gray-400">
                            {creator.codeUses.toLocaleString()} total uses
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="mt-6 lg:mt-8 text-center">
              <div className="bg-gradient-to-r from-purple-900/40 to-pink-900/30 border border-purple-400/30 rounded-xl p-4 sm:p-6 backdrop-blur-sm">
                <h3 className="text-xl sm:text-2xl font-bold text-purple-400 mb-2">🚀 Want to Join the Top 5?</h3>
                <p className="text-gray-400 mb-4 text-sm sm:text-base">
                  Performance-based earnings mean the sky's the limit. The more followers you have, the more you earn!
                </p>
                <div className="flex flex-wrap justify-center gap-4 sm:gap-6 text-xs sm:text-sm">
                  <div className="text-green-400">✓ No ceiling on earnings</div>
                  <div className="text-blue-400">✓ Custom promo codes</div>
                  <div className="text-purple-400">✓ Premium creator benefits</div>
                </div>
              </div>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}