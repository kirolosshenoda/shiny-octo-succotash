import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Users, DollarSign, Clock, PlayCircle, TrendingUp, Zap } from 'lucide-react';

interface LiveCreatorsModalProps {
  children: React.ReactNode;
}

export default function LiveCreatorsModal({ children }: LiveCreatorsModalProps) {
  const liveCreators = [
    {
      id: 1,
      name: "GamerQueen_Emma",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616c-art&auto=format&fit=crop&w=100&q=80",
      location: "Manchester",
      followers: "127K",
      currentEarnings: "£45.20",
      timeOnline: "2h 15m",
      gameType: "Casino Slots",
      viewerCount: 892,
      status: "recording"
    },
    {
      id: 2,
      name: "LondonLucky_Marcus",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      location: "London",
      followers: "89K",
      currentEarnings: "£32.80",
      timeOnline: "1h 45m",
      gameType: "Sports Betting",
      viewerCount: 654,
      status: "live"
    },
    {
      id: 3,
      name: "BrightonBabe_Sophie",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      location: "Brighton",
      followers: "203K",
      currentEarnings: "£67.40",
      timeOnline: "3h 20m",
      gameType: "Live Casino",
      viewerCount: 1247,
      status: "recording"
    },
    {
      id: 4,
      name: "ScottishSlots_Jamie",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      location: "Edinburgh",
      followers: "156K",
      currentEarnings: "£51.90",
      timeOnline: "2h 55m",
      gameType: "Poker",
      viewerCount: 723,
      status: "live"
    },
    {
      id: 5,
      name: "WelshWins_Chloe",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      location: "Cardiff",
      followers: "94K",
      currentEarnings: "£38.60",
      timeOnline: "1h 30m",
      gameType: "Blackjack",
      viewerCount: 456,
      status: "recording"
    },
    {
      id: 6,
      name: "IrishLuck_Conor",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      location: "Belfast",
      followers: "178K",
      currentEarnings: "£58.30",
      timeOnline: "2h 40m",
      gameType: "Roulette",
      viewerCount: 987,
      status: "live"
    }
  ];

  return (
    <Dialog>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-black via-purple-950/50 to-pink-950/30 border-purple-500/30 text-white">
        <DialogHeader>
          <DialogTitle className="text-3xl font-bold text-center mb-4">
            <div className="flex items-center justify-center space-x-3">
              <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
              <span className="bg-gradient-to-r from-red-400 to-pink-400 bg-clip-text text-transparent">
                LIVE NOW
              </span>
              <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
            </div>
          </DialogTitle>
          <p className="text-center text-gray-400 text-lg">
            Watch UK creators earning money in real-time!
          </p>
        </DialogHeader>

        <div className="space-y-4 mt-6">
          {liveCreators.map((creator, index) => (
            <Card key={creator.id} className="bg-gradient-to-r from-purple-900/40 to-pink-900/30 border-purple-500/30 backdrop-blur-sm hover:scale-[1.02] transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <ImageWithFallback
                        src={creator.avatar}
                        alt={creator.name}
                        className="w-16 h-16 rounded-full object-cover border-2 border-purple-400"
                      />
                      <div className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full border-2 border-black flex items-center justify-center ${
                        creator.status === 'live' ? 'bg-red-500' : 'bg-orange-500'
                      }`}>
                        {creator.status === 'live' ? (
                          <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                        ) : (
                          <PlayCircle className="w-3 h-3 text-white" />
                        )}
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-xl font-bold text-white">{creator.name}</h3>
                      <div className="flex items-center space-x-3 text-sm text-gray-400">
                        <span>📍 {creator.location}</span>
                        <span className="flex items-center">
                          <Users className="w-4 h-4 mr-1" />
                          {creator.followers}
                        </span>
                        <span className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {creator.timeOnline}
                        </span>
                      </div>
                      <Badge className="mt-2 bg-blue-500/20 text-blue-300 border-blue-400/30">
                        {creator.gameType}
                      </Badge>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-3xl font-bold text-green-400 mb-1">
                      {creator.currentEarnings}
                    </div>
                    <div className="text-sm text-gray-400 mb-2">earnings today</div>
                    <div className="flex items-center text-sm text-purple-300">
                      <TrendingUp className="w-4 h-4 mr-1" />
                      {creator.viewerCount.toLocaleString()} watching
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-between">
                  <Badge className={`${
                    creator.status === 'live' 
                      ? 'bg-red-500/20 text-red-300 border-red-400/30' 
                      : 'bg-orange-500/20 text-orange-300 border-orange-400/30'
                  } animate-pulse`}>
                    {creator.status === 'live' ? '🔴 LIVE STREAMING' : '🎬 RECORDING CONTENT'}
                  </Badge>
                  
                  <div className="flex items-center space-x-4 text-sm">
                    <div className="flex items-center text-yellow-400">
                      <DollarSign className="w-4 h-4 mr-1" />
                      <span>£{(Math.random() * 10 + 15).toFixed(2)}/hr rate</span>
                    </div>
                    <div className="flex items-center text-green-400">
                      <Zap className="w-4 h-4 mr-1" />
                      <span>+{Math.floor(Math.random() * 50 + 10)} conversions</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-8 text-center">
          <div className="bg-gradient-to-r from-green-900/40 to-emerald-900/30 border border-green-400/30 rounded-xl p-6 backdrop-blur-sm">
            <h3 className="text-2xl font-bold text-green-400 mb-2">💰 Total Platform Earnings Today</h3>
            <div className="text-4xl font-bold text-white mb-2">£{(67890 + Math.random() * 1000).toFixed(0)}</div>
            <p className="text-gray-400">Join them and start earning now!</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}