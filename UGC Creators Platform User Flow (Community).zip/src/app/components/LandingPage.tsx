import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import LiveCreatorsModal from './LiveCreatorsModal';
import HotCreatorsModal from './HotCreatorsModal';
import { 
  Play, Gamepad2, Trophy, Zap, Star, TrendingUp, Users, Clock, DollarSign, Target, 
  Crown, Code, ArrowRight, ChevronRight, Sparkles, Flame, Copy, ExternalLink,
  BarChart3, TrendingDown, Award, Gift
} from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
}

export default function LandingPage({ onGetStarted }: LandingPageProps) {
  const [currentGame, setCurrentGame] = useState(0);
  const [floatingIndex, setFloatingIndex] = useState(0);
  const [liveCount, setLiveCount] = useState(1247);
  const [todayEarnings, setTodayEarnings] = useState(67890);
  
  const gameTypes = ["🎰 Casino", "🎮 Slots", "🏆 Sports", "🎯 Poker", "🃏 Blackjack"];
  const floatingEmojis = ["💎", "🎰", "🏆", "💰", "⚡", "🎮", "🔥", "💸", "🎲", "👑"];
  
  useEffect(() => {
    const gameInterval = setInterval(() => {
      setCurrentGame((prev) => (prev + 1) % gameTypes.length);
    }, 2000);
    
    const floatingInterval = setInterval(() => {
      setFloatingIndex((prev) => (prev + 1) % floatingEmojis.length);
    }, 3000);

    // Simulate live updates
    const liveInterval = setInterval(() => {
      setLiveCount(prev => prev + Math.floor(Math.random() * 10 - 3));
      setTodayEarnings(prev => prev + Math.floor(Math.random() * 50 + 10));
    }, 5000);
    
    return () => {
      clearInterval(gameInterval);
      clearInterval(floatingInterval);
      clearInterval(liveInterval);
    };
  }, []);

  const testimonials = [
    {
      name: "Alex_GamerUK, 24",
      text: "450K followers = £2,800/month! My biggest win yet was £500 in one stream! 🔥",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=250&q=80",
      earnings: "£2,800",
      followers: "450K",
      promoCode: "ALEX20",
      verified: true,
      tier: "diamond"
    },
    {
      name: "Sophie_London, 22",
      text: "Started with 50K followers, now earning £1,200/month! My promo code gets 1000+ uses daily! 💰",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616c-art&auto=format&fit=crop&w=250&q=80",
      earnings: "£1,200",
      followers: "180K",
      promoCode: "SOPHIE15",
      verified: true,
      tier: "gold"
    },
    {
      name: "Marcus_Manchester, 29",
      text: "720K followers brought me £3,500 last month! Plus £800 just from referrals! 🚀",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=250&q=80",
      earnings: "£3,500",
      followers: "720K",
      promoCode: "MARCUS25",
      verified: true,
      tier: "diamond"
    }
  ];

  const earningTiers = [
    {
      tier: "Starter",
      followers: "0-10K",
      baseRate: "£20",
      bonusRate: "£0.02",
      color: "from-gray-500 to-slate-600",
      icon: "🥉"
    },
    {
      tier: "Rising Star",
      followers: "10K-50K",
      baseRate: "£35",
      bonusRate: "£0.05",
      color: "from-blue-500 to-cyan-600",
      icon: "⭐"
    },
    {
      tier: "Gold Creator",
      followers: "50K-200K",
      baseRate: "£60",
      bonusRate: "£0.08",
      color: "from-yellow-500 to-orange-600",
      icon: "🥇"
    },
    {
      tier: "Diamond Elite",
      followers: "200K+",
      baseRate: "£100",
      bonusRate: "£0.12",
      color: "from-purple-500 to-pink-600",
      icon: "💎"
    }
  ];

  const liveStats = [
    { label: "Creators Online", value: liveCount.toLocaleString(), icon: Users, color: "text-green-400", animate: true },
    { label: "Paid Today", value: `£${todayEarnings.toLocaleString()}`, icon: DollarSign, color: "text-yellow-400", animate: true },
    { label: "Avg Approval Time", value: "28hrs", icon: Clock, color: "text-blue-400" },
    { label: "Success Rate", value: "97.2%", icon: Target, color: "text-purple-400" }
  ];

  const copyPromoCode = (code: string) => {
    navigator.clipboard.writeText(code);
    // You could add a toast notification here
  };

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Enhanced AI-Style Video Background Effect */}
      <div className="absolute inset-0">
        {/* Multi-layer gradient mesh */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/30 via-black to-pink-900/30"></div>
        <div className="absolute inset-0 bg-gradient-to-tl from-blue-900/20 via-transparent to-yellow-900/20"></div>
        
        {/* Advanced grid pattern with multiple layers */}
        <div className="absolute inset-0 opacity-15">
          <div 
            className="absolute inset-0"
            style={{
              backgroundImage: `
                linear-gradient(rgba(139, 92, 246, 0.4) 1px, transparent 1px),
                linear-gradient(90deg, rgba(139, 92, 246, 0.4) 1px, transparent 1px),
                linear-gradient(rgba(236, 72, 153, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(236, 72, 153, 0.3) 1px, transparent 1px)
              `,
              backgroundSize: '60px 60px, 60px 60px, 120px 120px, 120px 120px',
              animation: 'grid-move 25s linear infinite, grid-fade 8s ease-in-out infinite alternate'
            }}
          />
        </div>

        {/* Enhanced floating particles with different sizes */}
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float opacity-60"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.3}s`,
              animationDuration: `${6 + Math.random() * 8}s`
            }}
          >
            <div className={`${
              i % 3 === 0 ? 'w-3 h-3' : i % 3 === 1 ? 'w-2 h-2' : 'w-1 h-1'
            } bg-gradient-to-r from-purple-400 to-pink-400 rounded-full blur-sm`}></div>
          </div>
        ))}

        {/* Dynamic floating gaming elements */}
        {floatingEmojis.slice(0, 8).map((emoji, i) => (
          <div
            key={i}
            className="absolute animate-bounce opacity-40"
            style={{
              left: `${10 + (i % 4) * 25}%`,
              top: `${15 + Math.floor(i / 4) * 35}%`,
              animationDelay: `${i * 0.5}s`,
              animationDuration: `${3 + Math.random() * 2}s`,
              fontSize: `${2 + Math.random() * 2}rem`
            }}
          >
            {emoji}
          </div>
        ))}
      </div>

      {/* Enhanced Header */}
      <header className="relative z-10 p-4 lg:p-6 flex flex-col lg:flex-row justify-between items-center border-b border-purple-500/20 backdrop-blur-md bg-black/30">
        <div className="flex items-center space-x-4 mb-4 lg:mb-0">
          <div className="text-4xl lg:text-5xl animate-pulse">🎮</div>
          <div>
            <div className="text-2xl lg:text-3xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-yellow-400 bg-clip-text text-transparent">
              UGC Creators
            </div>
            <div className="text-xs text-gray-400 uppercase tracking-wider">Gaming Edition by Incline • UK's #1 Platform</div>
          </div>
        </div>
        
        <div className="flex flex-wrap items-center justify-center lg:justify-end space-x-3 lg:space-x-4">
          <LiveCreatorsModal>
            <Badge className="bg-gradient-to-r from-red-500 to-pink-500 text-white animate-pulse px-4 py-2 cursor-pointer hover:scale-105 transition-transform">
              <div className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse"></div>
              LIVE NOW
            </Badge>
          </LiveCreatorsModal>
          
          <HotCreatorsModal>
            <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-4 py-2 cursor-pointer hover:scale-105 transition-transform">
              🔥 HOT
            </Badge>
          </HotCreatorsModal>
          
          <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-4 py-2">
            💎 PREMIUM
          </Badge>
        </div>
      </header>

      {/* Hero Section - Enhanced */}
      <section className="relative z-10 px-4 lg:px-6 py-12 lg:py-20 text-center">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8 lg:mb-16">
            <Badge className="bg-purple-500/20 text-purple-300 border-purple-400/30 mb-6 text-lg lg:text-xl px-6 py-3 backdrop-blur-sm animate-pulse">
              💎 PERFORMANCE-BASED CREATOR PROGRAMME
            </Badge>
            
            <h1 className="text-4xl md:text-6xl lg:text-8xl xl:text-9xl font-bold mb-6 lg:mb-8 leading-tight">
              <span className="bg-gradient-to-r from-white via-purple-200 to-pink-200 bg-clip-text text-transparent block mb-2 lg:mb-4">
                More Followers =
              </span>
              <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-yellow-400 bg-clip-text text-transparent relative">
                More Money from {gameTypes[currentGame]}
                <div className="absolute -inset-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 blur-2xl rounded-full"></div>
              </span>
            </h1>
          </div>
          
          <p className="text-xl md:text-2xl lg:text-3xl text-gray-300 mb-8 lg:mb-12 max-w-5xl mx-auto leading-relaxed">
            🎯 <span className="text-white font-semibold">Performance-based earnings</span> • 
            📱 <span className="text-white font-semibold">Your promo code</span> • 
            💰 <span className="text-white font-semibold">No earnings limit</span>
          </p>

          <div className="flex flex-col lg:flex-row gap-4 lg:gap-6 justify-center items-center mb-8 lg:mb-16">
            <Button 
              onClick={onGetStarted}
              className="w-full sm:w-auto bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500 hover:from-purple-600 hover:via-pink-600 hover:to-yellow-600 text-white px-8 lg:px-12 py-6 lg:py-8 text-2xl lg:text-3xl rounded-full shadow-2xl shadow-purple-500/50 transform transition-all hover:scale-110 relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 to-pink-400/20 animate-pulse"></div>
              <Gamepad2 className="w-6 lg:w-8 h-6 lg:h-8 mr-3 lg:mr-4 relative z-10" />
              <span className="relative z-10">START EARNING NOW</span>
            </Button>
            
            <div className="flex items-center text-green-400 bg-black/50 px-4 lg:px-6 py-3 lg:py-4 rounded-full backdrop-blur-sm border border-green-400/30 hover:scale-105 transition-transform cursor-pointer">
              <Play className="w-5 lg:w-6 h-5 lg:h-6 mr-3" />
              <span className="font-medium text-base lg:text-lg">Watch How It Works (30s)</span>
            </div>
          </div>

          {/* Enhanced Live Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 max-w-5xl mx-auto">
            {liveStats.map((stat, index) => (
              <div key={index} className="bg-black/60 backdrop-blur-md border border-purple-500/30 rounded-xl p-4 lg:p-6 text-center hover:scale-105 transition-transform group">
                <stat.icon className={`w-5 lg:w-6 h-5 lg:h-6 mx-auto mb-2 ${stat.color} group-hover:animate-pulse`} />
                <div className={`text-lg lg:text-xl font-bold ${stat.color} ${stat.animate ? 'animate-pulse' : ''}`}>
                  {stat.value}
                </div>
                <div className="text-xs lg:text-sm text-gray-400 uppercase tracking-wide">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Performance-Based Earnings Tiers */}
      <section className="relative z-10 px-4 lg:px-6 py-16 lg:py-24">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12 lg:mb-20">
            <h2 className="text-4xl lg:text-6xl font-bold text-white mb-4 lg:mb-6">
              💰 Performance-Based Earnings
            </h2>
            <p className="text-xl lg:text-2xl text-gray-400 max-w-3xl mx-auto">
              The more followers you have, the more you earn. No limits, just pure performance rewards!
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
            {earningTiers.map((tier, index) => (
              <Card key={index} className={`bg-gradient-to-br from-purple-900/50 to-pink-900/40 border-purple-500/30 backdrop-blur-sm transform hover:scale-105 transition-all duration-500 relative overflow-hidden group ${
                tier.tier === 'Diamond Elite' ? 'ring-2 ring-purple-400/50 shadow-2xl shadow-purple-400/20' : ''
              }`}>
                {tier.tier === 'Diamond Elite' && (
                  <div className="absolute top-0 right-0 bg-gradient-to-l from-purple-500 to-pink-500 text-white px-4 py-1 text-sm font-bold">
                    👑 PREMIUM
                  </div>
                )}
                
                <CardContent className="p-6 lg:p-8 text-center">
                  <div className="text-6xl lg:text-8xl mb-4 lg:mb-6">{tier.icon}</div>
                  <h3 className="text-2xl lg:text-3xl font-bold text-white mb-2">{tier.tier}</h3>
                  <Badge className={`bg-gradient-to-r ${tier.color} text-white mb-4 text-sm lg:text-base px-3 py-1`}>
                    {tier.followers} followers
                  </Badge>
                  
                  <div className="space-y-3 lg:space-y-4">
                    <div>
                      <div className="text-3xl lg:text-4xl font-bold text-green-400">{tier.baseRate}</div>
                      <div className="text-gray-400 text-sm lg:text-base">base per video</div>
                    </div>
                    
                    <div className="bg-black/30 rounded-lg p-3 lg:p-4">
                      <div className="text-xl lg:text-2xl font-bold text-yellow-400">{tier.bonusRate}</div>
                      <div className="text-gray-400 text-xs lg:text-sm">per follower bonus</div>
                    </div>
                    
                    <div className="text-sm lg:text-base text-gray-300">
                      + Custom promo code
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Earnings Calculator Example */}
          <div className="mt-12 lg:mt-16 text-center">
            <Card className="bg-gradient-to-r from-green-900/50 to-emerald-900/40 border-green-500/30 backdrop-blur-sm max-w-4xl mx-auto">
              <CardContent className="p-6 lg:p-8">
                <h3 className="text-2xl lg:text-3xl font-bold text-green-400 mb-6">📊 Earnings Calculator Example</h3>
                <div className="grid md:grid-cols-3 gap-6 lg:gap-8 text-center">
                  <div>
                    <div className="text-lg lg:text-xl text-gray-400 mb-2">100K Followers</div>
                    <div className="text-3xl lg:text-4xl font-bold text-white">£95</div>
                    <div className="text-sm text-gray-400">per video</div>
                  </div>
                  <div>
                    <div className="text-lg lg:text-xl text-gray-400 mb-2">500K Followers</div>
                    <div className="text-3xl lg:text-4xl font-bold text-yellow-400">£140</div>
                    <div className="text-sm text-gray-400">per video</div>
                  </div>
                  <div>
                    <div className="text-lg lg:text-xl text-gray-400 mb-2">1M+ Followers</div>
                    <div className="text-3xl lg:text-4xl font-bold text-purple-400">£220+</div>
                    <div className="text-sm text-gray-400">per video</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Enhanced Creator Testimonials with Promo Codes */}
      <section className="relative z-10 px-4 lg:px-6 py-16 lg:py-24 bg-gradient-to-r from-purple-950/30 to-pink-950/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12 lg:mb-20">
            <h2 className="text-4xl lg:text-6xl font-bold text-white mb-4 lg:mb-6">
              🏆 Success Stories + Promo Codes
            </h2>
            <p className="text-xl lg:text-2xl text-gray-400 max-w-4xl mx-auto">
              Real creators, real earnings, real promo codes you can use right now!
            </p>
          </div>
          
          <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-gradient-to-br from-black/80 to-gray-900/60 border-purple-500/30 backdrop-blur-sm transform hover:scale-105 transition-all duration-500 relative overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-600/5 to-pink-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                
                {/* Tier badge */}
                <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-bold ${
                  testimonial.tier === 'diamond' ? 'bg-purple-500 text-white' : 'bg-yellow-500 text-black'
                }`}>
                  {testimonial.tier === 'diamond' ? '💎 DIAMOND' : '🥇 GOLD'}
                </div>
                
                <CardContent className="p-6 lg:p-8 relative z-10">
                  <div className="flex items-center mb-6">
                    <div className="relative">
                      <ImageWithFallback
                        src={testimonial.avatar}
                        alt={testimonial.name}
                        className="w-16 h-16 lg:w-20 lg:h-20 rounded-full mr-4 object-cover border-3 border-purple-400"
                      />
                      {testimonial.verified && (
                        <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      )}
                    </div>
                    <div className="flex-grow">
                      <div className="text-purple-300 font-semibold text-lg lg:text-xl">{testimonial.name}</div>
                      <div className="flex items-center space-x-3 text-sm text-gray-400">
                        <span className="flex items-center">
                          <Users className="w-4 h-4 mr-1" />
                          {testimonial.followers}
                        </span>
                        <Badge className="bg-green-500/20 text-green-300 border-green-400/30 text-xs">
                          VERIFIED
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-gray-300 italic text-base lg:text-lg mb-6 leading-relaxed">"{testimonial.text}"</p>
                  
                  <div className="space-y-4">
                    {/* Earnings */}
                    <div className="bg-green-900/30 border border-green-400/30 rounded-lg p-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <div className="text-2xl lg:text-3xl font-bold text-green-400">{testimonial.earnings}</div>
                          <div className="text-sm text-gray-400">monthly earnings</div>
                        </div>
                        <TrendingUp className="w-6 h-6 text-green-400" />
                      </div>
                    </div>
                    
                    {/* Promo Code */}
                    <div className="bg-blue-900/30 border border-blue-400/30 rounded-lg p-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <div className="text-lg font-bold text-blue-300 mb-1">🎁 Active Promo Code</div>
                          <div className="text-2xl font-bold text-white bg-blue-600/20 px-3 py-1 rounded inline-block">
                            {testimonial.promoCode}
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            onClick={() => copyPromoCode(testimonial.promoCode)}
                            size="sm"
                            variant="outline"
                            className="border-blue-400/50 text-blue-300 hover:bg-blue-500/10"
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            className="bg-blue-500 hover:bg-blue-600 text-white"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="text-xs text-gray-400 mt-2">
                        20% off for new users • Track conversions • Earn commission
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works - Enhanced Tutorial */}
      <section className="relative z-10 px-4 lg:px-6 py-16 lg:py-24">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12 lg:mb-20">
            <h2 className="text-4xl lg:text-6xl font-bold text-white mb-4 lg:mb-6">
              🎯 How the Performance System Works
            </h2>
            <p className="text-xl lg:text-2xl text-gray-400">
              From zero to hero in 4 simple steps
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
            {[
              { 
                step: 1, 
                icon: "📝", 
                title: "Sign Up", 
                desc: "Register & connect your socials", 
                color: "from-blue-500 to-cyan-500",
                detail: "Link your social accounts to calculate your follower-based earnings tier"
              },
              { 
                step: 2, 
                icon: "🎲", 
                title: "Get Assets", 
                desc: "Receive persona + promo code", 
                color: "from-purple-500 to-pink-500",
                detail: "Get your unique promo code and gaming character for authentic content"
              },
              { 
                step: 3, 
                icon: "📱", 
                title: "Create Content", 
                desc: "Film + share with your code", 
                color: "from-pink-500 to-red-500",
                detail: "Create authentic gaming content and promote your trackable discount code"
              },
              { 
                step: 4, 
                icon: "💰", 
                title: "Earn More", 
                desc: "Get paid per follower + conversion", 
                color: "from-green-500 to-emerald-500",
                detail: "Earn base rate + follower bonus + commission on every code use"
              }
            ].map((item, index) => (
              <Card key={index} className="bg-gradient-to-br from-purple-900/50 to-pink-900/40 border-purple-500/30 backdrop-blur-sm text-center group hover:scale-105 transition-all duration-500">
                <CardContent className="p-6 lg:p-8">
                  <div className="relative mb-6">
                    <div className={`w-20 h-20 lg:w-24 lg:h-24 bg-gradient-to-r ${item.color} rounded-full flex items-center justify-center mx-auto text-3xl lg:text-4xl shadow-2xl transform group-hover:scale-110 transition-transform duration-300`}>
                      {item.icon}
                    </div>
                    <Badge className="absolute -top-3 -right-3 bg-yellow-500 text-black font-bold text-lg px-3 py-1">
                      {item.step}
                    </Badge>
                    
                    {/* Connecting Line */}
                    {index < 3 && (
                      <div className="hidden lg:block absolute top-10 left-full w-full h-1 bg-gradient-to-r from-purple-500/50 to-transparent transform translate-x-4"></div>
                    )}
                  </div>
                  
                  <h3 className="text-xl lg:text-2xl font-bold text-white mb-3">{item.title}</h3>
                  <p className="text-gray-400 text-base lg:text-lg leading-relaxed mb-4">{item.desc}</p>
                  <p className="text-sm text-gray-500 leading-relaxed">{item.detail}</p>
                  
                  <div className="mt-4">
                    <Badge className={`bg-gradient-to-r ${item.color} bg-opacity-20 text-white border-0 px-4 py-2`}>
                      Step {item.step}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Promo Code System Explanation */}
      <section className="relative z-10 px-4 lg:px-6 py-16 lg:py-24 bg-gradient-to-r from-blue-950/30 to-purple-950/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="text-4xl lg:text-6xl font-bold text-white mb-4 lg:mb-6">
              🎁 Your Personal Promo Code System
            </h2>
            <p className="text-xl lg:text-2xl text-gray-400 max-w-4xl mx-auto">
              Every creator gets a unique trackable promo code. Your followers save money, you earn more!
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            <Card className="bg-gradient-to-br from-green-900/50 to-emerald-900/40 border-green-500/30 backdrop-blur-sm">
              <CardContent className="p-8 text-center">
                <Gift className="w-16 h-16 mx-auto mb-6 text-green-400" />
                <h3 className="text-2xl font-bold text-green-400 mb-4">For Your Followers</h3>
                <div className="space-y-3 text-gray-300">
                  <div>💰 20% off first deposit</div>
                  <div>🎮 Exclusive game bonuses</div>
                  <div>⚡ Instant activation</div>
                  <div>🎁 Special promotions</div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-900/50 to-pink-900/40 border-purple-500/30 backdrop-blur-sm">
              <CardContent className="p-8 text-center">
                <BarChart3 className="w-16 h-16 mx-auto mb-6 text-purple-400" />
                <h3 className="text-2xl font-bold text-purple-400 mb-4">Full Tracking</h3>
                <div className="space-y-3 text-gray-300">
                  <div>📊 Real-time analytics</div>
                  <div>👥 User conversion tracking</div>
                  <div>💸 Revenue attribution</div>
                  <div>📈 Performance insights</div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-yellow-900/50 to-orange-900/40 border-yellow-500/30 backdrop-blur-sm">
              <CardContent className="p-8 text-center">
                <Award className="w-16 h-16 mx-auto mb-6 text-yellow-400" />
                <h3 className="text-2xl font-bold text-yellow-400 mb-4">For You</h3>
                <div className="space-y-3 text-gray-300">
                  <div>💰 Commission per use</div>
                  <div>📈 Bonus tier unlocks</div>
                  <div>🏆 Performance rewards</div>
                  <div>💎 VIP creator status</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Final CTA - Enhanced */}
      <section className="relative z-10 px-4 lg:px-6 py-16 lg:py-24 text-center">
        <div className="max-w-5xl mx-auto">
          <div className="mb-8 lg:mb-16">
            <div className="text-6xl lg:text-8xl mb-6 animate-bounce">🎮</div>
            <h2 className="text-4xl lg:text-7xl font-bold mb-6 lg:mb-8 text-white">
              Ready to Level Up Your Earnings?
            </h2>
            <p className="text-xl lg:text-3xl text-gray-300 mb-8 lg:mb-12 leading-relaxed max-w-4xl mx-auto">
              Join the performance-based revolution. The more you grow, the more you earn. No limits, just results!
            </p>
          </div>
          
          <div className="space-y-6 lg:space-y-8">
            <Button 
              onClick={onGetStarted}
              className="w-full sm:w-auto bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500 hover:from-purple-600 hover:via-pink-600 hover:to-yellow-600 text-white px-12 lg:px-20 py-8 lg:py-12 text-2xl lg:text-4xl rounded-full shadow-2xl shadow-purple-500/50 transform transition-all hover:scale-110 relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 to-pink-400/20 animate-pulse"></div>
              <Zap className="w-6 lg:w-10 h-6 lg:h-10 mr-4 lg:mr-6 relative z-10" />
              <span className="relative z-10">START EARNING BIG NOW</span>
            </Button>
            
            <div className="flex flex-wrap justify-center items-center gap-4 lg:gap-8 text-base lg:text-lg">
              <div className="flex items-center text-green-400">
                <TrendingUp className="w-5 h-5 mr-2" />
                <span>Performance-based</span>
              </div>
              <span className="text-gray-400">•</span>
              <div className="text-yellow-400 flex items-center">
                <Code className="w-5 h-5 mr-2" />
                <span>Personal promo code</span>
              </div>
              <span className="text-gray-400">•</span>
              <div className="text-purple-400 flex items-center">
                <Crown className="w-5 h-5 mr-2" />
                <span>No earnings ceiling</span>
              </div>
              <span className="text-gray-400">•</span>
              <div className="text-pink-400 flex items-center">
                <Users className="w-5 h-5 mr-2" />
                <span>UK's #1 platform</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Footer */}
      <footer className="relative z-10 px-4 lg:px-6 py-8 lg:py-12 border-t border-purple-500/20 bg-black/50 backdrop-blur-md">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row justify-between items-center">
          <div className="mb-6 lg:mb-0 flex items-center text-center lg:text-left">
            <span className="text-3xl lg:text-4xl mr-3 animate-pulse">🎮</span>
            <div>
              <div className="text-lg lg:text-xl font-semibold text-white">© 2025 UGC Creators Gaming by Incline</div>
              <div className="text-sm text-gray-400">Performance-based creator platform • Made in the UK 🇬🇧</div>
            </div>
          </div>
          <div className="flex flex-wrap gap-4 lg:gap-8 text-sm justify-center lg:justify-end">
            <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors">Terms & Conditions</a>
            <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors">Privacy Policy</a>
            <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors">Creator Support</a>
            <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors">Discord Community</a>
            <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors">Performance Guidelines</a>
          </div>
        </div>
      </footer>

      {/* Enhanced Custom CSS for animations */}
      <style>{`
        @keyframes grid-move {
          0% { transform: translate(0, 0); }
          100% { transform: translate(60px, 60px); }
        }
        
        @keyframes grid-fade {
          0%, 100% { opacity: 0.1; }
          50% { opacity: 0.2; }
        }
        
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          33% { transform: translateY(-15px) rotate(120deg); }
          66% { transform: translateY(-10px) rotate(240deg); }
        }
        
        .animate-float {
          animation: float 8s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}