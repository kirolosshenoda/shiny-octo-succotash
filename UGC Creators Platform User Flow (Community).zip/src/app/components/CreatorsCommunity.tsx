import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  ArrowLeft, Heart, MessageCircle, Share2, Camera, Upload, Zap, 
  Trophy, Star, Flame, TrendingUp, Users, Crown, Play, Image as ImageIcon
} from 'lucide-react';

interface CreatorsCommunityProps {
  onBack: () => void;
}

export default function CreatorsCommunity({ onBack }: CreatorsCommunityProps) {
  const [newPostText, setNewPostText] = useState('');
  const [selectedTab, setSelectedTab] = useState('feed');

  const communityPosts = [
    {
      id: 1,
      creator: {
        name: "Alex_GamerUK",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
        followers: "450K",
        tier: "Diamond",
        verified: true
      },
      content: "Just hit my biggest win ever! £500 in one stream! 🔥 The community support has been incredible. Thank you everyone!",
      image: "https://images.unsplash.com/photo-1596838132731-3301c3fd4317?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
      timestamp: "2 hours ago",
      likes: 247,
      comments: 32,
      shares: 18,
      isVideo: false
    },
    {
      id: 2,
      creator: {
        name: "Sophie_London",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616c-art&auto=format&fit=crop&w=100&q=80",
        followers: "180K",
        tier: "Gold",
        verified: true
      },
      content: "Behind the scenes of my latest casino content! The setup is getting more professional each month. UGC Creators changed my life! 💰",
      image: "https://images.unsplash.com/photo-1579952363873-27d3bfad9c0d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
      timestamp: "5 hours ago",
      likes: 189,
      comments: 28,
      shares: 15,
      isVideo: true
    },
    {
      id: 3,
      creator: {
        name: "Marcus_Manchester",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
        followers: "720K",
        tier: "Diamond",
        verified: true
      },
      content: "New creators asking for tips - here's my advice: Be authentic! Your genuine reactions are what viewers connect with. Don't try to fake excitement.",
      timestamp: "8 hours ago",
      likes: 156,
      comments: 45,
      shares: 22,
      isVideo: false
    },
    {
      id: 4,
      creator: {
        name: "Emma_Brighton",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
        followers: "95K",
        tier: "Gold",
        verified: true
      },
      content: "My promo code just hit 1000 uses this week! 🎉 The performance-based system really works. Thank you UGC team!",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
      timestamp: "12 hours ago",
      likes: 203,
      comments: 19,
      shares: 31,
      isVideo: false
    },
    {
      id: 5,
      creator: {
        name: "Tyler_Cardiff",
        avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
        followers: "67K",
        tier: "Rising Star",
        verified: false
      },
      content: "First month complete! From zero followers to 67K and already earning £800! This platform is incredible for new creators. 🚀",
      timestamp: "1 day ago",
      likes: 178,
      comments: 24,
      shares: 12,
      isVideo: false
    }
  ];

  const topPerformers = [
    { name: "Alex_GamerUK", earnings: "£2,800", growth: "+15%" },
    { name: "Sophie_London", earnings: "£1,200", growth: "+22%" },
    { name: "Marcus_Manchester", earnings: "£3,500", growth: "+8%" },
    { name: "Emma_Brighton", earnings: "£950", growth: "+31%" }
  ];

  const communityStats = [
    { label: "Active Creators", value: "3,247", icon: Users, color: "text-blue-400" },
    { label: "Posts This Week", value: "1,856", icon: MessageCircle, color: "text-green-400" },
    { label: "Total Earnings Shared", value: "£89K", icon: Trophy, color: "text-yellow-400" },
    { label: "Success Stories", value: "456", icon: Star, color: "text-purple-400" }
  ];

  const getTierBadge = (tier: string) => {
    switch (tier) {
      case 'Diamond':
        return 'bg-purple-500/20 text-purple-300 border-purple-400/30';
      case 'Gold':
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-400/30';
      case 'Rising Star':
        return 'bg-blue-500/20 text-blue-300 border-blue-400/30';
      default:
        return 'bg-gray-500/20 text-gray-300 border-gray-400/30';
    }
  };

  const handleCreatePost = () => {
    if (newPostText.trim()) {
      // In a real app, this would send to backend
      alert('Post created successfully! 🎉');
      setNewPostText('');
    }
  };

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Enhanced Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20"></div>
        
        {/* Animated particles */}
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.8}s`,
              animationDuration: `${8 + Math.random() * 4}s`
            }}
          >
            <div className="w-3 h-3 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-30 blur-sm"></div>
          </div>
        ))}

        {/* Floating gaming elements */}
        <div className="absolute top-20 right-10 text-5xl animate-bounce delay-100 opacity-30">💬</div>
        <div className="absolute bottom-32 left-10 text-6xl animate-pulse delay-300 opacity-30">🎉</div>
        <div className="absolute top-60 left-20 text-4xl animate-bounce delay-500 opacity-30">📸</div>
        <div className="absolute bottom-60 right-20 text-5xl animate-pulse delay-700 opacity-30">🚀</div>
      </div>

      {/* Header */}
      <header className="relative z-10 p-4 lg:p-6 mb-6 lg:mb-8">
        <Button
          variant="ghost"
          onClick={onBack}
          className="text-white hover:text-purple-400 hover:bg-purple-500/10 mb-4 lg:mb-6 text-lg group"
        >
          <ArrowLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform" />
          Back to Dashboard
        </Button>
        
        <div className="text-center">
          <div className="flex items-center justify-center space-x-4 mb-3">
            <span className="text-4xl lg:text-5xl animate-pulse">🎮</span>
            <div className="text-3xl lg:text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Creators Community
            </div>
          </div>
          <div className="text-sm text-gray-300 uppercase tracking-wider">Share Your Success • Connect • Inspire</div>
        </div>
      </header>

      <div className="relative z-10 max-w-7xl mx-auto px-4 lg:px-6">
        {/* Community Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8 lg:mb-12">
          {communityStats.map((stat, index) => (
            <Card key={index} className="bg-black/60 backdrop-blur-md border-purple-500/30 hover:scale-105 transition-transform">
              <CardContent className="p-4 lg:p-6 text-center">
                <stat.icon className={`w-6 h-6 lg:w-8 lg:h-8 mx-auto mb-2 ${stat.color}`} />
                <div className={`text-xl lg:text-2xl font-bold ${stat.color}`}>{stat.value}</div>
                <div className="text-xs lg:text-sm text-gray-400 uppercase tracking-wide">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-4 gap-6 lg:gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-3">
            <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-purple-900/20 border border-purple-500/30 rounded-xl">
                <TabsTrigger value="feed" className="data-[state=active]:bg-purple-500/30 text-white">
                  🏠 Feed
                </TabsTrigger>
                <TabsTrigger value="create" className="data-[state=active]:bg-purple-500/30 text-white">
                  📝 Create Post
                </TabsTrigger>
                <TabsTrigger value="trending" className="data-[state=active]:bg-purple-500/30 text-white">
                  🔥 Trending
                </TabsTrigger>
              </TabsList>

              <TabsContent value="feed" className="space-y-6 mt-6">
                <ScrollArea className="h-[800px]">
                  <div className="space-y-6 pr-4">
                    {communityPosts.map((post) => (
                      <Card key={post.id} className="bg-gradient-to-br from-purple-900/30 to-pink-900/20 border-purple-500/30 backdrop-blur-sm">
                        <CardContent className="p-6">
                          {/* Post Header */}
                          <div className="flex items-center space-x-4 mb-4">
                            <div className="relative">
                              <ImageWithFallback
                                src={post.creator.avatar}
                                alt={post.creator.name}
                                className="w-12 h-12 rounded-full object-cover border-2 border-purple-400"
                              />
                              {post.creator.verified && (
                                <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                                  <span className="text-white text-xs">✓</span>
                                </div>
                              )}
                            </div>
                            <div className="flex-grow">
                              <div className="flex items-center space-x-2">
                                <h3 className="font-bold text-white">{post.creator.name}</h3>
                                <Badge className={getTierBadge(post.creator.tier)}>
                                  {post.creator.tier === 'Diamond' && '💎'}
                                  {post.creator.tier === 'Gold' && '🥇'}
                                  {post.creator.tier === 'Rising Star' && '⭐'}
                                  {post.creator.tier}
                                </Badge>
                              </div>
                              <div className="text-sm text-gray-400">
                                {post.creator.followers} followers • {post.timestamp}
                              </div>
                            </div>
                          </div>

                          {/* Post Content */}
                          <p className="text-gray-300 mb-4 leading-relaxed">{post.content}</p>

                          {/* Post Media */}
                          {post.image && (
                            <div className="relative mb-4 rounded-xl overflow-hidden">
                              <ImageWithFallback
                                src={post.image}
                                alt="Post content"
                                className="w-full h-64 object-cover"
                              />
                              {post.isVideo && (
                                <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                                  <Play className="w-16 h-16 text-white/80" />
                                </div>
                              )}
                            </div>
                          )}

                          {/* Post Actions */}
                          <div className="flex items-center justify-between pt-4 border-t border-purple-500/20">
                            <div className="flex items-center space-x-6">
                              <button className="flex items-center space-x-2 text-gray-400 hover:text-red-400 transition-colors">
                                <Heart className="w-5 h-5" />
                                <span>{post.likes}</span>
                              </button>
                              <button className="flex items-center space-x-2 text-gray-400 hover:text-blue-400 transition-colors">
                                <MessageCircle className="w-5 h-5" />
                                <span>{post.comments}</span>
                              </button>
                              <button className="flex items-center space-x-2 text-gray-400 hover:text-green-400 transition-colors">
                                <Share2 className="w-5 h-5" />
                                <span>{post.shares}</span>
                              </button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="create" className="mt-6">
                <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/20 border-purple-500/30 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-2xl text-white flex items-center">
                      <Camera className="w-6 h-6 mr-3 text-purple-400" />
                      Share Your Creator Journey
                    </CardTitle>
                    <p className="text-gray-400">Share your wins, tips, or behind-the-scenes content with the community!</p>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <Textarea
                      value={newPostText}
                      onChange={(e) => setNewPostText(e.target.value)}
                      placeholder="What's happening in your creator journey today? Share your wins, tips, or ask questions! 🎮"
                      className="bg-black/50 border-purple-500/30 text-white placeholder:text-gray-400 min-h-[120px] text-lg"
                    />
                    
                    <div className="flex flex-wrap gap-4">
                      <Button variant="outline" className="border-blue-400/50 text-blue-300 hover:bg-blue-500/10">
                        <ImageIcon className="w-4 h-4 mr-2" />
                        Add Photo
                      </Button>
                      <Button variant="outline" className="border-purple-400/50 text-purple-300 hover:bg-purple-500/10">
                        <Play className="w-4 h-4 mr-2" />
                        Add Video
                      </Button>
                      <Button variant="outline" className="border-yellow-400/50 text-yellow-300 hover:bg-yellow-500/10">
                        <Trophy className="w-4 h-4 mr-2" />
                        Share Win
                      </Button>
                    </div>

                    <Button
                      onClick={handleCreatePost}
                      disabled={!newPostText.trim()}
                      className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-6 text-lg rounded-xl"
                    >
                      <Share2 className="w-5 h-5 mr-2" />
                      Share with Community
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="trending" className="mt-6">
                <div className="grid gap-6">
                  <Card className="bg-gradient-to-r from-orange-900/30 to-red-900/20 border-orange-500/30 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="text-2xl text-white flex items-center">
                        <Flame className="w-6 h-6 mr-3 text-orange-400" />
                        Trending Topics
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {[
                          { tag: "#BigWins", posts: "156 posts", trend: "+45%" },
                          { tag: "#CreatorTips", posts: "89 posts", trend: "+32%" },
                          { tag: "#PromoCodeSuccess", posts: "234 posts", trend: "+67%" },
                          { tag: "#BehindTheScenes", posts: "78 posts", trend: "+28%" },
                          { tag: "#NewCreatorAdvice", posts: "145 posts", trend: "+51%" }
                        ].map((topic, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-black/20 rounded-lg">
                            <div>
                              <div className="text-orange-400 font-bold">{topic.tag}</div>
                              <div className="text-gray-400 text-sm">{topic.posts}</div>
                            </div>
                            <Badge className="bg-green-500/20 text-green-300 border-green-400/30">
                              {topic.trend}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Top Performers */}
            <Card className="bg-gradient-to-br from-yellow-900/30 to-orange-900/20 border-yellow-500/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-xl text-white flex items-center">
                  <Crown className="w-5 h-5 mr-2 text-yellow-400" />
                  Top Performers
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {topPerformers.map((performer, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-black/20 rounded-lg">
                      <div>
                        <div className="text-white font-medium">{performer.name}</div>
                        <div className="text-yellow-400 text-sm">{performer.earnings}</div>
                      </div>
                      <Badge className="bg-green-500/20 text-green-300 border-green-400/30">
                        {performer.growth}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Community Guidelines */}
            <Card className="bg-gradient-to-br from-blue-900/30 to-cyan-900/20 border-blue-500/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-xl text-white flex items-center">
                  <Star className="w-5 h-5 mr-2 text-blue-400" />
                  Community Guidelines
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <div>
                      <div className="text-blue-300 font-medium">Be Authentic</div>
                      <div className="text-gray-400 text-xs">Share genuine experiences</div>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-green-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <div>
                      <div className="text-green-300 font-medium">Support Others</div>
                      <div className="text-gray-400 text-xs">Help fellow creators succeed</div>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-purple-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <div>
                      <div className="text-purple-300 font-medium">Share Responsibly</div>
                      <div className="text-gray-400 text-xs">Follow platform guidelines</div>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <div>
                      <div className="text-yellow-300 font-medium">Celebrate Wins</div>
                      <div className="text-gray-400 text-xs">Share your success stories</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="bg-gradient-to-br from-gray-900/40 to-gray-800/30 border-gray-600/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-xl text-white">📊 Your Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Posts Shared:</span>
                    <span className="text-green-400 font-medium">12</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Community Likes:</span>
                    <span className="text-purple-400 font-medium">847</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Followers Gained:</span>
                    <span className="text-blue-400 font-medium">+2.3K</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Engagement Rate:</span>
                    <span className="text-yellow-400 font-medium">8.7%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Custom animations */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-15px) rotate(180deg); }
        }
        
        .animate-float {
          animation: float 8s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}