import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { CheckCircle, Clock, Share2, Home, BarChart3, Copy, TrendingUp, Users, DollarSign, Zap, Star } from 'lucide-react';

interface SubmissionStatusPageProps {
  onReturnHome: () => void;
  onViewDashboard: () => void;
}

export default function SubmissionStatusPage({ onReturnHome, onViewDashboard }: SubmissionStatusPageProps) {
  const handleCopyReferralLink = () => {
    const link = "https://ugccreators.incline.com/ref/user123";
    navigator.clipboard.writeText(link);
    alert('Referral link copied to clipboard!');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Join UGC Creators by Incline',
        text: 'Get paid to create gaming content with your phone!',
        url: 'https://ugccreators.incline.com/ref/user123'
      });
    } else {
      handleCopyReferralLink();
    }
  };

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Enhanced Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20"></div>
        
        {/* Animated particles */}
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.8}s`,
              animationDuration: `${6 + Math.random() * 4}s`
            }}
          >
            <div className="w-3 h-3 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-40 blur-sm"></div>
          </div>
        ))}

        {/* Floating gaming elements */}
        <div className="absolute top-20 right-10 text-6xl animate-bounce delay-100 opacity-30">🎉</div>
        <div className="absolute bottom-32 left-10 text-7xl animate-pulse delay-300 opacity-30">💰</div>
        <div className="absolute top-60 left-20 text-5xl animate-bounce delay-500 opacity-30">🎮</div>
        <div className="absolute bottom-60 right-20 text-4xl animate-pulse delay-700 opacity-30">👑</div>
      </div>

      {/* Header */}
      <header className="relative z-10 p-4 lg:p-6 mb-6 lg:mb-8">
        <div className="text-center">
          <div className="flex items-center justify-center space-x-4 mb-3">
            <span className="text-4xl lg:text-5xl animate-pulse">🎮</span>
            <div className="text-3xl lg:text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              UGC Creators
            </div>
          </div>
          <div className="text-sm text-gray-300 uppercase tracking-wider">Gaming Edition by Incline • Submission Complete</div>
        </div>
      </header>

      <div className="relative z-10 max-w-5xl mx-auto px-4 lg:px-6">
        {/* Success Message */}
        <div className="text-center mb-8 lg:mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 lg:w-24 lg:h-24 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full mb-6 shadow-2xl shadow-green-500/30">
            <CheckCircle className="w-10 h-10 lg:w-12 lg:h-12 text-white" />
          </div>
          <h1 className="text-4xl lg:text-6xl font-bold text-white mb-4">Video Submitted!</h1>
          <p className="text-gray-400 text-lg lg:text-xl max-w-3xl mx-auto leading-relaxed">
            We'll review your video within 48 hours. If approved, payment will be processed automatically to your account.
          </p>
        </div>

        {/* Submission Progress */}
        <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/20 border-purple-500/20 backdrop-blur-sm mb-8 lg:mb-12 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-2xl lg:text-3xl text-white flex items-center">
              <TrendingUp className="w-6 h-6 lg:w-8 lg:h-8 mr-3" />
              Your Creator Progress
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 lg:space-y-8">
            <div>
              <div className="flex justify-between items-center mb-4">
                <span className="text-white text-lg lg:text-xl">Videos Submitted</span>
                <span className="text-purple-300 text-lg lg:text-xl font-bold">1 of 3</span>
              </div>
              <Progress value={33} className="h-4 bg-black/50">
                <div className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all shadow-lg"></div>
              </Progress>
              <p className="text-sm lg:text-base text-gray-400 mt-3">
                Complete 3 videos to unlock maximum performance bonuses!
              </p>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
              <div className="text-center p-4 lg:p-6 bg-black/30 rounded-xl border border-purple-500/20">
                <DollarSign className="w-8 h-8 mx-auto mb-2 text-green-400" />
                <div className="text-2xl lg:text-3xl font-bold text-green-400">£45</div>
                <div className="text-sm lg:text-base text-gray-300">Pending Earnings</div>
              </div>
              <div className="text-center p-4 lg:p-6 bg-black/30 rounded-xl border border-pink-500/20">
                <Users className="w-8 h-8 mx-auto mb-2 text-pink-400" />
                <div className="text-2xl lg:text-3xl font-bold text-pink-400">0</div>
                <div className="text-sm lg:text-base text-gray-300">Referral Earnings</div>
              </div>
              <div className="text-center p-4 lg:p-6 bg-black/30 rounded-xl border border-blue-500/20">
                <Star className="w-8 h-8 mx-auto mb-2 text-blue-400" />
                <div className="text-2xl lg:text-3xl font-bold text-blue-400">0</div>
                <div className="text-sm lg:text-base text-gray-300">Code Uses</div>
              </div>
              <div className="text-center p-4 lg:p-6 bg-black/30 rounded-xl border border-yellow-500/20">
                <Zap className="w-8 h-8 mx-auto mb-2 text-yellow-400" />
                <div className="text-2xl lg:text-3xl font-bold text-yellow-400">1</div>
                <div className="text-sm lg:text-base text-gray-300">Tier Level</div>
              </div>
            </div>

            {/* Current Status */}
            <div className="flex items-center justify-between p-4 lg:p-6 bg-gradient-to-r from-yellow-900/20 to-orange-900/20 rounded-xl border border-yellow-400/20">
              <div className="flex items-center">
                <Clock className="w-6 h-6 text-yellow-400 mr-4" />
                <div>
                  <div className="text-white font-medium text-lg lg:text-xl">Under Review</div>
                  <div className="text-yellow-400 text-sm lg:text-base">Expected approval within 36 hours</div>
                </div>
              </div>
              <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-300 border-yellow-400/30 text-sm lg:text-base px-3 py-2">
                PROCESSING
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Referral Section */}
        <Card className="bg-gradient-to-br from-green-900/20 to-emerald-900/10 border-green-500/20 backdrop-blur-sm mb-8 lg:mb-12 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-2xl lg:text-3xl text-white flex items-center">
              <Share2 className="w-6 h-6 lg:w-8 lg:h-8 mr-3" />
              Invite Friends &amp; Earn More
            </CardTitle>
            <p className="text-gray-400 text-lg lg:text-xl">Get £25 for each friend who joins and submits their first video!</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-black/30 rounded-xl p-4 lg:p-6 border border-green-500/20">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-green-400 font-medium text-xl lg:text-2xl">£25 per referral</div>
                  <div className="text-gray-400 text-sm lg:text-base">No limit on earnings potential</div>
                </div>
                <div className="text-right">
                  <div className="text-3xl lg:text-4xl font-bold text-green-300">0</div>
                  <div className="text-xs lg:text-sm text-gray-400">Successful Referrals</div>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="text-sm lg:text-base text-gray-300">Your personal referral link:</div>
              <div className="flex items-center space-x-3">
                <div className="flex-1 bg-black/50 border border-purple-500/30 rounded-xl px-4 py-3 lg:py-4 text-white text-sm lg:text-base font-mono truncate">
                  https://ugccreators.incline.com/ref/user123
                </div>
                <Button
                  onClick={handleCopyReferralLink}
                  size="sm"
                  variant="outline"
                  className="border-green-400/50 text-green-300 hover:bg-green-500/10 px-4 py-3 lg:py-4"
                >
                  <Copy className="w-4 h-4 lg:w-5 lg:h-5" />
                </Button>
              </div>
            </div>

            <Button
              onClick={handleShare}
              className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white py-6 lg:py-8 text-lg lg:text-xl rounded-full shadow-lg shadow-green-500/25"
            >
              <Share2 className="w-5 h-5 lg:w-6 lg:h-6 mr-3" />
              Share &amp; Earn £25 Each!
            </Button>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="grid md:grid-cols-2 gap-4 lg:gap-6 mb-8 lg:mb-12">
          <Button
            onClick={onReturnHome}
            variant="outline"
            className="border-purple-400/50 text-purple-300 hover:bg-purple-500/10 hover:text-purple-200 py-6 lg:py-8 text-lg lg:text-xl rounded-xl"
          >
            <Home className="w-5 h-5 lg:w-6 lg:h-6 mr-3" />
            Return to Homepage
          </Button>
          
          <Button
            onClick={onViewDashboard}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-6 lg:py-8 text-lg lg:text-xl rounded-xl shadow-lg shadow-purple-500/25"
          >
            <BarChart3 className="w-5 h-5 lg:w-6 lg:h-6 mr-3" />
            View Dashboard Preview
          </Button>
        </div>

        {/* Next Steps */}
        <Card className="bg-gradient-to-br from-gray-900/30 to-gray-800/20 border-gray-600/20 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl lg:text-3xl text-white">🚀 What's Next?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
              <div className="flex items-start">
                <div className="w-3 h-3 bg-purple-400 rounded-full mt-2 mr-4 flex-shrink-0"></div>
                <div>
                  <div className="font-medium text-white text-lg lg:text-xl">Video Review</div>
                  <div className="text-sm lg:text-base text-gray-400 mt-1">Our team will review your content within 48 hours for authenticity and quality</div>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-3 h-3 bg-pink-400 rounded-full mt-2 mr-4 flex-shrink-0"></div>
                <div>
                  <div className="font-medium text-white text-lg lg:text-xl">Payment Processing</div>
                  <div className="text-sm lg:text-base text-gray-400 mt-1">If approved, your earnings will be processed automatically to your account</div>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-3 h-3 bg-green-400 rounded-full mt-2 mr-4 flex-shrink-0"></div>
                <div>
                  <div className="font-medium text-white text-lg lg:text-xl">Create More Content</div>
                  <div className="text-sm lg:text-base text-gray-400 mt-1">Submit up to 3 videos for maximum performance-based earnings</div>
                </div>
              </div>
            </div>

            <div className="mt-8 lg:mt-12 p-4 lg:p-6 bg-gradient-to-r from-blue-900/20 to-purple-900/20 rounded-xl border border-blue-400/20">
              <h3 className="text-blue-400 font-bold text-lg lg:text-xl mb-3">💡 Pro Creator Tips</h3>
              <div className="grid md:grid-cols-2 gap-4 text-sm lg:text-base text-gray-300">
                <div>• Share your referral link on social media for maximum reach</div>
                <div>• Create authentic content for better approval rates</div>
                <div>• Check your email for review updates and bonuses</div>
                <div>• Join our Discord community for creator support</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Custom animations */}
      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-15px) rotate(180deg); }
        }
        
        .animate-float {
          animation: float 8s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}