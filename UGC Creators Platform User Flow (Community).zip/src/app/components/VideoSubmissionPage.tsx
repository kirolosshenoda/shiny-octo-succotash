import React, { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ArrowLeft, Upload, Video, CheckCircle, Play, Lightbulb, Zap, Clock, Smartphone, Trophy, Star } from 'lucide-react';
import { Persona } from '../App';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface VideoSubmissionPageProps {
  persona: Persona;
  onSubmit: () => void;
  onBack: () => void;
}

export default function VideoSubmissionPage({ persona, onSubmit, onBack }: VideoSubmissionPageProps) {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [comment, setComment] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('video/')) {
        alert('Please select video files only!');
        return;
      }
      
      // Validate file size (max 100MB)
      if (file.size > 100 * 1024 * 1024) {
        alert('File too large! Maximum 100MB allowed.');
        return;
      }
      
      setUploadedFile(file);
    }
  };

  const handleRecordNow = () => {
    alert('📱 Tip: Use your phone\'s native camera app to record in vertical (9:16) format for best quality!');
  };

  const handleSubmit = async () => {
    if (!uploadedFile) {
      alert('🎬 Oops! Please upload your gaming video first!');
      return;
    }

    setIsUploading(true);
    
    // Simulate realistic upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setIsUploading(false);
            onSubmit();
          }, 500);
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 200);
  };

  const tips = [
    {
      icon: "📱",
      title: "Vertical Format",
      desc: "9:16 ratio works best on all platforms"
    },
    {
      icon: "💡",
      title: "Good Lighting",
      desc: "Natural light or ring light makes all the difference"
    },
    {
      icon: "🎭",
      title: "Be Authentic",
      desc: "Act as your character naturally"
    },
    {
      icon: "⚡",
      title: "High Energy",
      desc: "Show genuine excitement during win moments!"
    }
  ];

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Enhanced Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20"></div>
        
        {/* Animated particles */}
        {[...Array(10)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.8}s`,
              animationDuration: `${8 + Math.random() * 4}s`
            }}
          >
            <div className="w-4 h-4 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-30 blur-sm"></div>
          </div>
        ))}

        {/* Floating gaming elements */}
        <div className="absolute top-20 left-10 text-5xl animate-bounce delay-100 opacity-40">🎬</div>
        <div className="absolute bottom-32 left-10 text-6xl animate-pulse delay-300 opacity-40">💰</div>
        <div className="absolute top-60 left-20 text-4xl animate-bounce delay-500 opacity-40">🎮</div>
        <div className="absolute bottom-20 right-10 text-5xl animate-pulse delay-700 opacity-40">🏆</div>
      </div>

      {/* Header */}
      <header className="relative z-10 p-4 lg:p-6 mb-6 lg:mb-8">
        <Button
          variant="ghost"
          onClick={onBack}
          className="text-white hover:text-purple-400 hover:bg-purple-500/10 mb-4 lg:mb-6 text-lg group"
        >
          <ArrowLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform" />
          Back to Character
        </Button>
        
        <div className="text-center">
          <div className="flex items-center justify-center space-x-4 mb-3">
            <span className="text-4xl lg:text-5xl animate-pulse">🎬</span>
            <div className="text-3xl lg:text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Action! Create Your Video
            </div>
          </div>
          <div className="text-sm text-gray-300 uppercase tracking-wider">Create Your Gaming Content Masterpiece</div>
        </div>
      </header>

      {/* Enhanced Progress */}
      <div className="relative z-10 max-w-lg mx-auto px-4 lg:px-6 mb-8 lg:mb-12">
        <div className="flex items-center justify-center space-x-4 mb-6">
          <div className="flex items-center">
            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-green-500 rounded-full flex items-center justify-center text-white font-bold shadow-lg">
              ✓
            </div>
            <div className="text-green-300 ml-3 font-semibold text-sm lg:text-base">Registration</div>
          </div>
          <div className="w-12 lg:w-16 h-1 bg-green-500 rounded-full"></div>
          <div className="flex items-center">
            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-green-500 rounded-full flex items-center justify-center text-white font-bold shadow-lg">
              ✓
            </div>
            <div className="text-green-300 ml-3 font-semibold text-sm lg:text-base">Character</div>
          </div>
          <div className="w-12 lg:w-16 h-1 bg-purple-500 rounded-full"></div>
          <div className="flex items-center">
            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold shadow-lg">
              3
            </div>
            <div className="text-white ml-3 font-semibold text-sm lg:text-base">Content</div>
          </div>
        </div>
        <div className="w-full bg-gray-800 rounded-full h-3 shadow-inner">
          <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-3 rounded-full w-full transition-all duration-500 shadow-lg"></div>
        </div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 lg:px-6">
        <div className="text-center mb-8 lg:mb-12">
          <Badge className="bg-gradient-to-r from-red-500 to-pink-500 text-white font-bold text-lg lg:text-xl px-6 py-3 mb-6 animate-pulse">
            🔴 REC - SHOWTIME!
          </Badge>
          <h1 className="text-3xl lg:text-5xl font-bold text-white mb-4">Submit Your Gaming Video</h1>
          <p className="text-gray-400 text-lg lg:text-xl max-w-3xl mx-auto">Record 30-60 seconds as your character. Be creative and authentic!</p>
        </div>

        {/* Current Character Reminder */}
        <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/20 border-purple-500/30 backdrop-blur-sm mb-8 lg:mb-12 shadow-2xl max-w-4xl mx-auto">
          <CardHeader className="pb-4 lg:pb-6">
            <CardTitle className="text-xl lg:text-2xl text-white flex items-center">
              <ImageWithFallback
                src={persona.avatar}
                alt={persona.name}
                className="w-16 h-16 lg:w-20 lg:h-20 rounded-full object-cover mr-4 lg:mr-6 border-3 border-purple-400/50"
              />
              <div>
                <div className="text-xl lg:text-2xl">{persona.name}</div>
                <Badge className="bg-green-500/20 text-green-300 border-green-400/30 mt-2">
                  YOUR ACTIVE CHARACTER
                </Badge>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4 lg:gap-6 text-sm lg:text-base">
              <div className="bg-blue-900/20 border border-blue-400/30 rounded-lg p-4">
                <Badge variant="secondary" className="bg-blue-500/20 text-blue-300 border-blue-400/30 mb-2 text-xs lg:text-sm">
                  🎯 SCENARIO
                </Badge>
                <p className="text-gray-300 leading-relaxed">{persona.scene}</p>
              </div>
              <div className="bg-yellow-900/20 border border-yellow-400/30 rounded-lg p-4">
                <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-300 border-yellow-400/30 mb-2 text-xs lg:text-sm">
                  🏆 WIN REACTION
                </Badge>
                <p className="text-gray-300 leading-relaxed font-medium">{persona.winReaction}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-3 gap-6 lg:gap-8">
          {/* Left Column - Upload Section */}
          <div className="lg:col-span-2">
            <Card className="bg-gradient-to-br from-purple-900/40 to-pink-900/30 border-purple-500/30 backdrop-blur-sm shadow-2xl mb-6 lg:mb-8">
              <CardHeader>
                <CardTitle className="text-2xl lg:text-3xl text-white text-center flex items-center justify-center">
                  <Video className="w-6 h-6 lg:w-8 lg:h-8 mr-3" />
                  Upload Your Gaming Content
                </CardTitle>
                <div className="flex flex-wrap items-center justify-center space-x-2 lg:space-x-4 pt-2">
                  <Badge className="bg-green-500/20 text-green-300 border-green-400/30 text-sm lg:text-base">
                    30-60 seconds
                  </Badge>
                  <Badge className="bg-blue-500/20 text-blue-300 border-blue-400/30 text-sm lg:text-base">
                    Max 100MB
                  </Badge>
                  <Badge className="bg-purple-500/20 text-purple-300 border-purple-400/30 text-sm lg:text-base">
                    Vertical 9:16
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-6 lg:space-y-8">
                {/* Upload Options */}
                <div className="grid md:grid-cols-2 gap-4 lg:gap-6">
                  <div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="video/*"
                      onChange={handleFileUpload}
                      className="hidden"
                      id="video-upload"
                    />
                    <label
                      htmlFor="video-upload"
                      className="flex flex-col items-center justify-center p-6 lg:p-8 border-2 border-dashed border-purple-400/40 rounded-xl hover:border-purple-400/60 cursor-pointer transition-all group bg-gradient-to-br from-purple-900/10 to-pink-900/10 hover:from-purple-900/20 hover:to-pink-900/20"
                    >
                      <Upload className="w-10 h-10 lg:w-12 lg:h-12 text-purple-400 mb-4 group-hover:text-purple-300 transition-colors" />
                      <div className="text-white font-medium mb-2 text-lg lg:text-xl">Upload File</div>
                      <div className="text-gray-400 text-sm lg:text-base text-center leading-relaxed">
                        Choose your gaming video<br/>
                        <span className="text-purple-300">(MP4, MOV, AVI)</span>
                      </div>
                      <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-400/30 mt-3">
                        RECOMMENDED
                      </Badge>
                    </label>
                  </div>

                  <Button
                    onClick={handleRecordNow}
                    variant="outline"
                    className="flex flex-col items-center justify-center p-6 lg:p-8 border-2 border-pink-400/40 text-pink-300 hover:bg-pink-500/10 hover:border-pink-400/60 hover:text-pink-200 h-auto bg-gradient-to-br from-pink-900/10 to-red-900/10 hover:from-pink-900/20 hover:to-red-900/20"
                  >
                    <Smartphone className="w-10 h-10 lg:w-12 lg:h-12 mb-4" />
                    <div className="font-medium mb-2 text-lg lg:text-xl">Record Now</div>
                    <div className="text-sm lg:text-base opacity-75 text-center leading-relaxed">
                      Use your phone's<br/>
                      camera app
                    </div>
                    <Badge className="bg-red-500/20 text-red-300 border-red-400/30 mt-3">
                      MOBILE FIRST
                    </Badge>
                  </Button>
                </div>

                {/* Upload Status */}
                {uploadedFile && (
                  <div className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 border border-green-400/40 rounded-xl p-6">
                    <div className="flex items-start">
                      <CheckCircle className="w-6 h-6 text-green-400 mr-4 mt-1 flex-shrink-0" />
                      <div className="flex-grow">
                        <div className="text-green-300 font-medium text-lg lg:text-xl">Video Ready for Upload! 🚀</div>
                        <div className="text-green-400 text-sm lg:text-base mb-2">{uploadedFile.name}</div>
                        <div className="flex items-center space-x-4 text-xs lg:text-sm">
                          <Badge className="bg-green-500/20 text-green-300 border-green-400/30">
                            {(uploadedFile.size / (1024 * 1024)).toFixed(1)}MB
                          </Badge>
                          <Badge className="bg-blue-500/20 text-blue-300 border-blue-400/30">
                            {uploadedFile.type.split('/')[1].toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Upload Progress */}
                {isUploading && (
                  <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 border border-purple-400/40 rounded-xl p-6">
                    <div className="flex items-center mb-4">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-purple-400 mr-3"></div>
                      <div className="text-white font-medium text-lg">Uploading your gaming masterpiece...</div>
                    </div>
                    <Progress value={uploadProgress} className="h-3 mb-2" />
                    <div className="text-sm text-gray-400">{Math.round(uploadProgress)}% complete</div>
                  </div>
                )}

                {/* Optional Comment */}
                <div>
                  <label className="block text-white font-medium mb-3 text-lg lg:text-xl flex items-center">
                    <Lightbulb className="w-5 h-5 lg:w-6 lg:h-6 mr-2 text-yellow-400" />
                    Video Context (Optional)
                  </label>
                  <Textarea
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Tell us about your creative approach, epic moments, or anything special about this gaming session... 🎮"
                    className="bg-black/50 border-purple-500/30 text-white placeholder:text-gray-400 min-h-[120px] text-base lg:text-lg leading-relaxed"
                  />
                  <p className="text-xs lg:text-sm text-gray-500 mt-2">
                    💡 Tip: Adding context can help with faster approval!
                  </p>
                </div>

                {/* Submit Button */}
                <div className="space-y-4 lg:space-y-6">
                  <Button
                    onClick={handleSubmit}
                    disabled={!uploadedFile || isUploading}
                    className="w-full bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500 hover:from-purple-600 hover:via-pink-600 hover:to-yellow-600 text-white py-6 lg:py-8 text-xl lg:text-2xl rounded-full shadow-2xl shadow-purple-500/50 transform transition-all hover:scale-105 disabled:opacity-50 disabled:transform-none disabled:shadow-none"
                  >
                    {isUploading ? (
                      <>
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white mr-3"></div>
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Zap className="w-6 h-6 mr-3" />
                        SEND FOR REVIEW
                      </>
                    )}
                  </Button>

                  {/* Earning Reminder */}
                  <div className="text-center bg-gradient-to-r from-green-900/30 to-emerald-900/30 border border-green-400/30 rounded-xl p-6">
                    <div className="text-4xl lg:text-5xl mb-2">💰</div>
                    <div className="text-green-300 font-bold text-2xl lg:text-3xl">You'll earn £20+ if approved!</div>
                    <div className="text-green-400 text-sm lg:text-base mt-2 flex items-center justify-center">
                      <Clock className="w-4 h-4 mr-1" />
                      Typical review: &lt;48 hours
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Tips & Guidelines */}
          <div className="space-y-6">
            {/* Pro Tips */}
            <Card className="bg-gradient-to-br from-yellow-900/30 to-orange-900/20 border-yellow-500/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-lg lg:text-xl text-white flex items-center">
                  <Trophy className="w-5 h-5 lg:w-6 lg:h-6 mr-2 text-yellow-400" />
                  Pro Gaming Tips
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {tips.map((tip, index) => (
                    <div key={index} className="flex items-start space-x-3 p-3 bg-black/20 rounded-lg border border-yellow-400/20">
                      <div className="text-xl lg:text-2xl">{tip.icon}</div>
                      <div>
                        <div className="text-yellow-300 font-medium text-sm lg:text-base">{tip.title}</div>
                        <div className="text-gray-400 text-xs lg:text-sm leading-relaxed">{tip.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Content Guidelines */}
            <Card className="bg-gradient-to-br from-blue-900/30 to-cyan-900/20 border-blue-500/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-lg lg:text-xl text-white flex items-center">
                  <Star className="w-5 h-5 lg:w-6 lg:h-6 mr-2 text-blue-400" />
                  Content Guidelines
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm lg:text-base">
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-green-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <div>
                      <div className="text-green-300 font-medium">Be Natural</div>
                      <div className="text-gray-400 text-xs lg:text-sm">Act how you'd genuinely react</div>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-purple-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <div>
                      <div className="text-purple-300 font-medium">Clear Audio</div>
                      <div className="text-gray-400 text-xs lg:text-sm">Minimal background noise</div>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-pink-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <div>
                      <div className="text-pink-300 font-medium">Show the Screen</div>
                      <div className="text-gray-400 text-xs lg:text-sm">Include the win moment clearly</div>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <div>
                      <div className="text-yellow-300 font-medium">Genuine Reaction</div>
                      <div className="text-gray-400 text-xs lg:text-sm">Your happiness is contagious!</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="bg-gradient-to-br from-gray-900/40 to-gray-800/30 border-gray-600/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-lg lg:text-xl text-white">📊 Quick Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm lg:text-base">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Average Approval:</span>
                    <span className="text-green-400 font-medium">97.2%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Review Time:</span>
                    <span className="text-yellow-400 font-medium">&lt;36h</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Average Payout:</span>
                    <span className="text-purple-400 font-medium">£45.80</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Active Creators:</span>
                    <span className="text-blue-400 font-medium">3,247</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Custom animations */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-15px) rotate(180deg); }
        }
        
        .animate-float {
          animation: float 8s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}