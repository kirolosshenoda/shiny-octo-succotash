import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { ArrowLeft, RefreshCw, Play, Zap, Trophy, Dice1, Heart, Star, Crown, Target, MessageCircle, Mail, Phone } from 'lucide-react';
import { UserData, Persona } from '../App';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface PersonaAssignmentPageProps {
  userData: UserData;
  onUserDataUpdate: (data: Partial<UserData>) => void;
  onAccept: () => void;
  onBack: () => void;
}

const personas: Persona[] = [
  {
    id: 1,
    name: "Sophie – The Busy Mum 🎮",
    description: "32, busy mum of two. Her rare 'me time' happens after 10pm with a relaxing gaming session.",
    scene: "Kids finally asleep, settles on the sofa with a cuppa and opens her favourite casino app.",
    motivation: "Much-needed mental break from the chaos of motherhood.",
    winReaction: "Quiet but genuine smile – 'Finally, something just for me!' Secretly plans a little treat.",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=250&q=80"
  },
  {
    id: 2,
    name: "James – The London Commuter 🚇",
    description: "28, solicitor with a 45-minute tube journey to Central London every morning.",
    scene: "On the packed Northern line, gets a seat, opens slots app and hits a massive win!",
    motivation: "Entertainment before the workday stress kicks in.",
    winReaction: "Eyes light up, almost jumps from his seat – 'This is going to be a brilliant day!'",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=250&q=80"
  },
  {
    id: 3,
    name: "Emma – The Brighton Commuter 🚢",
    description: "29, graphic designer taking the evening train home after a long day in London.",
    scene: "Sunset train journey, plays a few spins and wins big while watching the countryside.",
    motivation: "Perfect way to unwind after a stressful day.",
    winReaction: "Leans back with a satisfied sigh – 'What a perfect end to the day!'",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616c-art&auto=format&fit=crop&w=250&q=80"
  },
  {
    id: 4,
    name: "Rachel – The Office Warrior 💼",
    description: "35, executive assistant having the most hectic Monday imaginable.",
    scene: "Lunch break at her desk, opens casino app for a quick escape – instant jackpot!",
    motivation: "Desperate mental escape from midday office chaos.",
    winReaction: "Quiet fist pump and whispers 'Yes!' – already planning that weekend spa day.",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=250&q=80"
  },
  {
    id: 5,
    name: "Danny – The Football Fan ⚽",
    description: "26, die-hard Arsenal supporter watching the most boring 0-0 draw ever.",
    scene: "Half-time, no goals, opens betting app and wins BIG just as Arsenal finally score!",
    motivation: "Fighting the boredom during football's dull moments.",
    winReaction: "Leaps off the sofa celebrating both the goal AND the win – 'This is my day!'",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=250&q=80"
  },
  {
    id: 6,
    name: "Mike – The Weekend Dad 🎣",
    description: "42, finally gets some alone time while the family's at the shops.",
    scene: "Fishing by the canal, no bites for hours, opens casino app and hits a lovely win.",
    motivation: "Pure relaxation away from family responsibilities.",
    winReaction: "Content smile, settles back in his chair – 'Don't need the fish to bite today!'",
    avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=250&q=80"
  },
  {
    id: 7,
    name: "Margaret – The Digital Nan 👵",
    description: "67, recently retired and discovering the joys of online gaming.",
    scene: "After tending her garden, settles with a G&T and plays on her iPad – massive win!",
    motivation: "Entertainment in retirement plus a bit of extra pocket money.",
    winReaction: "Claps her hands and laughs out loud – 'The grandkids are getting bigger Christmas presents!'",
    avatar: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=250&q=80"
  },
  {
    id: 8,
    name: "Tyler – The Night Owl 🦉",
    description: "24, just rolled in from the clubs at 3am, still buzzing with energy.",
    scene: "Can't sleep after a big night out, opens casino app to wind down and hits jackpot!",
    motivation: "Post-party comedown with adrenaline still pumping.",
    winReaction: "Jumps up and dances around the flat – 'The night's not over yet!'",
    avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?ixlib=rb-4.0.3&auto=format&fit=crop&w=250&q=80"
  },
  {
    id: 9,
    name: "Sarah – The Business Traveller ✈️",
    description: "30, alone in a Premier Inn in Birmingham, missing home comforts.",
    scene: "Strange hotel room, feeling homesick, plays mobile casino and gets a lovely surprise win.",
    motivation: "Combating loneliness and homesickness on business trips.",
    winReaction: "Relieved smile – 'Thank you universe, I needed that boost today!'",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=250&q=80"
  },
  {
    id: 10,
    name: "Ben – The First Date Nerves 💕",
    description: "33, waiting nervously at a Pret for a Bumble date who might not show.",
    scene: "Anxious and possibly being stood up, opens casino app to calm nerves – big win!",
    motivation: "Distraction from first date anxiety and potential rejection.",
    winReaction: "Genuine smile returns to his face – 'If she doesn't show, at least I've won something!'",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=250&q=80"
  }
];

export default function PersonaAssignmentPage({ userData, onUserDataUpdate, onAccept, onBack }: PersonaAssignmentPageProps) {
  const [currentPersona, setCurrentPersona] = useState<Persona | null>(null);
  const [rerollsLeft, setRerollsLeft] = useState(2);
  const [personasViewed, setPersonasViewed] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [floatingIndex, setFloatingIndex] = useState(0);
  const [showContactDialog, setShowContactDialog] = useState(false);

  const floatingEmojis = ["💎", "🎰", "🏆", "💰", "⚡", "🎮", "🔥", "💸", "🎲", "👑"];

  const getRandomPersona = () => {
    const randomIndex = Math.floor(Math.random() * personas.length);
    return personas[randomIndex];
  };

  useEffect(() => {
    if (!currentPersona) {
      setTimeout(() => {
        const newPersona = getRandomPersona();
        setCurrentPersona(newPersona);
        setPersonasViewed(1);
        setShowDetails(true);
      }, 1000);
    }
    
    const interval = setInterval(() => {
      setFloatingIndex((prev) => (prev + 1) % floatingEmojis.length);
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);

  const handleReroll = () => {
    if (rerollsLeft > 0) {
      setIsAnimating(true);
      setShowDetails(false);
      setTimeout(() => {
        const newPersona = getRandomPersona();
        setCurrentPersona(newPersona);
        setRerollsLeft(prev => prev - 1);
        setPersonasViewed(prev => prev + 1);
        setIsAnimating(false);
        setTimeout(() => {
          setShowDetails(true);
          // Show contact dialog after viewing 3rd persona
          if (personasViewed + 1 >= 3) {
            setTimeout(() => setShowContactDialog(true), 1000);
          }
        }, 500);
      }, 800);
    }
  };

  const handleAccept = () => {
    onUserDataUpdate({ assignedPersona: currentPersona });
    onAccept();
  };

  const handleContactUs = () => {
    // In a real app, this would open a contact form or support chat
    setShowContactDialog(false);
    alert('📞 Thank you! Our team will be in touch within 24 hours to help you find the perfect persona. Check your email for next steps!');
  };

  if (!currentPersona) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center relative overflow-hidden">
        {/* Loading background effect */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20"></div>
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="absolute animate-pulse"
              style={{
                left: `${20 + i * 15}%`,
                top: `${20 + (i % 2) * 40}%`,
                animationDelay: `${i * 0.5}s`
              }}
            >
              <div className="text-6xl opacity-20">{floatingEmojis[i]}</div>
            </div>
          ))}
        </div>
        
        <Card className="bg-gradient-to-br from-purple-900/40 to-pink-900/30 border-purple-500/30 backdrop-blur-xl p-8 lg:p-12 text-center relative z-10 shadow-2xl max-w-md mx-4">
          <div className="text-8xl animate-spin mb-6">🎲</div>
          <h2 className="text-2xl lg:text-3xl text-white mb-4 font-bold">Generating Your Gaming Character...</h2>
          <p className="text-gray-400 text-lg">Finding the perfect persona for authentic content creation!</p>
          <div className="flex justify-center mt-6">
            <div className="flex space-x-2">
              {[...Array(3)].map((_, i) => (
                <div
                  key={i}
                  className="w-3 h-3 bg-purple-400 rounded-full animate-bounce"
                  style={{ animationDelay: `${i * 0.2}s` }}
                ></div>
              ))}
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Contact Dialog */}
      <Dialog open={showContactDialog} onOpenChange={setShowContactDialog}>
        <DialogContent className="bg-gradient-to-br from-purple-900/50 to-pink-900/40 border-purple-500/40 backdrop-blur-xl text-white max-w-md mx-4">
          <DialogHeader className="text-center">
            <DialogTitle className="text-2xl font-bold mb-4 flex items-center justify-center">
              <MessageCircle className="w-6 h-6 mr-3 text-purple-400" />
              Need Help Finding Your Perfect Character?
            </DialogTitle>
            <DialogDescription className="text-gray-300 text-lg leading-relaxed">
              No worries! Our team can help you create a custom persona that feels completely authentic to you.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 mt-6">
            <div className="bg-blue-900/20 border border-blue-400/30 rounded-xl p-4">
              <h4 className="text-blue-300 font-bold mb-2 flex items-center">
                <Star className="w-4 h-4 mr-2" />
                What We'll Do:
              </h4>
              <ul className="text-gray-300 text-sm space-y-1">
                <li>• Create a custom persona based on your personality</li>
                <li>• Provide tailored gaming scenarios</li>
                <li>• Give you authentic reaction guidance</li>
                <li>• Ensure maximum earning potential</li>
              </ul>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={handleContactUs}
                className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white py-6 text-lg rounded-xl"
              >
                <Mail className="w-4 h-4 mr-2" />
                Email Us
              </Button>
              <Button
                onClick={handleContactUs}
                variant="outline"
                className="border-green-400/50 text-green-300 hover:bg-green-500/10 py-6 text-lg rounded-xl"
              >
                <Phone className="w-4 h-4 mr-2" />
                WhatsApp
              </Button>
            </div>

            <Button
              onClick={() => setShowContactDialog(false)}
              variant="ghost"
              className="w-full text-gray-400 hover:text-white py-3"
            >
              I'll choose from these options
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Enhanced Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20"></div>
        
        {/* Animated particles */}
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.8}s`,
              animationDuration: `${8 + Math.random() * 4}s`
            }}
          >
            <div className="w-4 h-4 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-30 blur-sm"></div>
          </div>
        ))}

        {/* Large floating elements */}
        <div className="absolute top-20 left-10 text-7xl animate-bounce opacity-30">{floatingEmojis[floatingIndex]}</div>
        <div className="absolute top-40 right-20 text-6xl animate-pulse delay-100 opacity-30">{floatingEmojis[(floatingIndex + 1) % floatingEmojis.length]}</div>
        <div className="absolute bottom-40 left-20 text-8xl animate-bounce delay-200 opacity-30">{floatingEmojis[(floatingIndex + 2) % floatingEmojis.length]}</div>
        <div className="absolute bottom-20 right-10 text-7xl animate-pulse delay-300 opacity-30">{floatingEmojis[(floatingIndex + 3) % floatingEmojis.length]}</div>
        <div className="absolute top-60 right-40 text-5xl animate-bounce delay-400 opacity-30">{floatingEmojis[(floatingIndex + 4) % floatingEmojis.length]}</div>
      </div>

      {/* Header */}
      <header className="relative z-10 p-4 lg:p-6 mb-6 lg:mb-8">
        <Button
          variant="ghost"
          onClick={onBack}
          className="text-white hover:text-purple-400 hover:bg-purple-500/10 mb-4 lg:mb-6 text-lg group"
        >
          <ArrowLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform" />
          Back to Registration
        </Button>
        
        <div className="text-center">
          <div className="flex items-center justify-center space-x-4 mb-3">
            <span className="text-4xl lg:text-5xl animate-pulse">🎭</span>
            <div className="text-3xl lg:text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Character Selection
            </div>
          </div>
          <div className="text-sm text-gray-300 uppercase tracking-wider">Choose Your Gaming Avatar • UK Edition</div>
        </div>
      </header>

      {/* Enhanced Progress */}
      <div className="relative z-10 max-w-lg mx-auto px-4 lg:px-6 mb-8 lg:mb-12">
        <div className="flex items-center justify-center space-x-4 mb-6">
          <div className="flex items-center">
            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-green-500 rounded-full flex items-center justify-center text-white font-bold shadow-lg">
              ✓
            </div>
            <div className="text-green-300 ml-3 font-semibold text-sm lg:text-base">Registration</div>
          </div>
          <div className="w-12 lg:w-16 h-1 bg-green-500 rounded-full"></div>
          <div className="flex items-center">
            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold shadow-lg">
              2
            </div>
            <div className="text-white ml-3 font-semibold text-sm lg:text-base">Character</div>
          </div>
          <div className="w-12 lg:w-16 h-1 bg-gray-700 rounded-full"></div>
          <div className="flex items-center">
            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-gray-700 rounded-full flex items-center justify-center text-gray-400 font-bold">
              3
            </div>
            <div className="text-gray-400 ml-3 text-sm lg:text-base">Content</div>
          </div>
        </div>
        <div className="w-full bg-gray-800 rounded-full h-3 shadow-inner">
          <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-3 rounded-full w-2/3 transition-all duration-500 shadow-lg"></div>
        </div>
        
        {/* Persona Counter */}
        <div className="text-center mt-4">
          <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-400/30">
            Persona {personasViewed} of 3 • {rerollsLeft} rerolls remaining
          </Badge>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 lg:px-6">
        <div className="text-center mb-8 lg:mb-12">
          <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-black font-bold text-lg lg:text-xl px-6 py-3 mb-6 shadow-lg">
            🎲 CHARACTER GENERATED!
          </Badge>
          <h1 className="text-4xl lg:text-6xl font-bold text-white mb-4">Meet Your Gaming Persona</h1>
          <p className="text-gray-400 text-xl lg:text-2xl max-w-3xl mx-auto">
            This character will inspire your authentic content creation. Embody them naturally!
          </p>
        </div>

        <Card className={`bg-gradient-to-br from-purple-900/50 to-pink-900/40 border-purple-500/40 backdrop-blur-xl shadow-2xl transition-all duration-1000 ${isAnimating ? 'scale-95 opacity-50 rotate-1' : 'scale-100 opacity-100'} ${showDetails ? 'animate-in' : ''}`}>
          <CardHeader className="text-center pb-6 lg:pb-8">
            <div className="flex justify-center mb-6 lg:mb-8">
              <div className="relative">
                <ImageWithFallback
                  src={currentPersona.avatar}
                  alt={currentPersona.name}
                  className="w-40 h-40 lg:w-48 lg:h-48 rounded-full object-cover border-4 border-purple-400/60 shadow-2xl shadow-purple-500/50 transition-all duration-500"
                />
                <div className="absolute -top-4 -right-4">
                  <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-black font-bold text-lg px-3 py-2 rounded-full shadow-lg">
                    🏆 ACTIVE
                  </Badge>
                </div>
                <div className="absolute -bottom-4 -left-4">
                  <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-3 py-2 rounded-full shadow-lg">
                    ✓ VERIFIED
                  </Badge>
                </div>
                <div className="absolute top-4 -left-4">
                  <Crown className="w-8 h-8 text-yellow-400 animate-pulse" />
                </div>
              </div>
            </div>
            <CardTitle className="text-3xl lg:text-4xl text-white mb-4 font-bold">{currentPersona.name}</CardTitle>
            <p className="text-gray-300 text-lg lg:text-xl leading-relaxed max-w-3xl mx-auto">{currentPersona.description}</p>
          </CardHeader>

          <CardContent className="space-y-6 lg:space-y-8">
            {/* Enhanced Gaming Stats */}
            <div className="grid grid-cols-4 gap-4 lg:gap-6 mb-6 lg:mb-8">
              <div className="bg-purple-900/40 border border-purple-400/40 rounded-xl p-3 lg:p-4 text-center backdrop-blur-sm">
                <Target className="w-5 h-5 lg:w-6 lg:h-6 mx-auto mb-2 text-purple-400" />
                <div className="text-purple-300 text-xs lg:text-sm font-medium">Authenticity</div>
                <div className="text-white font-bold text-sm lg:text-base">Expert</div>
              </div>
              <div className="bg-green-900/40 border border-green-400/40 rounded-xl p-3 lg:p-4 text-center backdrop-blur-sm">
                <div className="text-2xl lg:text-3xl mb-2">💰</div>
                <div className="text-green-300 text-xs lg:text-sm font-medium">Earnings</div>
                <div className="text-white font-bold text-sm lg:text-base">£20+</div>
              </div>
              <div className="bg-yellow-900/40 border border-yellow-400/40 rounded-xl p-3 lg:p-4 text-center backdrop-blur-sm">
                <Star className="w-5 h-5 lg:w-6 lg:h-6 mx-auto mb-2 text-yellow-400" />
                <div className="text-yellow-300 text-xs lg:text-sm font-medium">Difficulty</div>
                <div className="text-white font-bold text-sm lg:text-base">Easy</div>
              </div>
              <div className="bg-pink-900/40 border border-pink-400/40 rounded-xl p-3 lg:p-4 text-center backdrop-blur-sm">
                <Trophy className="w-5 h-5 lg:w-6 lg:h-6 mx-auto mb-2 text-pink-400" />
                <div className="text-pink-300 text-xs lg:text-sm font-medium">Success Rate</div>
                <div className="text-white font-bold text-sm lg:text-base">98%</div>
              </div>
            </div>

            {/* Enhanced Character Details */}
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 border border-blue-400/40 rounded-xl p-4 lg:p-6 backdrop-blur-sm">
                <Badge variant="secondary" className="bg-blue-500/20 text-blue-300 border-blue-400/30 mb-3 flex items-center w-fit text-sm lg:text-base px-3 py-1">
                  <Zap className="w-4 h-4 lg:w-5 lg:h-5 mr-2" />
                  Gaming Scenario
                </Badge>
                <p className="text-gray-300 leading-relaxed text-base lg:text-lg">{currentPersona.scene}</p>
              </div>

              <div className="bg-gradient-to-r from-pink-900/30 to-red-900/30 border border-pink-400/40 rounded-xl p-4 lg:p-6 backdrop-blur-sm">
                <Badge variant="secondary" className="bg-pink-500/20 text-pink-300 border-pink-400/30 mb-3 flex items-center w-fit text-sm lg:text-base px-3 py-1">
                  <Heart className="w-4 h-4 lg:w-5 lg:h-5 mr-2" />
                  Motivation
                </Badge>
                <p className="text-gray-300 leading-relaxed text-base lg:text-lg">{currentPersona.motivation}</p>
              </div>

              <div className="bg-gradient-to-r from-yellow-900/30 to-orange-900/30 border border-yellow-400/40 rounded-xl p-4 lg:p-6 backdrop-blur-sm">
                <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-300 border-yellow-400/30 mb-3 flex items-center w-fit text-sm lg:text-base px-3 py-1">
                  <Trophy className="w-4 h-4 lg:w-5 lg:h-5 mr-2" />
                  Win Reaction
                </Badge>
                <p className="text-gray-300 leading-relaxed text-base lg:text-lg font-medium">{currentPersona.winReaction}</p>
              </div>
            </div>

            {/* Enhanced Example Videos Preview */}
            <div className="bg-gray-900/50 border border-gray-600/40 rounded-xl p-4 lg:p-6 backdrop-blur-sm">
              <Badge variant="secondary" className="bg-gray-700/50 text-gray-300 border-gray-600/40 mb-4 flex items-center w-fit text-sm lg:text-base px-3 py-1">
                <Play className="w-4 h-4 lg:w-5 lg:h-5 mr-2" />
                Reference Examples
              </Badge>
              <div className="grid grid-cols-3 gap-3 lg:gap-4">
                <div className="bg-gradient-to-br from-purple-900/60 to-pink-900/60 rounded-xl p-3 lg:p-4 border border-purple-500/30 text-center">
                  <div className="aspect-video bg-black/40 rounded-lg flex items-center justify-center mb-3">
                    <Play className="w-8 h-8 lg:w-10 lg:h-10 text-white/70" />
                  </div>
                  <p className="text-xs lg:text-sm text-purple-300 font-medium">Pre-Game Setup</p>
                  <p className="text-xs text-gray-400">Character introduction</p>
                </div>
                <div className="bg-gradient-to-br from-green-900/60 to-emerald-900/60 rounded-xl p-3 lg:p-4 border border-green-500/30 text-center">
                  <div className="aspect-video bg-black/40 rounded-lg flex items-center justify-center mb-3">
                    <Play className="w-8 h-8 lg:w-10 lg:h-10 text-white/70" />
                  </div>
                  <p className="text-xs lg:text-sm text-green-300 font-medium">Big Win Moment</p>
                  <p className="text-xs text-gray-400">Authentic reaction</p>
                </div>
                <div className="bg-gradient-to-br from-yellow-900/60 to-orange-900/60 rounded-xl p-3 lg:p-4 border border-yellow-500/30 text-center">
                  <div className="aspect-video bg-black/40 rounded-lg flex items-center justify-center mb-3">
                    <Play className="w-8 h-8 lg:w-10 lg:h-10 text-white/70" />
                  </div>
                  <p className="text-xs lg:text-sm text-yellow-300 font-medium">Post-Win Chat</p>
                  <p className="text-xs text-gray-400">Character outro</p>
                </div>
              </div>
              <p className="text-sm text-gray-500 mt-4 text-center">
                💡 <strong>Pro Tip:</strong> Stay true to your character for maximum authenticity and engagement!
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Action Buttons */}
        <div className="flex flex-col lg:flex-row gap-4 lg:gap-6 mt-8 lg:mt-12">
          <Button
            onClick={handleReroll}
            disabled={rerollsLeft === 0 || isAnimating}
            variant="outline"
            className="flex-1 border-purple-400/50 text-purple-300 hover:bg-purple-500/10 hover:text-purple-200 py-6 lg:py-8 text-lg lg:text-xl disabled:opacity-50 rounded-xl backdrop-blur-sm"
          >
            <RefreshCw className={`w-5 h-5 lg:w-6 lg:h-6 mr-3 ${isAnimating ? 'animate-spin' : ''}`} />
            {isAnimating ? 'Generating New Character...' : rerollsLeft > 0 ? `Reroll Character (${rerollsLeft} remaining)` : 'No rerolls left'}
          </Button>
          
          <Button
            onClick={handleAccept}
            disabled={isAnimating}
            className="flex-1 bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500 hover:from-purple-600 hover:via-pink-600 hover:to-yellow-600 text-white py-6 lg:py-8 text-lg lg:text-xl rounded-xl shadow-2xl shadow-purple-500/30 transform transition-all hover:scale-105 disabled:opacity-50 relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 to-pink-400/20 animate-pulse"></div>
            <Dice1 className="w-5 h-5 lg:w-6 lg:h-6 mr-3 relative z-10" />
            <span className="relative z-10">ACCEPT &amp; CREATE CONTENT</span>
          </Button>
        </div>

        {/* Contact Help Button */}
        {personasViewed >= 2 && (
          <div className="text-center mt-6">
            <Button
              onClick={() => setShowContactDialog(true)}
              variant="ghost"
              className="text-gray-400 hover:text-white border border-gray-600/40 hover:border-purple-400/40 px-6 py-3 rounded-xl"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              None of these feel right? Get a custom persona
            </Button>
          </div>
        )}

        {/* Enhanced Gaming Tip */}
        <Card className="bg-gradient-to-r from-gray-900/50 to-gray-800/40 border-gray-600/40 backdrop-blur-sm mt-6 lg:mt-8 shadow-xl">
          <CardContent className="p-6 lg:p-8 text-center">
            <div className="flex justify-center mb-4">
              <div className="bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full p-3">
                <Trophy className="w-6 h-6 lg:w-8 lg:h-8 text-black" />
              </div>
            </div>
            <p className="text-yellow-400 font-bold text-xl lg:text-2xl mb-4">🎮 Pro Creator Tip</p>
            <p className="text-gray-300 text-lg lg:text-xl leading-relaxed max-w-4xl mx-auto">
              Authenticity is absolutely key to success! The more naturally you embody your character, 
              the better your engagement rates and earnings potential. Remember: you're a gamer having genuine fun, 
              not an actor putting on a performance! 🚀
            </p>
            <div className="flex flex-wrap justify-center space-x-4 lg:space-x-6 mt-6 text-sm lg:text-base">
              <div className="text-green-400">✓ Natural reactions</div>
              <div className="text-blue-400">✓ Genuine excitement</div>
              <div className="text-purple-400">✓ Authentic personality</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Custom animations */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(180deg); }
        }
        
        .animate-float {
          animation: float 8s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}