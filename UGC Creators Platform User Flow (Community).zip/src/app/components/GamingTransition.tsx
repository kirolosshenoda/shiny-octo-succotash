import React, { useState, useEffect } from 'react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { TrendingUp, Users, DollarSign, Trophy, Star, Zap, Target, Crown, Gamepad2, BarChart3 } from 'lucide-react';

interface GamingTransitionProps {
  isVisible: boolean;
  title: string;
  subtitle: string;
  onComplete: () => void;
  duration?: number; // in milliseconds
}

export default function GamingTransition({ 
  isVisible, 
  title, 
  subtitle, 
  onComplete, 
  duration = 4000 
}: GamingTransitionProps) {
  const [progress, setProgress] = useState(0);
  const [currentStat, setCurrentStat] = useState(0);
  const [loadingMessages, setLoadingMessages] = useState<string[]>([]);
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);

  const gameStats = [
    { label: "Active Players", value: "47,832", icon: Users, color: "text-blue-400", targetValue: 47832 },
    { label: "Total Wins Today", value: "£234,567", icon: DollarSign, color: "text-green-400", targetValue: 234567 },
    { label: "Live Games", value: "2,847", icon: Gamepad2, color: "text-purple-400", targetValue: 2847 },
    { label: "Success Rate", value: "94.2%", icon: Target, color: "text-yellow-400", targetValue: 94.2 },
    { label: "Top Streamers", value: "1,456", icon: Crown, color: "text-orange-400", targetValue: 1456 },
    { label: "Conversions", value: "8,921", icon: TrendingUp, color: "text-pink-400", targetValue: 8921 }
  ];

  const messages = [
    "🎮 Connecting to gaming network...",
    "⚡ Loading real-time player data...",
    "🏆 Fetching top performer stats...",
    "💰 Calculating earnings potential...",
    "📊 Analyzing conversion rates...",
    "🎯 Optimizing creator matches...",
    "🚀 Preparing your dashboard...",
    "✨ Almost ready to go live!"
  ];

  useEffect(() => {
    if (!isVisible) return;

    setProgress(0);
    setCurrentStat(0);
    setLoadingMessages([]);
    setCurrentMessageIndex(0);

    // Progress animation
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          setTimeout(onComplete, 500);
          return 100;
        }
        return prev + (100 / (duration / 50));
      });
    }, 50);

    // Stats cycling
    const statsInterval = setInterval(() => {
      setCurrentStat(prev => (prev + 1) % gameStats.length);
    }, 600);

    // Messages cycling
    const messageInterval = setInterval(() => {
      setCurrentMessageIndex(prev => {
        if (prev < messages.length - 1) {
          setLoadingMessages(prevMessages => [...prevMessages, messages[prev + 1]]);
          return prev + 1;
        }
        return prev;
      });
    }, duration / messages.length);

    // Initialize first message
    setLoadingMessages([messages[0]]);

    return () => {
      clearInterval(progressInterval);
      clearInterval(statsInterval);
      clearInterval(messageInterval);
    };
  }, [isVisible, duration, onComplete]);

  if (!isVisible) return null;

  const currentStatData = gameStats[currentStat];

  return (
    <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
      {/* Enhanced Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/30 via-black to-pink-900/30"></div>
        
        {/* Advanced grid pattern with gaming effects */}
        <div className="absolute inset-0 opacity-20">
          <div 
            className="absolute inset-0"
            style={{
              backgroundImage: `
                linear-gradient(rgba(139, 92, 246, 0.4) 1px, transparent 1px),
                linear-gradient(90deg, rgba(139, 92, 246, 0.4) 1px, transparent 1px),
                linear-gradient(rgba(236, 72, 153, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(236, 72, 153, 0.3) 1px, transparent 1px)
              `,
              backgroundSize: '40px 40px, 40px 40px, 80px 80px, 80px 80px',
              animation: 'grid-move 20s linear infinite, grid-fade 6s ease-in-out infinite alternate'
            }}
          />
        </div>

        {/* Animated gaming particles */}
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float opacity-60"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.3}s`,
              animationDuration: `${4 + Math.random() * 6}s`
            }}
          >
            <div className={`${
              i % 4 === 0 ? 'w-4 h-4' : i % 4 === 1 ? 'w-3 h-3' : i % 4 === 2 ? 'w-2 h-2' : 'w-1 h-1'
            } bg-gradient-to-r from-purple-400 to-pink-400 rounded-full blur-sm`}></div>
          </div>
        ))}

        {/* Floating gaming elements */}
        {['💰', '🎮', '🏆', '⚡', '🎲', '👑', '🔥', '💎'].map((emoji, i) => (
          <div
            key={i}
            className="absolute animate-bounce opacity-40"
            style={{
              left: `${10 + (i % 4) * 20}%`,
              top: `${15 + Math.floor(i / 4) * 30}%`,
              animationDelay: `${i * 0.5}s`,
              animationDuration: `${2 + Math.random() * 2}s`,
              fontSize: `${1.5 + Math.random() * 1.5}rem`
            }}
          >
            {emoji}
          </div>
        ))}
      </div>

      {/* Main Content */}
      <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
        {/* Header */}
        <div className="mb-12">
          <div className="text-6xl lg:text-8xl mb-6 animate-pulse">🎮</div>
          <h1 className="text-4xl lg:text-6xl font-bold mb-4 bg-gradient-to-r from-purple-400 via-pink-400 to-yellow-400 bg-clip-text text-transparent">
            {title}
          </h1>
          <p className="text-xl lg:text-2xl text-gray-400 mb-8">{subtitle}</p>
        </div>

        {/* Live Gaming Stats */}
        <Card className="bg-gradient-to-br from-purple-900/50 to-pink-900/40 border-purple-500/40 backdrop-blur-xl shadow-2xl mb-8">
          <CardContent className="p-8">
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {gameStats.map((stat, index) => (
                <div 
                  key={index}
                  className={`text-center p-4 rounded-xl border transition-all duration-500 ${
                    index === currentStat 
                      ? 'bg-gradient-to-br from-purple-600/30 to-pink-600/30 border-purple-400/50 scale-110 shadow-lg' 
                      : 'bg-black/20 border-gray-600/30'
                  }`}
                >
                  <stat.icon className={`w-8 h-8 mx-auto mb-2 ${stat.color} ${index === currentStat ? 'animate-pulse' : ''}`} />
                  <div className={`text-2xl font-bold ${stat.color} ${index === currentStat ? 'animate-pulse' : ''}`}>
                    {index === currentStat ? (
                      <CountingNumber target={stat.targetValue} suffix={stat.value.includes('%') ? '%' : stat.value.includes('£') ? '' : ''} prefix={stat.value.includes('£') ? '£' : ''} />
                    ) : (
                      stat.value
                    )}
                  </div>
                  <div className="text-sm text-gray-400">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Featured Current Stat */}
            <div className="bg-gradient-to-r from-yellow-900/30 to-orange-900/30 border border-yellow-400/40 rounded-xl p-6 mb-6">
              <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-400/30 mb-3">
                🔥 LIVE DATA
              </Badge>
              <div className="flex items-center justify-center space-x-4">
                <currentStatData.icon className={`w-12 h-12 ${currentStatData.color} animate-pulse`} />
                <div>
                  <div className={`text-4xl font-bold ${currentStatData.color}`}>
                    <CountingNumber 
                      target={currentStatData.targetValue} 
                      suffix={currentStatData.value.includes('%') ? '%' : ''} 
                      prefix={currentStatData.value.includes('£') ? '£' : ''}
                    />
                  </div>
                  <div className="text-gray-300">{currentStatData.label}</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <span className="text-gray-400">Loading Progress</span>
            <span className="text-purple-400 font-bold">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-4 bg-gray-800/50">
            <div className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500 rounded-full transition-all shadow-lg"></div>
          </Progress>
        </div>

        {/* Loading Messages */}
        <div className="space-y-3 max-h-40 overflow-hidden">
          {loadingMessages.slice(-5).map((message, index) => (
            <div 
              key={index}
              className={`text-lg transition-all duration-500 ${
                index === loadingMessages.slice(-5).length - 1 
                  ? 'text-white font-semibold scale-105' 
                  : 'text-gray-400 opacity-70'
              }`}
              style={{
                animationDelay: `${index * 0.1}s`
              }}
            >
              {message}
            </div>
          ))}
        </div>

        {/* Gaming Elements */}
        <div className="mt-8 flex justify-center space-x-6">
          {[Trophy, Star, Crown].map((Icon, index) => (
            <Icon 
              key={index}
              className={`w-8 h-8 ${
                index === 0 ? 'text-yellow-400' : 
                index === 1 ? 'text-purple-400' : 'text-pink-400'
              } animate-pulse`}
              style={{ animationDelay: `${index * 0.3}s` }}
            />
          ))}
        </div>
      </div>

      {/* Enhanced Custom CSS */}
      <style>{`
        @keyframes grid-move {
          0% { transform: translate(0, 0); }
          100% { transform: translate(40px, 40px); }
        }
        
        @keyframes grid-fade {
          0%, 100% { opacity: 0.1; }
          50% { opacity: 0.3; }
        }
        
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          33% { transform: translateY(-10px) rotate(120deg); }
          66% { transform: translateY(-5px) rotate(240deg); }
        }
        
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}

// Counting Number Component
function CountingNumber({ target, duration = 1500, prefix = '', suffix = '' }: {
  target: number;
  duration?: number;
  prefix?: string;
  suffix?: string;
}) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let startTime: number;
    let animationFrame: number;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Easing function for smooth animation
      const easeOut = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(target * easeOut));

      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [target, duration]);

  const formatNumber = (num: number) => {
    if (suffix === '%') return num.toFixed(1);
    return num.toLocaleString();
  };

  return <span>{prefix}{formatNumber(count)}{suffix}</span>;
}