import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Play, Users, DollarSign, Star, Zap, TrendingUp, Heart, MessageCircle, Share2, Crown, Target, Smartphone } from 'lucide-react';
import LiveCreatorsModal from './LiveCreatorsModal';
import HotCreatorsModal from './HotCreatorsModal';

interface LandingPageTikTokProps {
  onGetStarted: () => void;
}

export default function LandingPageTikTok({ onGetStarted }: LandingPageTikTokProps) {
  const [scrollY, setScrollY] = useState(0);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const testimonials = [
    {
      name: "Sophie_Creates",
      handle: "@sophie_creates",
      followers: "180K",
      earnings: "£2,400/month",
      content: "Went from 50K to 180K followers in 3 months! The gaming content performs SO much better than my usual stuff. Best decision ever! 💸",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616c-art&auto=format&fit=crop&w=100&q=80",
      platform: "TikTok"
    },
    {
      name: "JackLondon_",
      handle: "@jacklondon_",
      followers: "95K",
      earnings: "£1,800/month",
      content: "The personas they give you are GENIUS! My gaming character feels so natural and my engagement rate went from 3% to 12%! 🎮",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      platform: "Instagram"
    },
    {
      name: "EmmaVibes",
      handle: "@emmavibes",
      followers: "220K",
      earnings: "£3,200/month",
      content: "I was struggling to monetize my content. Now I'm earning more than my day job just posting casino wins! The algorithm LOVES this content! ✨",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      platform: "TikTok"
    }
  ];

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      {/* TikTok-Style Background */}
      <div className="absolute inset-0">
        {/* Gradient background with TikTok colors */}
        <div className="absolute inset-0 bg-gradient-to-br from-black via-purple-900/30 to-pink-900/40"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-cyan-900/10 to-transparent"></div>
        
        {/* Moving gradient orbs */}
        <div className="absolute top-20 left-20 w-96 h-96 bg-gradient-to-r from-pink-500/20 to-purple-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-40 right-20 w-80 h-80 bg-gradient-to-r from-cyan-500/15 to-blue-500/15 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/3 w-72 h-72 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 rounded-full blur-3xl animate-pulse delay-2000"></div>

        {/* Floating TikTok-style elements */}
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float opacity-60"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.5}s`,
              animationDuration: `${4 + Math.random() * 4}s`
            }}
          >
            <div className="w-2 h-2 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full blur-sm"></div>
          </div>
        ))}

        {/* TikTok-style floating icons */}
        <div className="absolute top-32 right-32 text-6xl animate-bounce delay-100 opacity-20">📱</div>
        <div className="absolute bottom-40 left-32 text-5xl animate-pulse delay-300 opacity-20">🎬</div>
        <div className="absolute top-1/2 right-20 text-4xl animate-bounce delay-500 opacity-20">💎</div>
        <div className="absolute bottom-60 right-1/3 text-7xl animate-pulse delay-700 opacity-20">🚀</div>
      </div>

      {/* Header */}
      <header className="relative z-10 p-4 lg:p-6">
        <div className="flex justify-between items-center max-w-7xl mx-auto">
          <div className="flex items-center space-x-3">
            <div className="text-3xl lg:text-4xl">🎮</div>
            <div>
              <div className="text-xl lg:text-2xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                UGC Creators
              </div>
              <div className="text-xs text-gray-400">by Incline</div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <LiveCreatorsModal>
              <Button className="bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white px-4 lg:px-6 py-2 lg:py-3 text-sm lg:text-base animate-pulse">
                🔴 LIVE NOW
              </Button>
            </LiveCreatorsModal>
            <HotCreatorsModal>
              <Button variant="outline" className="border-orange-400/50 text-orange-300 hover:bg-orange-500/10 px-4 lg:px-6 py-2 lg:py-3 text-sm lg:text-base">
                🔥 HOT
              </Button>
            </HotCreatorsModal>
          </div>
        </div>
      </header>

      {/* Hero Section - TikTok Style */}
      <section className="relative z-10 text-center py-12 lg:py-20 px-4 lg:px-6">
        <div className="max-w-6xl mx-auto">
          {/* Mobile-first badge */}
          <Badge className="bg-gradient-to-r from-pink-500 to-purple-500 text-white font-bold text-base lg:text-xl px-6 lg:px-8 py-2 lg:py-3 mb-6 lg:mb-8 shadow-2xl shadow-pink-500/30 animate-bounce">
            📱 TIKTOK CREATORS WANTED
          </Badge>
          
          <h1 className="text-4xl lg:text-7xl xl:text-8xl font-black mb-6 lg:mb-8 leading-tight">
            <span className="bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent block">
              Go Viral with
            </span>
            <span className="bg-gradient-to-r from-yellow-400 via-orange-400 to-red-400 bg-clip-text text-transparent block">
              Gaming Content
            </span>
          </h1>
          
          <p className="text-xl lg:text-3xl text-gray-300 mb-8 lg:mb-12 max-w-4xl mx-auto leading-relaxed">
            Turn your TikTok following into <span className="text-green-400 font-bold">£20-£220+ per video</span> with authentic casino gaming content that the algorithm absolutely loves! 🎰
          </p>

          {/* TikTok-style stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8 mb-12 lg:mb-16">
            <div className="bg-gradient-to-br from-pink-900/40 to-purple-900/30 border border-pink-400/30 rounded-2xl p-4 lg:p-6 backdrop-blur-sm">
              <div className="text-3xl lg:text-4xl mb-2">📱</div>
              <div className="text-xl lg:text-2xl font-bold text-pink-400">47M+</div>
              <div className="text-sm lg:text-base text-gray-400">Views Generated</div>
            </div>
            <div className="bg-gradient-to-br from-purple-900/40 to-blue-900/30 border border-purple-400/30 rounded-2xl p-4 lg:p-6 backdrop-blur-sm">
              <div className="text-3xl lg:text-4xl mb-2">💰</div>
              <div className="text-xl lg:text-2xl font-bold text-green-400">£89K+</div>
              <div className="text-sm lg:text-base text-gray-400">Paid This Month</div>
            </div>
            <div className="bg-gradient-to-br from-cyan-900/40 to-teal-900/30 border border-cyan-400/30 rounded-2xl p-4 lg:p-6 backdrop-blur-sm">
              <div className="text-3xl lg:text-4xl mb-2">🔥</div>
              <div className="text-xl lg:text-2xl font-bold text-orange-400">3,247</div>
              <div className="text-sm lg:text-base text-gray-400">Active Creators</div>
            </div>
            <div className="bg-gradient-to-br from-yellow-900/40 to-orange-900/30 border border-yellow-400/30 rounded-2xl p-4 lg:p-6 backdrop-blur-sm">
              <div className="text-3xl lg:text-4xl mb-2">⚡</div>
              <div className="text-xl lg:text-2xl font-bold text-yellow-400">94%</div>
              <div className="text-sm lg:text-base text-gray-400">Go Viral</div>
            </div>
          </div>

          <Button
            onClick={onGetStarted}
            className="bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 hover:from-pink-600 hover:via-purple-600 hover:to-cyan-600 text-white text-xl lg:text-2xl px-12 lg:px-16 py-6 lg:py-8 rounded-2xl font-bold shadow-2xl shadow-purple-500/40 transform hover:scale-105 transition-all duration-300 animate-pulse"
          >
            🚀 START EARNING NOW
          </Button>
          
          <p className="text-sm lg:text-base text-gray-400 mt-4">
            ✅ Free to join • ✅ No upfront costs • ✅ Instant approval for 50K+ followers
          </p>
        </div>
      </section>

      {/* Testimonial Carousel */}
      <section className="relative z-10 py-12 lg:py-20 px-4 lg:px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-5xl font-bold mb-4 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
              Real TikTok Creators, Real Results
            </h2>
            <p className="text-xl text-gray-400">See how creators are scaling their income with gaming content</p>
          </div>

          <Card className="bg-gradient-to-br from-gray-900/50 to-purple-900/30 border-purple-400/30 backdrop-blur-xl shadow-2xl overflow-hidden">
            <CardContent className="p-8 lg:p-12">
              <div className="flex items-center space-x-4 mb-6">
                <ImageWithFallback
                  src={testimonials[currentTestimonial].avatar}
                  alt={testimonials[currentTestimonial].name}
                  className="w-16 h-16 lg:w-20 lg:h-20 rounded-full object-cover border-3 border-pink-400"
                />
                <div>
                  <h3 className="text-xl lg:text-2xl font-bold text-white">{testimonials[currentTestimonial].name}</h3>
                  <div className="flex items-center space-x-4 text-gray-400">
                    <span>{testimonials[currentTestimonial].handle}</span>
                    <Badge className={`${testimonials[currentTestimonial].platform === 'TikTok' ? 'bg-pink-500/20 text-pink-300 border-pink-400/30' : 'bg-purple-500/20 text-purple-300 border-purple-400/30'}`}>
                      {testimonials[currentTestimonial].platform}
                    </Badge>
                  </div>
                </div>
              </div>
              
              <blockquote className="text-xl lg:text-2xl text-gray-300 mb-6 leading-relaxed italic">
                "{testimonials[currentTestimonial].content}"
              </blockquote>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-400">{testimonials[currentTestimonial].followers}</div>
                    <div className="text-sm text-gray-400">Followers</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400">{testimonials[currentTestimonial].earnings}</div>
                    <div className="text-sm text-gray-400">Monthly Earnings</div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {testimonials.map((_, index) => (
                    <div
                      key={index}
                      className={`w-3 h-3 rounded-full transition-all ${
                        index === currentTestimonial ? 'bg-pink-400' : 'bg-gray-600'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* How It Works - TikTok Style */}
      <section className="relative z-10 py-12 lg:py-20 px-4 lg:px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
              From Zero to Viral in 3 Steps
            </h2>
            <p className="text-xl text-gray-400">The exact system 3,247+ TikTok creators use to monetize</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                step: "1",
                title: "Get Your Gaming Persona",
                description: "We create an authentic UK gaming character that fits your personality perfectly. No fake acting required!",
                icon: "🎭",
                color: "from-pink-500 to-purple-500"
              },
              {
                step: "2", 
                title: "Create Viral Content",
                description: "Film yourself playing with genuine reactions. The more authentic, the better it performs. Algorithm gold! ⚡",
                icon: "📱",
                color: "from-purple-500 to-blue-500"
              },
              {
                step: "3",
                title: "Get Paid Big",
                description: "Earn £20-£220+ per video based on followers, plus commission on every signup through your promo code!",
                icon: "💰",
                color: "from-blue-500 to-green-500"
              }
            ].map((item, index) => (
              <Card key={index} className="bg-gradient-to-br from-gray-900/50 to-black/50 border-purple-400/30 backdrop-blur-sm hover:scale-105 transition-all duration-300 overflow-hidden">
                <div className={`h-2 bg-gradient-to-r ${item.color}`}></div>
                <CardHeader className="text-center p-8">
                  <div className="text-6xl mb-4">{item.icon}</div>
                  <div className={`text-4xl font-bold mb-4 bg-gradient-to-r ${item.color} bg-clip-text text-transparent`}>
                    Step {item.step}
                  </div>
                  <CardTitle className="text-2xl text-white mb-4">{item.title}</CardTitle>
                </CardHeader>
                <CardContent className="px-8 pb-8">
                  <p className="text-gray-300 text-lg leading-relaxed">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Content Examples */}
      <section className="relative z-10 py-12 lg:py-20 px-4 lg:px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold mb-4 bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
              Content That Actually Goes Viral
            </h2>
            <p className="text-xl text-gray-400">Examples of the gaming content creators are posting</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Big Win Reaction",
                views: "2.3M views",
                engagement: "340K likes",
                description: "Authentic celebration after hitting jackpot",
                thumbnail: "https://images.unsplash.com/photo-1596838132731-3301c3fd4317?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
              },
              {
                title: "Gaming Setup Tour", 
                views: "890K views",
                engagement: "125K likes",
                description: "Behind-the-scenes of creator gaming setup",
                thumbnail: "https://images.unsplash.com/photo-1579952363873-27d3bfad9c0d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
              },
              {
                title: "First Time Playing",
                views: "1.7M views", 
                engagement: "267K likes",
                description: "Nervous excitement trying casino games",
                thumbnail: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
              }
            ].map((video, index) => (
              <Card key={index} className="bg-gradient-to-br from-gray-900/50 to-purple-900/30 border-purple-400/20 backdrop-blur-sm hover:scale-105 transition-all duration-300 overflow-hidden group">
                <div className="relative">
                  <ImageWithFallback
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="w-16 h-16 text-white" />
                  </div>
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-red-500/90 text-white">
                      VIRAL
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-white mb-2">{video.title}</h3>
                  <p className="text-gray-400 text-sm mb-4">{video.description}</p>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center text-blue-400">
                      <Play className="w-4 h-4 mr-1" />
                      {video.views}
                    </div>
                    <div className="flex items-center text-red-400">
                      <Heart className="w-4 h-4 mr-1" />
                      {video.engagement}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="relative z-10 py-16 lg:py-24 px-4 lg:px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-gradient-to-br from-purple-900/50 to-pink-900/40 border border-purple-400/40 rounded-3xl p-8 lg:p-12 backdrop-blur-xl shadow-2xl">
            <div className="text-6xl lg:text-8xl mb-6">🚀</div>
            <h2 className="text-4xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
              Ready to Go Viral?
            </h2>
            <p className="text-xl lg:text-2xl text-gray-300 mb-8 leading-relaxed">
              Join 3,247+ TikTok creators already earning £20-£220+ per video with authentic gaming content!
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="text-center">
                <div className="text-3xl lg:text-4xl font-bold text-green-400 mb-2">£89K+</div>
                <div className="text-gray-400">Paid This Month</div>
              </div>
              <div className="text-center">
                <div className="text-3xl lg:text-4xl font-bold text-purple-400 mb-2">47M+</div>
                <div className="text-gray-400">Views Generated</div>
              </div>
              <div className="text-center">
                <div className="text-3xl lg:text-4xl font-bold text-pink-400 mb-2">94%</div>
                <div className="text-gray-400">Success Rate</div>
              </div>
            </div>

            <Button
              onClick={onGetStarted}
              className="bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 hover:from-pink-600 hover:via-purple-600 hover:to-cyan-600 text-white text-xl lg:text-2xl px-12 lg:px-16 py-6 lg:py-8 rounded-2xl font-bold shadow-2xl shadow-purple-500/40 transform hover:scale-110 transition-all duration-300 mb-4"
            >
              🎮 JOIN NOW & START EARNING
            </Button>
            
            <p className="text-sm lg:text-base text-gray-400">
              ⚡ Instant approval for creators with 50K+ followers • 💰 First payment within 7 days
            </p>
          </div>
        </div>
      </section>

      {/* Custom animations */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-15px) rotate(180deg); }
        }
        
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}