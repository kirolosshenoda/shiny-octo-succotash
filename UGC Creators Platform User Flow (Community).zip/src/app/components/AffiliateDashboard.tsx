import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { ArrowLeft, TrendingUp, Users, DollarSign, Copy, ExternalLink, Target, Zap, Crown, Star, BarChart3, MessageCircle } from 'lucide-react';

interface AffiliateDashboardProps {
  onBack: () => void;
  onCommunity: () => void;
}

export default function AffiliateDashboard({ onBack, onCommunity }: AffiliateDashboardProps) {
  const handleCopyLink = () => {
    const link = "https://ugccreators.incline.com/ref/user123";
    navigator.clipboard.writeText(link);
    alert('Referral link copied to clipboard!');
  };

  const campaignData = [
    { campaign: 'Mega Casino Slots', clicks: 1247, conversions: 89, earnings: '£890.00', rate: '7.1%' },
    { campaign: 'Sports Betting Pro', clicks: 856, conversions: 67, earnings: '£670.00', rate: '7.8%' },
    { campaign: 'Live Casino Games', clicks: 1432, conversions: 112, earnings: '£1,120.00', rate: '7.8%' },
    { campaign: 'Poker Championship', clicks: 623, conversions: 41, earnings: '£410.00', rate: '6.6%' }
  ];

  const totalEarnings = campaignData.reduce((sum, campaign) => sum + parseFloat(campaign.earnings.replace('£', '').replace(',', '')), 0);
  const totalClicks = campaignData.reduce((sum, campaign) => sum + campaign.clicks, 0);
  const totalConversions = campaignData.reduce((sum, campaign) => sum + campaign.conversions, 0);
  const overallRate = ((totalConversions / totalClicks) * 100).toFixed(1);

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Enhanced Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20"></div>
        
        {/* Animated particles */}
        {[...Array(10)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.8}s`,
              animationDuration: `${8 + Math.random() * 4}s`
            }}
          >
            <div className="w-3 h-3 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-30 blur-sm"></div>
          </div>
        ))}

        {/* Floating gaming elements */}
        <div className="absolute top-20 right-10 text-6xl animate-bounce delay-100 opacity-30">📊</div>
        <div className="absolute bottom-32 left-10 text-7xl animate-pulse delay-300 opacity-30">💰</div>
        <div className="absolute top-60 left-20 text-5xl animate-bounce delay-500 opacity-30">🎮</div>
        <div className="absolute bottom-60 right-20 text-4xl animate-pulse delay-700 opacity-30">👑</div>
      </div>

      {/* Header */}
      <header className="relative z-10 p-4 lg:p-6 mb-6 lg:mb-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <Button
            variant="ghost"
            onClick={onBack}
            className="text-white hover:text-purple-400 hover:bg-purple-500/10 text-lg group"
          >
            <ArrowLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform" />
            Back to Status
          </Button>
          
          <Button
            onClick={onCommunity}
            className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-6 py-3 rounded-xl shadow-lg transition-all hover:scale-105"
          >
            <MessageCircle className="w-5 h-5 mr-2" />
            Join Community
          </Button>
        </div>
        
        <div className="text-center mt-4">
          <div className="flex items-center justify-center space-x-4 mb-3">
            <span className="text-4xl lg:text-5xl">📊</span>
            <div className="text-3xl lg:text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Creator Dashboard
            </div>
          </div>
          <div className="text-sm text-gray-300 uppercase tracking-wider">Performance Analytics &amp; Earnings Hub</div>
        </div>
      </header>

      <div className="relative z-10 max-w-7xl mx-auto px-4 lg:px-6">
        {/* Preview Notice */}
        <Card className="bg-gradient-to-r from-yellow-900/20 to-orange-900/20 border-yellow-400/20 backdrop-blur-sm mb-8 lg:mb-12 shadow-xl">
          <CardContent className="p-4 lg:p-6 text-center">
            <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-300 border-yellow-400/30 mb-3 text-sm lg:text-base px-4 py-2">
              DASHBOARD PREVIEW
            </Badge>
            <p className="text-yellow-200 text-lg lg:text-xl mb-2">
              Full dashboard access unlocked once your content generates £1,000 in total conversions.
            </p>
            <p className="text-yellow-400 text-sm lg:text-base">
              This preview shows what your performance analytics will look like!
            </p>
          </CardContent>
        </Card>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8 mb-8 lg:mb-12">
          <Card className="bg-gradient-to-br from-green-900/30 to-emerald-900/20 border-green-500/20 backdrop-blur-sm">
            <CardContent className="p-4 lg:p-8 text-center">
              <DollarSign className="w-8 h-8 lg:w-12 lg:h-12 text-green-400 mx-auto mb-3 lg:mb-4" />
              <div className="text-2xl lg:text-4xl font-bold text-green-300">£{totalEarnings.toLocaleString()}</div>
              <div className="text-green-400 text-sm lg:text-base">Total Earnings</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-900/30 to-cyan-900/20 border-blue-500/20 backdrop-blur-sm">
            <CardContent className="p-4 lg:p-8 text-center">
              <Users className="w-8 h-8 lg:w-12 lg:h-12 text-blue-400 mx-auto mb-3 lg:mb-4" />
              <div className="text-2xl lg:text-4xl font-bold text-blue-300">{totalConversions}</div>
              <div className="text-blue-400 text-sm lg:text-base">Total Conversions</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/20 border-purple-500/20 backdrop-blur-sm">
            <CardContent className="p-4 lg:p-8 text-center">
              <TrendingUp className="w-8 h-8 lg:w-12 lg:h-12 text-purple-400 mx-auto mb-3 lg:mb-4" />
              <div className="text-2xl lg:text-4xl font-bold text-purple-300">{totalClicks.toLocaleString()}</div>
              <div className="text-purple-400 text-sm lg:text-base">Total Clicks</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-900/30 to-red-900/20 border-orange-500/20 backdrop-blur-sm">
            <CardContent className="p-4 lg:p-8 text-center">
              <Target className="w-8 h-8 lg:w-12 lg:h-12 text-orange-400 mx-auto mb-3 lg:mb-4" />
              <div className="text-2xl lg:text-4xl font-bold text-orange-300">{overallRate}%</div>
              <div className="text-orange-400 text-sm lg:text-base">Conversion Rate</div>
            </CardContent>
          </Card>
        </div>

        {/* Community Showcase */}
        <Card className="bg-gradient-to-br from-blue-900/30 to-purple-900/20 border-blue-500/20 backdrop-blur-sm mb-8 lg:mb-12 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-2xl lg:text-3xl text-white flex items-center">
              <MessageCircle className="w-6 h-6 lg:w-8 lg:h-8 mr-3 text-blue-400" />
              Creators Community Highlights
            </CardTitle>
            <p className="text-gray-400 text-lg">See what fellow creators are sharing and connect with the community!</p>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6 mb-6">
              <div className="bg-black/30 rounded-xl p-4 text-center border border-blue-400/20">
                <div className="text-3xl mb-2">🎉</div>
                <div className="text-2xl font-bold text-blue-400">1,856</div>
                <div className="text-sm text-gray-400">Posts This Week</div>
              </div>
              <div className="bg-black/30 rounded-xl p-4 text-center border border-green-400/20">
                <div className="text-3xl mb-2">🏆</div>
                <div className="text-2xl font-bold text-green-400">£89K</div>
                <div className="text-sm text-gray-400">Earnings Shared</div>
              </div>
              <div className="bg-black/30 rounded-xl p-4 text-center border border-purple-400/20">
                <div className="text-3xl mb-2">⭐</div>
                <div className="text-2xl font-bold text-purple-400">456</div>
                <div className="text-sm text-gray-400">Success Stories</div>
              </div>
            </div>
            
            <div className="text-center">
              <Button
                onClick={onCommunity}
                className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-8 py-4 text-lg rounded-xl shadow-lg transition-all hover:scale-105"
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                Join the Community
              </Button>
              <p className="text-gray-400 text-sm mt-3">
                Share your wins, get tips, and connect with 3,247+ active creators!
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Referral Link */}
        <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/20 border-purple-500/20 backdrop-blur-sm mb-8 lg:mb-12 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-2xl lg:text-3xl text-white">🎁 Your Personal Promo Code</CardTitle>
            <p className="text-gray-400 text-lg lg:text-xl">Share this trackable link to earn £10 per signup + commission on conversions</p>
          </CardHeader>
          <CardContent>
            <div className="grid lg:grid-cols-3 gap-4 lg:gap-6 mb-6">
              <div className="bg-black/30 rounded-xl p-4 lg:p-6 text-center border border-green-400/20">
                <div className="text-2xl lg:text-3xl font-bold text-green-400">USER123</div>
                <div className="text-sm lg:text-base text-gray-400 mt-1">Your Promo Code</div>
              </div>
              <div className="bg-black/30 rounded-xl p-4 lg:p-6 text-center border border-blue-400/20">
                <div className="text-2xl lg:text-3xl font-bold text-blue-400">20%</div>
                <div className="text-sm lg:text-base text-gray-400 mt-1">User Discount</div>
              </div>
              <div className="bg-black/30 rounded-xl p-4 lg:p-6 text-center border border-purple-400/20">
                <div className="text-2xl lg:text-3xl font-bold text-purple-400">47</div>
                <div className="text-sm lg:text-base text-gray-400 mt-1">Code Uses Today</div>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <div className="flex-1 bg-black/50 border border-purple-500/30 rounded-xl px-4 py-3 lg:py-4 text-white font-mono text-sm lg:text-base">
                https://ugccreators.incline.com/ref/user123
              </div>
              <Button
                onClick={handleCopyLink}
                className="bg-purple-500 hover:bg-purple-600 text-white px-4 lg:px-6 py-3 lg:py-4"
              >
                <Copy className="w-4 h-4 lg:w-5 lg:h-5 mr-2" />
                Copy
              </Button>
              <Button
                variant="outline"
                className="border-purple-400/50 text-purple-300 hover:bg-purple-500/10 px-4 lg:px-6 py-3 lg:py-4"
              >
                <ExternalLink className="w-4 h-4 lg:w-5 lg:h-5 mr-2" />
                Share
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Campaign Performance Table */}
        <Card className="bg-gradient-to-br from-gray-900/30 to-gray-800/20 border-gray-600/20 backdrop-blur-sm mb-8 lg:mb-12 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-2xl lg:text-3xl text-white flex items-center">
              <BarChart3 className="w-6 h-6 lg:w-8 lg:h-8 mr-3" />
              Campaign Performance
            </CardTitle>
            <p className="text-gray-400 text-lg">Detailed breakdown of your gaming content performance</p>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700">
                    <TableHead className="text-gray-300 text-base lg:text-lg">Campaign</TableHead>
                    <TableHead className="text-gray-300 text-base lg:text-lg">Clicks</TableHead>
                    <TableHead className="text-gray-300 text-base lg:text-lg">Conversions</TableHead>
                    <TableHead className="text-gray-300 text-base lg:text-lg">Rate</TableHead>
                    <TableHead className="text-gray-300 text-base lg:text-lg text-right">Earnings</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {campaignData.map((row, index) => (
                    <TableRow key={index} className="border-gray-700 hover:bg-gray-800/50">
                      <TableCell className="text-white font-medium text-sm lg:text-base">{row.campaign}</TableCell>
                      <TableCell className="text-gray-300 text-sm lg:text-base">{row.clicks.toLocaleString()}</TableCell>
                      <TableCell className="text-gray-300 text-sm lg:text-base">
                        <Badge variant="secondary" className="bg-green-500/20 text-green-300 border-green-400/30">
                          {row.conversions}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-300 text-sm lg:text-base">
                        <Badge variant="secondary" className="bg-blue-500/20 text-blue-300 border-blue-400/30">
                          {row.rate}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right text-green-400 font-medium text-sm lg:text-base">{row.earnings}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Payout Information */}
        <div className="grid lg:grid-cols-2 gap-6 lg:gap-8 mb-8 lg:mb-12">
          <Card className="bg-gradient-to-br from-green-900/30 to-emerald-900/20 border-green-500/20 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-xl lg:text-2xl text-white flex items-center">
                <Crown className="w-6 h-6 lg:w-8 lg:h-8 mr-3 text-green-400" />
                Performance Payout Structure
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-300 text-sm lg:text-base">Base Video Rate:</span>
                <span className="text-green-400 font-bold text-sm lg:text-base">£20-£100+</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300 text-sm lg:text-base">Follower Bonus:</span>
                <span className="text-green-400 font-bold text-sm lg:text-base">£0.02-£0.12 each</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300 text-sm lg:text-base">Code Commission:</span>
                <span className="text-green-400 font-bold text-sm lg:text-base">£10 per use</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-300 text-sm lg:text-base">Referral Bonus:</span>
                <span className="text-green-400 font-bold text-sm lg:text-base">£25 each</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-900/30 to-cyan-900/20 border-blue-500/20 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-xl lg:text-2xl text-white flex items-center">
                <DollarSign className="w-6 h-6 lg:w-8 lg:h-8 mr-3 text-blue-400" />
                Next Payout
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="text-3xl lg:text-4xl font-bold text-blue-300 mb-2">£{totalEarnings.toLocaleString()}</div>
                <div className="text-blue-400 text-sm lg:text-base">Available for withdrawal</div>
                <div className="text-xs lg:text-sm text-gray-400 mt-2">Processed every Friday at 5pm GMT</div>
              </div>
              <Button className="w-full bg-blue-500 hover:bg-blue-600 text-white py-3 lg:py-4 text-sm lg:text-base">
                Request Payout
              </Button>
              <div className="text-xs lg:text-sm text-gray-500 text-center">
                Minimum payout: £50 • No fees • 1-2 business days
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tips & Help */}
        <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/20 border-purple-500/20 backdrop-blur-sm shadow-2xl">
          <CardHeader>
            <CardTitle className="text-2xl lg:text-3xl text-white flex items-center">
              <Star className="w-6 h-6 lg:w-8 lg:h-8 mr-3 text-purple-400" />
              Maximise Your Creator Earnings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid lg:grid-cols-2 gap-6 lg:gap-8">
              <div>
                <h4 className="text-purple-300 font-medium mb-4 text-lg lg:text-xl">Content Strategy:</h4>
                <ul className="space-y-2 text-gray-300 text-sm lg:text-base">
                  <li>• Post consistently across all your social platforms</li>
                  <li>• Use trending hashtags and popular gaming music</li>
                  <li>• Authentic reactions always perform best</li>
                  <li>• Try different gaming scenarios and characters</li>
                  <li>• Engage with your audience's comments and questions</li>
                </ul>
              </div>
              <div>
                <h4 className="text-pink-300 font-medium mb-4 text-lg lg:text-xl">Growth Strategy:</h4>
                <ul className="space-y-2 text-gray-300 text-sm lg:text-base">
                  <li>• Share your promo code across multiple platforms</li>
                  <li>• Target gaming communities and forums</li>
                  <li>• Explain the benefits clearly to your audience</li>
                  <li>• Use your personal success story as social proof</li>
                  <li>• Join our community for creator support and tips</li>
                </ul>
              </div>
            </div>

            <div className="mt-8 p-4 lg:p-6 bg-gradient-to-r from-yellow-900/20 to-orange-900/20 rounded-xl border border-yellow-400/20">
              <h4 className="text-yellow-400 font-bold text-lg lg:text-xl mb-3 flex items-center">
                <Zap className="w-5 h-5 lg:w-6 lg:h-6 mr-2" />
                Pro Creator Bonus Tips
              </h4>
              <div className="grid md:grid-cols-2 gap-4 text-sm lg:text-base text-gray-300">
                <div>✨ Create video series for better engagement</div>
                <div>🎯 Focus on high-converting gaming content</div>
                <div>📊 Monitor your analytics for optimization</div>
                <div>🤝 Collaborate with other gaming creators</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Custom animations */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-15px) rotate(180deg); }
        }
        
        .animate-float {
          animation: float 8s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}