import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Play, Users, DollarSign, Star, Zap, TrendingUp, Clock, Eye, ThumbsUp, BarChart3, Video, Mic, Camera } from 'lucide-react';
import LiveCreatorsModal from './LiveCreatorsModal';
import HotCreatorsModal from './HotCreatorsModal';

interface LandingPageYouTubeProps {
  onGetStarted: () => void;
}

export default function LandingPageYouTube({ onGetStarted }: LandingPageYouTubeProps) {
  const [scrollY, setScrollY] = useState(0);
  const [activeTab, setActiveTab] = useState(0);
  const [currentCase, setCurrentCase] = useState(0);

  const caseStudies = [
    {
      name: "Gaming with Marcus",
      channel: "Marcus Manchester Gaming",
      subscribers: "420K",
      monthlyRevenue: "£4,800",
      growth: "+67%",
      content: "I was struggling to monetize my gaming channel. UGC Creators gave me a character and storyline that my audience absolutely loves. Revenue went from £800 to £4,800/month!",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      beforeAfter: {
        before: { views: "45K", revenue: "£800", retention: "34%" },
        after: { views: "180K", revenue: "£4,800", retention: "67%" }
      }
    },
    {
      name: "Sophie's Gaming World",
      channel: "Sophie Creates Gaming",
      subscribers: "280K", 
      monthlyRevenue: "£3,200",
      growth: "+89%",
      content: "The personas are incredible! My gaming character feels so natural that I forget I'm 'acting'. My retention rate doubled and sponsorship deals started flowing in!",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616c-art&auto=format&fit=crop&w=100&q=80",
      beforeAfter: {
        before: { views: "28K", revenue: "£600", retention: "29%" },
        after: { views: "95K", revenue: "£3,200", retention: "54%" }
      }
    },
    {
      name: "Alex Gaming Channel",
      channel: "Alex Plays Everything",
      subscribers: "156K",
      monthlyRevenue: "£2,400", 
      growth: "+112%",
      content: "From 500 views per video to 50K+! The gaming content format they provided completely transformed my channel. Best investment I've ever made!",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      beforeAfter: {
        before: { views: "1.2K", revenue: "£120", retention: "22%" },
        after: { views: "52K", revenue: "£2,400", retention: "48%" }
      }
    }
  ];

  const contentTypes = [
    {
      title: "Casino Gaming Series",
      description: "10-20 minute episodes of authentic casino gameplay with your character",
      earnings: "£50-£150 per video",
      icon: Video,
      examples: ["Slot Machine Adventures", "Big Win Compilations", "Strategy Breakdowns"]
    },
    {
      title: "Gaming Tutorials",
      description: "Educational content teaching casino games with personality",
      earnings: "£30-£120 per video", 
      icon: Mic,
      examples: ["Beginner's Guides", "Pro Tips Series", "Game Explanations"]
    },
    {
      title: "Reaction Content",
      description: "React to other gaming content while staying in character",
      earnings: "£25-£100 per video",
      icon: Camera,
      examples: ["Big Win Reactions", "Game Reviews", "Trend Commentary"]
    }
  ];

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentCase((prev) => (prev + 1) % caseStudies.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      {/* YouTube-Style Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-red-900/20 to-orange-900/30"></div>
        <div className="absolute inset-0 bg-gradient-to-tl from-transparent via-purple-900/10 to-transparent"></div>
        
        {/* Professional grid overlay */}
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              linear-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255, 255, 255, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px'
          }}
        />

        {/* Floating professional elements */}
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float opacity-40"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.8}s`,
              animationDuration: `${8 + Math.random() * 4}s`
            }}
          >
            <div className="w-3 h-3 bg-gradient-to-r from-red-400 to-orange-400 rounded-full blur-sm"></div>
          </div>
        ))}

        {/* YouTube-style floating icons */}
        <div className="absolute top-40 right-20 text-5xl animate-pulse delay-100 opacity-20">🎬</div>
        <div className="absolute bottom-48 left-16 text-4xl animate-bounce delay-300 opacity-20">📊</div>
        <div className="absolute top-64 left-32 text-6xl animate-pulse delay-500 opacity-20">🎮</div>
        <div className="absolute bottom-32 right-32 text-5xl animate-bounce delay-700 opacity-20">💰</div>
      </div>

      {/* Header */}
      <header className="relative z-10 p-4 lg:p-6">
        <div className="flex justify-between items-center max-w-7xl mx-auto">
          <div className="flex items-center space-x-3">
            <div className="text-3xl lg:text-4xl">🎮</div>
            <div>
              <div className="text-xl lg:text-2xl font-bold bg-gradient-to-r from-red-400 to-orange-400 bg-clip-text text-transparent">
                UGC Creators
              </div>
              <div className="text-xs text-gray-400">by Incline • Pro Edition</div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <LiveCreatorsModal>
              <Button className="bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white px-4 lg:px-6 py-2 lg:py-3 text-sm lg:text-base">
                🔴 LIVE CREATORS
              </Button>
            </LiveCreatorsModal>
            <HotCreatorsModal>
              <Button variant="outline" className="border-yellow-400/50 text-yellow-300 hover:bg-yellow-500/10 px-4 lg:px-6 py-2 lg:py-3 text-sm lg:text-base">
                ⭐ TOP EARNERS
              </Button>
            </HotCreatorsModal>
          </div>
        </div>
      </header>

      {/* Hero Section - Professional YouTube Style */}
      <section className="relative z-10 py-12 lg:py-20 px-4 lg:px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="bg-gradient-to-r from-red-500 to-orange-500 text-white font-bold text-base lg:text-xl px-6 lg:px-8 py-2 lg:py-3 mb-6 lg:mb-8">
                🎬 YOUTUBE CREATORS PROGRAMME
              </Badge>
              
              <h1 className="text-4xl lg:text-6xl xl:text-7xl font-bold mb-6 lg:mb-8 leading-tight">
                <span className="bg-gradient-to-r from-red-400 to-orange-400 bg-clip-text text-transparent block">
                  Scale Your Gaming
                </span>
                <span className="bg-gradient-to-r from-orange-400 to-yellow-400 bg-clip-text text-transparent block">
                  Channel Revenue
                </span>
              </h1>
              
              <p className="text-xl lg:text-2xl text-gray-300 mb-8 lg:mb-12 leading-relaxed">
                Transform your YouTube channel with professional gaming content. 
                Earn <span className="text-green-400 font-bold">£50-£150+ per video</span> plus 
                sponsorship opportunities that scale with your growth! 📈
              </p>

              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button
                  onClick={onGetStarted}
                  className="bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white text-xl lg:text-2xl px-10 lg:px-12 py-4 lg:py-6 rounded-xl font-bold shadow-2xl transform hover:scale-105 transition-all duration-300"
                >
                  🚀 APPLY NOW
                </Button>
                <Button
                  variant="outline"
                  className="border-gray-400/50 text-gray-300 hover:bg-gray-500/10 text-xl lg:text-2xl px-10 lg:px-12 py-4 lg:py-6 rounded-xl"
                >
                  📊 View Case Studies
                </Button>
              </div>

              <div className="grid grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-2xl lg:text-3xl font-bold text-red-400">2.4M+</div>
                  <div className="text-sm lg:text-base text-gray-400">Total Views</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl lg:text-3xl font-bold text-green-400">£156K+</div>
                  <div className="text-sm lg:text-base text-gray-400">Creator Earnings</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl lg:text-3xl font-bold text-orange-400">847</div>
                  <div className="text-sm lg:text-base text-gray-400">Active Channels</div>
                </div>
              </div>
            </div>

            <div className="relative">
              {/* Professional video player mockup */}
              <div className="bg-gradient-to-br from-gray-900/60 to-black/60 rounded-2xl overflow-hidden shadow-2xl backdrop-blur-sm border border-gray-600/30">
                <div className="bg-black/80 px-6 py-3 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  </div>
                  <div className="text-sm text-gray-400">youtube.com/watch</div>
                </div>
                
                <div className="relative">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1596838132731-3301c3fd4317?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                    alt="Gaming content example"
                    className="w-full h-64 lg:h-80 object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    <div className="bg-red-600 hover:bg-red-700 w-20 h-20 lg:w-24 lg:h-24 rounded-full flex items-center justify-center cursor-pointer transform hover:scale-110 transition-all">
                      <Play className="w-8 h-8 lg:w-10 lg:h-10 text-white ml-1" />
                    </div>
                  </div>
                  <div className="absolute bottom-4 right-4 bg-black/80 text-white px-3 py-1 rounded text-sm">
                    12:34
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <Badge className="bg-red-600 text-white">LIVE</Badge>
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-2">Epic Casino Win - £2,500 Jackpot!</h3>
                  <div className="flex items-center justify-between text-gray-400 text-sm mb-4">
                    <span>247K views • 2 days ago</span>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center">
                        <ThumbsUp className="w-4 h-4 mr-1" />
                        8.9K
                      </div>
                      <div className="flex items-center">
                        <Eye className="w-4 h-4 mr-1" />
                        247K
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&q=80"
                      alt="Creator"
                      className="w-10 h-10 rounded-full"
                    />
                    <div>
                      <div className="text-white font-medium">Gaming with Marcus</div>
                      <div className="text-gray-400 text-sm">420K subscribers</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Performance badges */}
              <div className="absolute -top-6 -right-6">
                <Badge className="bg-green-500 text-white text-lg px-4 py-2 shadow-xl">
                  +67% Revenue ↗
                </Badge>
              </div>
              <div className="absolute -bottom-6 -left-6">
                <Badge className="bg-purple-500 text-white text-lg px-4 py-2 shadow-xl">
                  180K Views 👁
                </Badge>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Case Study Carousel */}
      <section className="relative z-10 py-12 lg:py-20 px-4 lg:px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold mb-6 bg-gradient-to-r from-red-400 to-orange-400 bg-clip-text text-transparent">
              Real YouTube Success Stories
            </h2>
            <p className="text-xl text-gray-400">How creators transformed their channels with our gaming content system</p>
          </div>

          <Card className="bg-gradient-to-br from-gray-900/50 to-red-900/20 border-red-400/30 backdrop-blur-xl shadow-2xl overflow-hidden">
            <CardContent className="p-8 lg:p-12">
              <div className="grid lg:grid-cols-2 gap-8 items-center">
                <div>
                  <div className="flex items-center space-x-4 mb-6">
                    <ImageWithFallback
                      src={caseStudies[currentCase].avatar}
                      alt={caseStudies[currentCase].name}
                      className="w-16 h-16 lg:w-20 lg:h-20 rounded-full object-cover border-3 border-red-400"
                    />
                    <div>
                      <h3 className="text-xl lg:text-2xl font-bold text-white">{caseStudies[currentCase].name}</h3>
                      <div className="text-gray-400">{caseStudies[currentCase].channel}</div>
                      <Badge className="bg-red-500/20 text-red-300 border-red-400/30 mt-1">
                        YouTube Creator
                      </Badge>
                    </div>
                  </div>
                  
                  <blockquote className="text-lg lg:text-xl text-gray-300 mb-6 leading-relaxed italic">
                    "{caseStudies[currentCase].content}"
                  </blockquote>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-400">{caseStudies[currentCase].subscribers}</div>
                      <div className="text-sm text-gray-400">Subscribers</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400">{caseStudies[currentCase].monthlyRevenue}</div>
                      <div className="text-sm text-gray-400">Monthly Revenue</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-orange-400">{caseStudies[currentCase].growth}</div>
                      <div className="text-sm text-gray-400">Growth Rate</div>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-2xl font-bold text-white mb-6 text-center">Before vs After</h4>
                  <div className="grid grid-cols-2 gap-6">
                    <div className="bg-gray-800/50 rounded-xl p-6 border border-gray-600/30">
                      <h5 className="text-red-400 font-bold text-center mb-4">BEFORE</h5>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Views:</span>
                          <span className="text-white">{caseStudies[currentCase].beforeAfter.before.views}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Revenue:</span>
                          <span className="text-white">{caseStudies[currentCase].beforeAfter.before.revenue}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Retention:</span>
                          <span className="text-white">{caseStudies[currentCase].beforeAfter.before.retention}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-green-800/50 rounded-xl p-6 border border-green-600/30">
                      <h5 className="text-green-400 font-bold text-center mb-4">AFTER</h5>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Views:</span>
                          <span className="text-green-400 font-bold">{caseStudies[currentCase].beforeAfter.after.views}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Revenue:</span>
                          <span className="text-green-400 font-bold">{caseStudies[currentCase].beforeAfter.after.revenue}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Retention:</span>
                          <span className="text-green-400 font-bold">{caseStudies[currentCase].beforeAfter.after.retention}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-center space-x-2 mt-8">
                {caseStudies.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentCase(index)}
                    className={`w-4 h-4 rounded-full transition-all ${
                      index === currentCase ? 'bg-red-400' : 'bg-gray-600'
                    }`}
                  />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Content Strategy Section */}
      <section className="relative z-10 py-12 lg:py-20 px-4 lg:px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold mb-6 bg-gradient-to-r from-orange-400 to-yellow-400 bg-clip-text text-transparent">
              Professional Content Strategy
            </h2>
            <p className="text-xl text-gray-400">Multiple revenue streams designed for long-form content creators</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {contentTypes.map((content, index) => (
              <Card key={index} className="bg-gradient-to-br from-gray-900/50 to-orange-900/20 border-orange-400/30 backdrop-blur-sm hover:scale-105 transition-all duration-300">
                <CardHeader className="text-center p-8">
                  <content.icon className="w-16 h-16 mx-auto mb-4 text-orange-400" />
                  <CardTitle className="text-2xl text-white mb-4">{content.title}</CardTitle>
                  <Badge className="bg-green-500/20 text-green-300 border-green-400/30 text-lg px-4 py-2">
                    {content.earnings}
                  </Badge>
                </CardHeader>
                <CardContent className="px-8 pb-8">
                  <p className="text-gray-300 text-lg leading-relaxed mb-6">{content.description}</p>
                  <div className="space-y-2">
                    <h4 className="text-orange-400 font-bold">Content Examples:</h4>
                    <ul className="text-gray-400 space-y-1">
                      {content.examples.map((example, idx) => (
                        <li key={idx} className="flex items-center">
                          <div className="w-2 h-2 bg-orange-400 rounded-full mr-3"></div>
                          {example}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Revenue Breakdown */}
      <section className="relative z-10 py-12 lg:py-20 px-4 lg:px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold mb-6 bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
              Complete Revenue Breakdown
            </h2>
            <p className="text-xl text-gray-400">Multiple income streams that scale with your channel</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                title: "Video Payments",
                amount: "£50-£150",
                description: "Per video based on subscriber count",
                icon: "🎬",
                color: "from-green-500 to-emerald-500"
              },
              {
                title: "Promo Commissions", 
                amount: "£10 each",
                description: "Every signup through your code",
                icon: "💰",
                color: "from-blue-500 to-cyan-500"
              },
              {
                title: "Sponsorship Deals",
                amount: "£500-£5K",
                description: "Brand partnerships we arrange",
                icon: "🤝",
                color: "from-purple-500 to-pink-500"
              },
              {
                title: "Channel Growth",
                amount: "+67%",
                description: "Average subscriber increase",
                icon: "📈",
                color: "from-orange-500 to-red-500"
              }
            ].map((item, index) => (
              <Card key={index} className="bg-gradient-to-br from-gray-900/50 to-black/50 border-gray-600/30 backdrop-blur-sm text-center hover:scale-105 transition-all duration-300">
                <CardContent className="p-8">
                  <div className="text-5xl mb-4">{item.icon}</div>
                  <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                  <div className={`text-3xl font-bold mb-4 bg-gradient-to-r ${item.color} bg-clip-text text-transparent`}>
                    {item.amount}
                  </div>
                  <p className="text-gray-400">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="relative z-10 py-16 lg:py-24 px-4 lg:px-6">
        <div className="max-w-5xl mx-auto text-center">
          <div className="bg-gradient-to-br from-red-900/50 to-orange-900/40 border border-red-400/40 rounded-3xl p-8 lg:p-12 backdrop-blur-xl shadow-2xl">
            <div className="text-6xl lg:text-8xl mb-8">🏆</div>
            <h2 className="text-4xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-red-400 via-orange-400 to-yellow-400 bg-clip-text text-transparent">
              Ready to Scale Your Channel?
            </h2>
            <p className="text-xl lg:text-2xl text-gray-300 mb-8 leading-relaxed">
              Join 847 YouTube creators already earning £50-£150+ per video with professional gaming content that grows your channel!
            </p>
            
            <div className="bg-black/30 rounded-2xl p-6 mb-8">
              <h3 className="text-2xl font-bold text-white mb-4">What You Get:</h3>
              <div className="grid md:grid-cols-2 gap-4 text-left">
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm">✓</span>
                  </div>
                  <span className="text-gray-300">Custom gaming persona</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm">✓</span>
                  </div>
                  <span className="text-gray-300">Content strategy guide</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm">✓</span>
                  </div>
                  <span className="text-gray-300">Guaranteed video payments</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm">✓</span>
                  </div>
                  <span className="text-gray-300">Sponsorship opportunities</span>
                </div>
              </div>
            </div>

            <Button
              onClick={onGetStarted}
              className="bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500 hover:from-red-600 hover:via-orange-600 hover:to-yellow-600 text-white text-xl lg:text-2xl px-12 lg:px-16 py-6 lg:py-8 rounded-2xl font-bold shadow-2xl transform hover:scale-110 transition-all duration-300 mb-4"
            >
              🎬 APPLY FOR CREATORS PROGRAMME
            </Button>
            
            <p className="text-sm lg:text-base text-gray-400">
              ⚡ Fast-track approval for 10K+ subscriber channels • 💰 First payment within 14 days
            </p>
          </div>
        </div>
      </section>

      {/* Custom animations */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-15px) rotate(180deg); }
        }
        
        .animate-float {
          animation: float 8s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}