import React, { useState } from 'react';
import LandingPage from './components/LandingPage';
import LandingPageTikTok from './components/LandingPageTikTok';
import LandingPageYouTube from './components/LandingPageYouTube';
import SignUpPage from './components/SignUpPage';
import PersonaAssignmentPage from './components/PersonaAssignmentPage';
import VideoSubmissionPage from './components/VideoSubmissionPage';
import SubmissionStatusPage from './components/SubmissionStatusPage';
import AffiliateDashboard from './components/AffiliateDashboard';
import CreatorsCommunity from './components/CreatorsCommunity';
import GamingTransition from './components/GamingTransition';
import { Button } from './components/ui/button';
import { Badge } from './components/ui/badge';
import { Card, CardContent } from './components/ui/card';

export interface UserData {
  fullName: string;
  age: string;
  location: string;
  email: string;
  socialHandle?: string;
  whatsappDiscord?: string;
  agreedToTerms: boolean;
  assignedPersona?: any;
}

export interface Persona {
  id: number;
  name: string;
  description: string;
  scene: string;
  motivation: string;
  winReaction: string;
  avatar: string;
}

type PageType = 'landing' | 'signup' | 'persona' | 'submission' | 'status' | 'dashboard' | 'community';
type LandingVariant = 'original' | 'tiktok' | 'youtube';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('landing');
  const [landingVariant, setLandingVariant] = useState<LandingVariant>('original');
  const [showLandingSelector, setShowLandingSelector] = useState(true);
  const [targetPage, setTargetPage] = useState<PageType>('landing');
  const [showTransition, setShowTransition] = useState(false);
  const [userData, setUserData] = useState<UserData>({
    fullName: '',
    age: '',
    location: '',
    email: '',
    socialHandle: '',
    whatsappDiscord: '',
    agreedToTerms: false
  });

  const transitionConfigs = {
    'signup': {
      title: "Welcome to UGC Creators",
      subtitle: "Setting up your gaming creator profile..."
    },
    'persona': {
      title: "Generating Your Character",
      subtitle: "Analyzing the perfect gaming persona for you..."
    },
    'submission': {
      title: "Content Studio Ready",
      subtitle: "Preparing your video creation workspace..."
    },
    'status': {
      title: "Upload Complete",
      subtitle: "Processing your gaming content..."
    },
    'dashboard': {
      title: "Analytics Loading",
      subtitle: "Calculating your creator performance metrics..."
    },
    'community': {
      title: "Joining Community",
      subtitle: "Connecting you with fellow gaming creators..."
    }
  };

  const landingVariants = [
    {
      id: 'original' as LandingVariant,
      name: 'General Creators',
      description: 'Perfect for all types of content creators',
      color: 'from-purple-500 to-pink-500',
      icon: '🎮',
      target: 'All Creators'
    },
    {
      id: 'tiktok' as LandingVariant,
      name: 'TikTok Creators',
      description: 'Optimized for short-form viral content',
      color: 'from-pink-500 to-cyan-500',
      icon: '📱',
      target: 'TikTok/Reels'
    },
    {
      id: 'youtube' as LandingVariant,
      name: 'YouTube Creators',
      description: 'Designed for long-form gaming content',
      color: 'from-red-500 to-orange-500',
      icon: '🎬',
      target: 'YouTube'
    }
  ];

  const shouldShowTransition = (fromPage: PageType, toPage: PageType): boolean => {
    // Show transitions for major page changes (not for back navigation)
    const forwardTransitions = [
      ['landing', 'signup'],
      ['signup', 'persona'],
      ['persona', 'submission'],
      ['submission', 'status'],
      ['status', 'dashboard'],
      ['dashboard', 'community']
    ];
    
    return forwardTransitions.some(([from, to]) => from === fromPage && to === toPage);
  };

  const handlePageChange = (page: PageType) => {
    if (shouldShowTransition(currentPage, page)) {
      setTargetPage(page);
      setShowTransition(true);
    } else {
      setCurrentPage(page);
    }
  };

  const handleTransitionComplete = () => {
    setShowTransition(false);
    setCurrentPage(targetPage);
  };

  const handleUserDataUpdate = (data: Partial<UserData>) => {
    setUserData(prev => ({ ...prev, ...data }));
  };

  const handleLandingVariantSelect = (variant: LandingVariant) => {
    setLandingVariant(variant);
    setShowLandingSelector(false);
  };

  const handleGetStarted = () => {
    handlePageChange('signup');
  };

  // Landing Page Selector
  if (showLandingSelector && currentPage === 'landing') {
    return (
      <div className="min-h-screen bg-black text-white relative overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20"></div>
          
          {/* Animated particles */}
          {[...Array(10)].map((_, i) => (
            <div
              key={i}
              className="absolute animate-float opacity-40"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${i * 0.8}s`,
                animationDuration: `${6 + Math.random() * 4}s`
              }}
            >
              <div className="w-3 h-3 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full blur-sm"></div>
            </div>
          ))}

          {/* Floating elements */}
          <div className="absolute top-20 right-20 text-6xl animate-bounce delay-100 opacity-30">🎮</div>
          <div className="absolute bottom-32 left-20 text-7xl animate-pulse delay-300 opacity-30">🎬</div>
          <div className="absolute top-60 left-20 text-5xl animate-bounce delay-500 opacity-30">📱</div>
          <div className="absolute bottom-60 right-20 text-4xl animate-pulse delay-700 opacity-30">🚀</div>
        </div>

        {/* Content */}
        <div className="relative z-10 min-h-screen flex items-center justify-center px-4 lg:px-6">
          <div className="max-w-6xl mx-auto text-center">
            {/* Header */}
            <div className="mb-12 lg:mb-16">
              <div className="flex items-center justify-center space-x-4 mb-6">
                <div className="text-5xl lg:text-6xl">🎮</div>
                <div>
                  <div className="text-4xl lg:text-5xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                    UGC Creators
                  </div>
                  <div className="text-lg text-gray-400">by Incline</div>
                </div>
              </div>
              
              <h1 className="text-4xl lg:text-6xl xl:text-7xl font-bold mb-6 leading-tight">
                <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">
                  Choose Your Creator Path
                </span>
              </h1>
              
              <p className="text-xl lg:text-2xl text-gray-300 mb-8 max-w-4xl mx-auto">
                Select the experience tailored to your content platform and audience
              </p>
              
              <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-black font-bold text-lg px-6 py-3 mb-8">
                🔥 All paths lead to the same amazing programme!
              </Badge>
            </div>

            {/* Landing Page Options */}
            <div className="grid lg:grid-cols-3 gap-8 mb-12">
              {landingVariants.map((variant) => (
                <Card
                  key={variant.id}
                  className="bg-gradient-to-br from-gray-900/50 to-black/50 border-purple-400/30 backdrop-blur-xl hover:scale-105 transition-all duration-300 cursor-pointer group"
                  onClick={() => handleLandingVariantSelect(variant.id)}
                >
                  <CardContent className="p-8 text-center">
                    <div className="text-6xl mb-6 group-hover:animate-bounce">{variant.icon}</div>
                    
                    <Badge className={`bg-gradient-to-r ${variant.color} text-white font-bold text-base px-4 py-2 mb-4`}>
                      {variant.target}
                    </Badge>
                    
                    <h3 className="text-2xl lg:text-3xl font-bold text-white mb-4">{variant.name}</h3>
                    <p className="text-gray-400 text-lg mb-6 leading-relaxed">{variant.description}</p>
                    
                    <div className="space-y-3 text-sm text-gray-500 mb-6">
                      <div className="flex items-center justify-center">
                        <span className="text-green-400">✓</span>
                        <span className="ml-2">Same earning potential</span>
                      </div>
                      <div className="flex items-center justify-center">
                        <span className="text-green-400">✓</span>
                        <span className="ml-2">Platform-optimized content</span>
                      </div>
                      <div className="flex items-center justify-center">
                        <span className="text-green-400">✓</span>
                        <span className="ml-2">Tailored user experience</span>
                      </div>
                    </div>
                    
                    <Button
                      className={`bg-gradient-to-r ${variant.color} hover:scale-110 transition-all text-white font-bold py-3 px-8 rounded-xl w-full`}
                    >
                      Explore This Path 🚀
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Alternative Option */}
            <div className="text-center">
              <p className="text-gray-400 mb-4">Not sure which path to choose?</p>
              <Button
                onClick={() => handleLandingVariantSelect('original')}
                variant="outline"
                className="border-gray-400/50 text-gray-300 hover:bg-gray-500/10 px-8 py-3 rounded-xl"
              >
                Start with General Creator Experience
              </Button>
            </div>
          </div>
        </div>

        {/* Custom animations */}
        <style>{`
          @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-15px) rotate(180deg); }
          }
          
          .animate-float {
            animation: float 6s ease-in-out infinite;
          }
        `}</style>
      </div>
    );
  }

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'landing':
        if (landingVariant === 'tiktok') {
          return <LandingPageTikTok onGetStarted={handleGetStarted} />;
        } else if (landingVariant === 'youtube') {
          return <LandingPageYouTube onGetStarted={handleGetStarted} />;
        } else {
          return <LandingPage onGetStarted={handleGetStarted} />;
        }
      case 'signup':
        return <SignUpPage 
          userData={userData}
          onUserDataUpdate={handleUserDataUpdate}
          onNext={() => handlePageChange('persona')} 
          onBack={() => {
            setShowLandingSelector(true);
            setCurrentPage('landing');
          }}
        />;
      case 'persona':
        return <PersonaAssignmentPage 
          userData={userData}
          onUserDataUpdate={handleUserDataUpdate}
          onAccept={() => handlePageChange('submission')}
          onBack={() => handlePageChange('signup')}
        />;
      case 'submission':
        return <VideoSubmissionPage 
          persona={userData.assignedPersona}
          onSubmit={() => handlePageChange('status')}
          onBack={() => handlePageChange('persona')}
        />;
      case 'status':
        return <SubmissionStatusPage 
          onReturnHome={() => {
            setShowLandingSelector(true);
            setCurrentPage('landing');
          }}
          onViewDashboard={() => handlePageChange('dashboard')}
        />;
      case 'dashboard':
        return <AffiliateDashboard 
          onBack={() => handlePageChange('status')}
          onCommunity={() => handlePageChange('community')}
        />;
      case 'community':
        return <CreatorsCommunity 
          onBack={() => handlePageChange('dashboard')}
        />;
      default:
        return <LandingPage onGetStarted={handleGetStarted} />;
    }
  };

  const currentTransitionConfig = transitionConfigs[targetPage];

  return (
    <div className="min-h-screen bg-black text-white">
      {renderCurrentPage()}
      
      <GamingTransition
        isVisible={showTransition}
        title={currentTransitionConfig?.title || "Loading..."}
        subtitle={currentTransitionConfig?.subtitle || "Please wait..."}
        onComplete={handleTransitionComplete}
        duration={4500} // 4.5 seconds for more immersive experience
      />
    </div>
  );
}