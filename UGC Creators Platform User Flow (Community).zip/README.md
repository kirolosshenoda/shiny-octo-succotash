
  # UGC Creators Platform User Flow (Community)

  This is a code bundle for UGC Creators Platform User Flow (Community). The original project is available at https://www.figma.com/design/7EW78dksLaPB2TRKj5zO5e/UGC-Creators-Platform-User-Flow--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  