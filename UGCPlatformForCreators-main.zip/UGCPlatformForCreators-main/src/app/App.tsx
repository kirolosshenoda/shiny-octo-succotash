import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Play, Star, MapPin, Clock, TrendingUp, Search, Bell, MessageSquare,
  Bookmark, Eye, Zap, Camera, Video, Instagram, Youtube, Users,
  Briefcase, ArrowRight, Check, X, Shield, FileText, Send, Upload,
  ChevronRight, Layers, DollarSign, AlertCircle, ThumbsUp, Sparkles,
  Target, RefreshCw, Package, BarChart2, Award, Globe, Filter,
  ChevronDown, Heart, Share2, LayoutGrid, PlusCircle, Wallet,
  TrendingDown, CheckCircle, MoreHorizontal, LogOut, Home,
  BookOpen, Settings, Percent, Tag,
} from "lucide-react";

type Role = "creator" | "company" | null;

// ─── Shared Data ──────────────────────────────────────────────────────────────

interface Creator {
  id: number; name: string; handle: string; avatar: string;
  location: string; country: string; niche: string[]; bio: string;
  thumbnail: string; stats: { views: string; engagement: string; delivery: string };
  rating: number; reviews: number;
  packages: { name: string; price: number; deliverables: string }[];
  platforms: string[]; verified: boolean; responseTime: string; followers: string;
}

const creators: Creator[] = [
  {
    id: 1, name: "Sofia Reyes", handle: "@sofiareyes",
    avatar: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=80&h=80&fit=crop&auto=format",
    location: "Dubai, UAE", country: "🇦🇪", niche: ["Beauty", "Skincare"],
    bio: "Award-winning UGC creator in Dubai. 4+ years in beauty & wellness for Gulf brands.",
    thumbnail: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=600&h=400&fit=crop&auto=format",
    stats: { views: "2.4M", engagement: "8.2%", delivery: "3 days" },
    rating: 4.98, reviews: 312, followers: "113.4K",
    packages: [
      { name: "Starter", price: 180, deliverables: "1 video (30s) + raw files" },
      { name: "Pro", price: 480, deliverables: "3 videos + story formats + revisions" },
    ],
    platforms: ["Instagram", "TikTok"], verified: true, responseTime: "< 2 hrs",
  },
  {
    id: 2, name: "Khalid Al-Rashid", handle: "@khalidshots",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop&auto=format",
    location: "Riyadh, KSA", country: "🇸🇦", niche: ["Tech", "Gadgets"],
    bio: "Tech UGC specialist in Riyadh. Trusted by 50+ brands for unboxings and demos.",
    thumbnail: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=600&h=400&fit=crop&auto=format",
    stats: { views: "1.8M", engagement: "6.7%", delivery: "5 days" },
    rating: 4.94, reviews: 189, followers: "89.2K",
    packages: [
      { name: "Basic", price: 220, deliverables: "1 unboxing video (60s)" },
      { name: "Growth", price: 590, deliverables: "3 videos + b-roll + thumbnail" },
    ],
    platforms: ["YouTube", "TikTok"], verified: true, responseTime: "< 4 hrs",
  },
  {
    id: 3, name: "Layla Hassan", handle: "@laylacreates",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=80&h=80&fit=crop&auto=format",
    location: "Cairo, Egypt", country: "🇪🇬", niche: ["Fashion", "Travel"],
    bio: "Bilingual Arabic-English lifestyle creator. Editorial aesthetic, Gulf market reach.",
    thumbnail: "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=600&h=400&fit=crop&auto=format",
    stats: { views: "3.1M", engagement: "9.1%", delivery: "4 days" },
    rating: 5.0, reviews: 407, followers: "204K",
    packages: [
      { name: "Mini", price: 150, deliverables: "1 photo + 1 reel (15s)" },
      { name: "Full", price: 420, deliverables: "5 photos + 2 reels + captions" },
    ],
    platforms: ["Instagram", "TikTok"], verified: true, responseTime: "< 1 hr",
  },
  {
    id: 4, name: "Omar Nasser", handle: "@omarnasser",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop&auto=format",
    location: "Abu Dhabi, UAE", country: "🇦🇪", niche: ["Fitness", "Health"],
    bio: "Fitness & wellness UGC in both Arabic and English. Real results for Gulf audiences.",
    thumbnail: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&h=400&fit=crop&auto=format",
    stats: { views: "900K", engagement: "7.4%", delivery: "3 days" },
    rating: 4.91, reviews: 94, followers: "52.8K",
    packages: [
      { name: "Solo", price: 200, deliverables: "1 workout demo + testimonial" },
      { name: "Bundle", price: 520, deliverables: "3 videos + transformation story" },
    ],
    platforms: ["TikTok", "Instagram", "YouTube"], verified: false, responseTime: "< 6 hrs",
  },
  {
    id: 5, name: "Fatima Al-Zahra", handle: "@fatimavibes",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=80&h=80&fit=crop&auto=format",
    location: "Jeddah, KSA", country: "🇸🇦", niche: ["Home Decor", "Lifestyle"],
    bio: "Khaliji-dialect native creator. Luxury and everyday home brands — Jeddah based.",
    thumbnail: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=600&h=400&fit=crop&auto=format",
    stats: { views: "1.2M", engagement: "5.9%", delivery: "6 days" },
    rating: 4.87, reviews: 156, followers: "78.3K",
    packages: [
      { name: "Basic", price: 175, deliverables: "1 styled video (30s)" },
      { name: "Campaign", price: 460, deliverables: "4 videos + mood board" },
    ],
    platforms: ["Instagram", "TikTok"], verified: true, responseTime: "< 3 hrs",
  },
  {
    id: 6, name: "Rami Barakat", handle: "@ramibarakat",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=80&h=80&fit=crop&auto=format",
    location: "Beirut, Lebanon", country: "🇱🇧", niche: ["Food", "Beverage"],
    bio: "Food & ASMR UGC in Arabic. Taste reactions and product reveals that make people hungry.",
    thumbnail: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=600&h=400&fit=crop&auto=format",
    stats: { views: "680K", engagement: "11.3%", delivery: "4 days" },
    rating: 4.96, reviews: 78, followers: "39.9K",
    packages: [
      { name: "Taste", price: 160, deliverables: "1 reaction video (45s)" },
      { name: "Full", price: 390, deliverables: "3 videos + recipe content" },
    ],
    platforms: ["TikTok", "Instagram"], verified: false, responseTime: "< 8 hrs",
  },
];

const heroPhotos = [
  "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=200&h=260&fit=crop&auto=format",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=260&fit=crop&auto=format",
  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=260&fit=crop&auto=format",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=260&fit=crop&auto=format",
  "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&h=260&fit=crop&auto=format",
  "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=260&fit=crop&auto=format",
  "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&h=260&fit=crop&auto=format",
  "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=200&h=260&fit=crop&auto=format",
];

// ─── Shared atoms ─────────────────────────────────────────────────────────────

function PlatformIcon({ name }: { name: string }) {
  if (name === "Instagram") return <Instagram size={11} />;
  if (name === "YouTube") return <Youtube size={11} />;
  return <Video size={11} />;
}

function StarRating({ rating }: { rating: number }) {
  return (
    <span className="flex items-center gap-0.5">
      <Star size={11} className="fill-amber-500 text-amber-500" />
      <span className="text-xs font-semibold text-amber-600">{rating.toFixed(2)}</span>
    </span>
  );
}

// ─── Profile Modal ────────────────────────────────────────────────────────────

function ProfileModal({ creator, onClose }: { creator: Creator; onClose: () => void }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm" onClick={onClose}>
      <motion.div initial={{ scale: 0.92, y: 16 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.92, y: 16 }}
        transition={{ type: "spring", damping: 28, stiffness: 300 }}
        className="bg-white border border-violet-100 rounded-3xl w-full max-w-xl max-h-[88vh] overflow-y-auto shadow-2xl"
        onClick={(e) => e.stopPropagation()}>
        <div className="relative h-44">
          <img src={creator.thumbnail} alt="" className="w-full h-full object-cover rounded-t-3xl" />
          <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-transparent rounded-t-3xl" />
          <button onClick={onClose} className="absolute top-3 right-3 w-7 h-7 rounded-full bg-white/80 backdrop-blur-sm flex items-center justify-center text-gray-500 hover:bg-white">
            <X size={13} />
          </button>
          <div className="absolute bottom-3 left-5 flex items-end gap-2.5">
            <img src={creator.avatar} alt={creator.name} className="w-14 h-14 rounded-2xl object-cover border-2 border-violet-400 shadow-lg" />
            <div>
              <h2 className="text-lg font-bold text-foreground">{creator.name}</h2>
              <p className="text-xs text-muted-foreground">{creator.handle} · {creator.followers}</p>
            </div>
          </div>
        </div>
        <div className="p-5">
          <div className="flex flex-wrap gap-3 mb-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><MapPin size={11} />{creator.location}</span>
            <StarRating rating={creator.rating} />
            <span>({creator.reviews} reviews)</span>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed mb-5">{creator.bio}</p>
          <div className="grid grid-cols-3 gap-2.5 mb-5">
            {[
              { label: "Avg Views", val: creator.stats.views, color: "text-violet-600" },
              { label: "Engagement", val: creator.stats.engagement, color: "text-orange-600" },
              { label: "Delivery", val: creator.stats.delivery, color: "text-emerald-600" },
            ].map((s) => (
              <div key={s.label} className="bg-violet-50 rounded-xl p-2.5 text-center border border-violet-100">
                <p className={`text-base font-bold ${s.color}`}>{s.val}</p>
                <p className="text-[10px] text-muted-foreground">{s.label}</p>
              </div>
            ))}
          </div>
          <div className="space-y-2 mb-5">
            {creator.packages.map((pkg) => (
              <div key={pkg.name} className="flex items-center justify-between p-3 rounded-xl border border-border hover:border-violet-300 hover:bg-violet-50 transition-all">
                <div>
                  <p className="text-sm font-semibold text-foreground">{pkg.name}</p>
                  <p className="text-[10px] text-muted-foreground">{pkg.deliverables}</p>
                </div>
                <div className="text-right">
                  <p className="text-base font-bold text-violet-700">${pkg.price}</p>
                </div>
              </div>
            ))}
          </div>
          <motion.button whileTap={{ scale: 0.97 }} className="w-full py-2.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-sm font-semibold transition-colors shadow-md shadow-violet-200">
            Send Brief to {creator.name.split(" ")[0]}
          </motion.button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// CREATOR DASHBOARD
// ══════════════════════════════════════════════════════════════════════════════

type CreatorTab = "home" | "gigs" | "projects" | "portfolio" | "earnings";

const creatorProjects = [
  {
    id: 1, brand: "NovaSkin Co.", logo: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=40&h=40&fit=crop&auto=format",
    title: "SPF Launch — 3× TikTok UGC", status: "in-review" as const,
    due: "Jul 28", payment: 480, escrowHeld: true,
    milestones: [true, true, true, false, false],
  },
  {
    id: 2, brand: "FitFuel Nutrition", logo: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=40&h=40&fit=crop&auto=format",
    title: "60-Day Transformation — Week 2", status: "revision" as const,
    due: "Aug 1", payment: 300, escrowHeld: true,
    milestones: [true, true, true, false, false],
  },
  {
    id: 3, brand: "Bloom Botanics", logo: "https://images.unsplash.com/photo-1490750967868-88df5691cc81?w=40&h=40&fit=crop&auto=format",
    title: "Spring Home Styling — 4 Reels", status: "approved" as const,
    due: "Jul 20", payment: 460, escrowHeld: false,
    milestones: [true, true, true, true, true],
  },
];

const openGigs = [
  {
    id: 1, brand: "NovaSkin Co.", logo: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=40&h=40&fit=crop&auto=format",
    title: "3× TikTok UGC — Skincare SPF Launch", budget: "$350–$600", deadline: "Jul 28",
    tags: ["Skincare", "TikTok"], location: "Remote · Gulf", applicants: 24, urgent: true, match: 96,
  },
  {
    id: 2, brand: "Catalyst Agency", logo: "https://images.unsplash.com/photo-1614680376408-81e91ffe3db7?w=40&h=40&fit=crop&auto=format",
    title: "UGC Video Editor — 20 videos/week", budget: "$12–$18/video", deadline: "Ongoing",
    tags: ["Editing", "CapCut"], location: "Remote", applicants: 41, urgent: false, match: 81,
  },
  {
    id: 3, brand: "FitFuel Nutrition", logo: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=40&h=40&fit=crop&auto=format",
    title: "6 Fitness Creators — Supplement Campaign", budget: "$300/month", deadline: "Aug 1",
    tags: ["Fitness", "Long-term"], location: "Remote · Gulf", applicants: 67, urgent: false, match: 74,
  },
  {
    id: 4, brand: "StoryArch", logo: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=40&h=40&fit=crop&auto=format",
    title: "Arabic UGC Scriptwriter — 15 scripts/week", budget: "$8–$15/script", deadline: "Ongoing",
    tags: ["Copywriting", "Arabic"], location: "Remote", applicants: 33, urgent: true, match: 68,
  },
];

const portfolioItems = [
  { id: 1, brand: "GlowLab", thumbnail: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=300&h=200&fit=crop&auto=format", views: "1.2M", type: "TikTok" },
  { id: 2, brand: "TechNova", thumbnail: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=300&h=200&fit=crop&auto=format", views: "890K", type: "YouTube" },
  { id: 3, brand: "Bloom Botanics", thumbnail: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=300&h=200&fit=crop&auto=format", views: "2.1M", type: "Instagram" },
  { id: 4, brand: "FitFuel", thumbnail: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=300&h=200&fit=crop&auto=format", views: "640K", type: "TikTok" },
  { id: 5, brand: "ArabesFoods", thumbnail: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=300&h=200&fit=crop&auto=format", views: "420K", type: "TikTok" },
  { id: 6, brand: "LuxeHome", thumbnail: "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=300&h=200&fit=crop&auto=format", views: "980K", type: "Instagram" },
];

const statusStyle: Record<string, { label: string; cls: string; dot: string }> = {
  "in-review": { label: "In Review", cls: "bg-blue-100 text-blue-700 border-blue-200", dot: "bg-blue-500" },
  "revision": { label: "Revision Needed", cls: "bg-orange-100 text-orange-700 border-orange-200", dot: "bg-orange-500" },
  "approved": { label: "Approved", cls: "bg-emerald-100 text-emerald-700 border-emerald-200", dot: "bg-emerald-500" },
};

function CreatorHome() {
  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "Total Earned", val: "$6,240", change: "+$480 this month", icon: <Wallet size={16} className="text-violet-600" />, bg: "bg-violet-50 border-violet-100", valColor: "text-violet-700" },
          { label: "Active Projects", val: "2", change: "1 needs revision", icon: <Briefcase size={16} className="text-orange-500" />, bg: "bg-orange-50 border-orange-100", valColor: "text-orange-700" },
          { label: "Avg Engagement", val: "8.2%", change: "+1.1% vs last month", icon: <TrendingUp size={16} className="text-emerald-500" />, bg: "bg-emerald-50 border-emerald-100", valColor: "text-emerald-700" },
          { label: "Profile Views", val: "3,421", change: "+22% this week", icon: <Eye size={16} className="text-blue-500" />, bg: "bg-blue-50 border-blue-100", valColor: "text-blue-700" },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
            className={`bg-white border rounded-2xl p-4 shadow-sm ${s.bg}`}>
            <div className="flex items-center justify-between mb-2">{s.icon}<span className="text-[10px] text-emerald-600 font-semibold">{s.change}</span></div>
            <p className={`text-2xl font-extrabold mb-0.5 ${s.valColor}`}>{s.val}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Active Projects */}
        <div className="lg:col-span-2 bg-white border border-border rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-foreground">Active Projects</h3>
            <button className="text-xs text-violet-600 font-semibold hover:text-violet-800">View all →</button>
          </div>
          <div className="space-y-3">
            {creatorProjects.map((p, i) => {
              const s = statusStyle[p.status];
              const done = p.milestones.filter(Boolean).length;
              const pct = Math.round((done / p.milestones.length) * 100);
              return (
                <motion.div key={p.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.08 }}
                  className="flex items-center gap-3 p-3 rounded-xl border border-border hover:border-violet-200 hover:bg-violet-50/30 transition-all">
                  <img src={p.logo} alt={p.brand} className="w-9 h-9 rounded-xl object-cover border border-border shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-xs font-bold text-foreground truncate">{p.title}</p>
                      <span className={`shrink-0 text-[9px] font-semibold px-1.5 py-0.5 rounded-full border ${s.cls}`}>{s.label}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1 rounded-full bg-violet-100 overflow-hidden">
                        <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.7, delay: i * 0.1 }}
                          className="h-full rounded-full bg-violet-500" />
                      </div>
                      <span className="text-[9px] text-muted-foreground shrink-0">{done}/{p.milestones.length}</span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-sm font-bold text-violet-700">${p.payment}</p>
                    <p className="text-[9px] text-muted-foreground">Due {p.due}</p>
                  </div>
                  {p.status === "revision" && (
                    <motion.button whileTap={{ scale: 0.95 }} className="shrink-0 px-2 py-1 rounded-lg bg-orange-50 border border-orange-200 text-[10px] font-semibold text-orange-700 hover:bg-orange-100 transition-colors flex items-center gap-1">
                      <Upload size={9} />Upload
                    </motion.button>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Escrow Wallet */}
        <div className="space-y-3">
          <div className="bg-gradient-to-br from-violet-600 to-purple-700 rounded-2xl p-4 text-white shadow-lg shadow-violet-200">
            <div className="flex items-center gap-1.5 mb-4">
              <Shield size={14} className="text-white/80" />
              <p className="text-xs font-semibold text-white/80">Spotless Pay · Escrow</p>
            </div>
            <p className="text-3xl font-extrabold mb-0.5">$780</p>
            <p className="text-xs text-white/70 mb-4">currently held in escrow</p>
            <div className="space-y-2">
              {creatorProjects.filter(p => p.escrowHeld).map(p => (
                <div key={p.id} className="flex items-center justify-between bg-white/10 rounded-xl px-3 py-2">
                  <span className="text-[10px] text-white/80 truncate">{p.brand}</span>
                  <span className="text-xs font-bold text-white">${p.payment}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white border border-border rounded-2xl p-4 shadow-sm">
            <p className="text-xs font-bold text-foreground mb-3">Quick Stats</p>
            {[
              { label: "On-time rate", val: "97%", color: "text-emerald-600" },
              { label: "Revision rate", val: "1.2 avg", color: "text-muted-foreground" },
              { label: "Repeat clients", val: "68%", color: "text-violet-600" },
            ].map((s) => (
              <div key={s.label} className="flex items-center justify-between py-1.5 border-b border-border last:border-0">
                <span className="text-xs text-muted-foreground">{s.label}</span>
                <span className={`text-xs font-bold ${s.color}`}>{s.val}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function CreatorGigs() {
  const [activeFilter, setActiveFilter] = useState("All");
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-foreground">Open Gigs for You</h2>
          <p className="text-xs text-muted-foreground">Matched to your niche, location & stats</p>
        </div>
        <div className="flex gap-2">
          {["All", "Urgent", "High Pay", "Best Match"].map(f => (
            <motion.button key={f} whileTap={{ scale: 0.95 }} onClick={() => setActiveFilter(f)}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${activeFilter === f ? "bg-violet-600 text-white shadow-sm" : "bg-white border border-border text-muted-foreground hover:border-violet-300"}`}>
              {f}
            </motion.button>
          ))}
        </div>
      </div>
      <div className="space-y-3">
        {openGigs.map((gig, i) => (
          <motion.div key={gig.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
            whileHover={{ x: 4 }}
            className="bg-white border border-border rounded-2xl p-4 hover:border-violet-300 hover:shadow-md hover:shadow-violet-50 transition-all">
            <div className="flex items-start gap-3">
              <img src={gig.logo} alt={gig.brand} className="w-10 h-10 rounded-xl object-cover border border-border shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {gig.urgent && <span className="flex items-center gap-0.5 text-[9px] font-bold text-rose-600 bg-rose-50 border border-rose-200 px-1.5 py-0.5 rounded-full"><Zap size={8} />Urgent</span>}
                    <span className="text-[10px] font-semibold text-violet-600 bg-violet-50 border border-violet-100 px-1.5 py-0.5 rounded-full">
                      {gig.match}% match
                    </span>
                    {gig.tags.map(t => <span key={t} className="text-[9px] px-1.5 py-0.5 rounded bg-secondary text-muted-foreground border border-border">{t}</span>)}
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-sm font-bold text-violet-700">{gig.budget}</p>
                    <p className="text-[9px] text-muted-foreground">Due {gig.deadline}</p>
                  </div>
                </div>
                <p className="text-sm font-bold text-foreground mb-1">{gig.title}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                    <span className="flex items-center gap-0.5"><MapPin size={9} />{gig.location}</span>
                    <span className="flex items-center gap-0.5"><Users size={9} />{gig.applicants} applied</span>
                  </div>
                  <motion.button whileTap={{ scale: 0.96 }} className="px-3 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-semibold transition-colors shadow-sm shadow-violet-200">
                    Apply Now
                  </motion.button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function CreatorPortfolio() {
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-foreground">My Portfolio</h2>
          <p className="text-xs text-muted-foreground">Your published UGC work · visible to brands</p>
        </div>
        <motion.button whileTap={{ scale: 0.96 }} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-violet-600 text-white text-xs font-semibold hover:bg-violet-700 transition-colors shadow-sm shadow-violet-200">
          <PlusCircle size={13} />Add Work
        </motion.button>
      </div>

      {/* Package cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-2">
        {[
          { name: "Starter", price: 180, deliverables: "1 video (30s) + raw files", active: true },
          { name: "Pro", price: 480, deliverables: "3 videos + story formats + revisions", active: true },
          { name: "Custom", price: null, deliverables: "Let's talk scope & budget", active: false },
        ].map((pkg) => (
          <div key={pkg.name} className={`p-4 rounded-2xl border transition-all ${pkg.active ? "border-violet-200 bg-violet-50" : "border-dashed border-border bg-white"}`}>
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-bold text-foreground">{pkg.name}</p>
              {pkg.active ? <span className="text-[9px] font-semibold text-emerald-600 bg-emerald-50 border border-emerald-100 px-1.5 py-0.5 rounded-full">Active</span>
                : <span className="text-[9px] font-semibold text-muted-foreground bg-secondary border border-border px-1.5 py-0.5 rounded-full">Draft</span>}
            </div>
            <p className="text-xl font-extrabold text-violet-700 mb-1">{pkg.price ? `$${pkg.price}` : "Contact"}</p>
            <p className="text-[10px] text-muted-foreground">{pkg.deliverables}</p>
          </div>
        ))}
      </div>

      {/* Video grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {portfolioItems.map((item, i) => (
          <motion.div key={item.id} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.06 }}
            whileHover={{ scale: 1.02 }}
            className="group relative rounded-2xl overflow-hidden border border-border shadow-sm aspect-video cursor-pointer">
            <img src={item.thumbnail} alt={item.brand} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="w-10 h-10 rounded-full bg-white/30 backdrop-blur-sm flex items-center justify-center border border-white/40">
                <Play size={14} className="text-white fill-white ml-0.5" />
              </div>
            </div>
            <div className="absolute bottom-2.5 left-3 right-3">
              <p className="text-xs font-bold text-white truncate">{item.brand}</p>
              <div className="flex items-center justify-between">
                <span className="text-[9px] text-white/70">{item.type}</span>
                <span className="text-[9px] text-white/80 flex items-center gap-0.5"><Eye size={8} />{item.views}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function CreatorEarnings() {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"];
  const earnings = [820, 1100, 940, 1380, 1200, 1650, 480];
  const maxE = Math.max(...earnings);

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-base font-bold text-foreground">Earnings & Payments</h2>
        <p className="text-xs text-muted-foreground">Your income history and escrow status</p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Total Earned", val: "$7,570", sub: "all time", color: "text-violet-700", bg: "bg-violet-50 border-violet-100" },
          { label: "This Month", val: "$480", sub: "in progress", color: "text-orange-600", bg: "bg-orange-50 border-orange-100" },
          { label: "In Escrow", val: "$780", sub: "pending release", color: "text-emerald-700", bg: "bg-emerald-50 border-emerald-100" },
        ].map((s) => (
          <div key={s.label} className={`bg-white border rounded-2xl p-4 shadow-sm ${s.bg}`}>
            <p className={`text-2xl font-extrabold mb-0.5 ${s.color}`}>{s.val}</p>
            <p className="text-xs font-semibold text-foreground">{s.label}</p>
            <p className="text-[10px] text-muted-foreground">{s.sub}</p>
          </div>
        ))}
      </div>

      {/* Bar chart */}
      <div className="bg-white border border-border rounded-2xl p-4 shadow-sm">
        <p className="text-xs font-bold text-foreground mb-4">Monthly Earnings (USD)</p>
        <div className="flex items-end gap-2 h-28">
          {months.map((m, i) => (
            <div key={m} className="flex-1 flex flex-col items-center gap-1">
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: `${(earnings[i] / maxE) * 100}%` }}
                transition={{ delay: i * 0.06, duration: 0.5, ease: "easeOut" }}
                className={`w-full rounded-t-lg ${i === months.length - 1 ? "bg-violet-200" : "bg-violet-500"}`}
              />
              <span className="text-[9px] text-muted-foreground">{m}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Transaction list */}
      <div className="bg-white border border-border rounded-2xl p-4 shadow-sm">
        <p className="text-xs font-bold text-foreground mb-3">Recent Transactions</p>
        {[
          { brand: "Bloom Botanics", amount: 460, date: "Jul 20", status: "paid" },
          { brand: "NovaSkin Co.", amount: 480, date: "Pending", status: "escrow" },
          { brand: "FitFuel Nutrition", amount: 300, date: "Pending", status: "escrow" },
          { brand: "GlowLab", amount: 340, date: "Jun 30", status: "paid" },
        ].map((t, i) => (
          <div key={i} className="flex items-center justify-between py-2.5 border-b border-border last:border-0">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${t.status === "paid" ? "bg-emerald-500" : "bg-yellow-400"}`} />
              <div>
                <p className="text-xs font-semibold text-foreground">{t.brand}</p>
                <p className="text-[9px] text-muted-foreground">{t.date}</p>
              </div>
            </div>
            <div className="text-right">
              <p className={`text-sm font-bold ${t.status === "paid" ? "text-emerald-700" : "text-yellow-600"}`}>+${t.amount}</p>
              <p className="text-[9px] text-muted-foreground capitalize">{t.status}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CreatorDashboard({ onSignOut }: { onSignOut: () => void }) {
  const [tab, setTab] = useState<CreatorTab>("home");

  const navItems: { id: CreatorTab; label: string; icon: React.ReactNode }[] = [
    { id: "home", label: "Dashboard", icon: <Home size={16} /> },
    { id: "gigs", label: "Find Gigs", icon: <Target size={16} /> },
    { id: "projects", label: "My Projects", icon: <Briefcase size={16} /> },
    { id: "portfolio", label: "Portfolio", icon: <Camera size={16} /> },
    { id: "earnings", label: "Earnings", icon: <Wallet size={16} /> },
  ];

  return (
    <div className="min-h-screen bg-background flex" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      {/* Sidebar */}
      <aside className="w-56 shrink-0 border-r border-border bg-white flex flex-col sticky top-0 h-screen">
        {/* Logo */}
        <div className="p-5 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-violet-600 to-purple-700 flex items-center justify-center shadow-sm shadow-violet-200">
              <Zap size={14} className="text-white fill-white" />
            </div>
            <span className="font-extrabold text-foreground text-sm tracking-tight">UGC <span className="text-violet-600">GULF</span></span>
          </div>
        </div>

        {/* Creator profile */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <img src="https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=60&h=60&fit=crop&auto=format" alt="Me" className="w-10 h-10 rounded-full object-cover border-2 border-violet-300" />
              <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-violet-600 border-2 border-white flex items-center justify-center">
                <Check size={7} className="text-white" strokeWidth={3} />
              </div>
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-foreground truncate">Sofia Reyes</p>
              <p className="text-[10px] text-violet-600 font-semibold">@sofiareyes</p>
              <div className="flex items-center gap-0.5 mt-0.5">
                <Star size={9} className="fill-amber-500 text-amber-500" />
                <span className="text-[9px] text-muted-foreground">4.98 · 312 reviews</span>
              </div>
            </div>
          </div>
          <div className="mt-3 p-2 rounded-xl bg-violet-50 border border-violet-100">
            <p className="text-[9px] text-muted-foreground">Escrow Balance</p>
            <p className="text-sm font-bold text-violet-700">$780 held</p>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-0.5">
          {navItems.map((item) => (
            <motion.button key={item.id} whileTap={{ scale: 0.97 }} onClick={() => setTab(item.id)}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm transition-all ${tab === item.id ? "bg-violet-600 text-white font-semibold shadow-sm shadow-violet-200" : "text-muted-foreground hover:bg-violet-50 hover:text-violet-700"}`}>
              {item.icon}<span>{item.label}</span>
              {item.id === "projects" && <span className="ml-auto w-4 h-4 rounded-full bg-orange-500 text-[9px] font-bold text-white flex items-center justify-center">1</span>}
            </motion.button>
          ))}
        </nav>

        <div className="p-3 border-t border-border space-y-0.5">
          <button className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm text-muted-foreground hover:bg-secondary hover:text-foreground transition-all">
            <Settings size={15} />Settings
          </button>
          <button onClick={onSignOut} className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm text-rose-500 hover:bg-rose-50 transition-all">
            <LogOut size={15} />Sign out
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 min-w-0">
        {/* Top bar */}
        <div className="sticky top-0 z-30 bg-white/80 backdrop-blur-xl border-b border-border px-6 h-13 flex items-center justify-between py-2.5 shadow-sm">
          <div>
            <h1 className="text-sm font-bold text-foreground capitalize">{tab === "home" ? "Creator Dashboard" : navItems.find(n => n.id === tab)?.label}</h1>
            <p className="text-[10px] text-muted-foreground">UAE · Beauty & Lifestyle</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-violet-50 border border-violet-100">
              <Camera size={12} className="text-violet-600" />
              <span className="text-[11px] font-semibold text-violet-700">Creator</span>
            </div>
            <button className="w-7 h-7 rounded-xl bg-secondary border border-border flex items-center justify-center text-muted-foreground hover:text-foreground relative">
              <Bell size={13} /><span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-orange-500" />
            </button>
            <button className="w-7 h-7 rounded-xl bg-secondary border border-border flex items-center justify-center text-muted-foreground hover:text-foreground">
              <MessageSquare size={13} />
            </button>
          </div>
        </div>

        <div className="p-6">
          <AnimatePresence mode="wait">
            <motion.div key={tab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.18 }}>
              {tab === "home" && <CreatorHome />}
              {tab === "gigs" && <CreatorGigs />}
              {tab === "projects" && <CreatorProjectsView />}
              {tab === "portfolio" && <CreatorPortfolio />}
              {tab === "earnings" && <CreatorEarnings />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

function CreatorProjectsView() {
  const [selected, setSelected] = useState(creatorProjects[0]);
  const [activeTab, setActiveTab] = useState<"milestones" | "review" | "files">("milestones");
  const done = selected.milestones.filter(Boolean).length;
  const pct = Math.round((done / selected.milestones.length) * 100);

  const milestoneLabels = ["Brief accepted", "Product received", "Draft submitted", "Brand approval", "Final delivery"];

  return (
    <div className="flex gap-5">
      <aside className="w-56 shrink-0 space-y-2">
        <p className="text-xs font-bold text-foreground mb-1">My Projects</p>
        {creatorProjects.map(p => {
          const s = statusStyle[p.status];
          return (
            <motion.button key={p.id} whileTap={{ scale: 0.98 }} onClick={() => setSelected(p)}
              className={`w-full text-left p-3 rounded-xl border transition-all ${selected.id === p.id ? "border-violet-400 bg-violet-50 shadow-sm" : "border-border bg-white hover:border-violet-200"}`}>
              <div className="flex items-center gap-2 mb-1.5">
                <img src={p.logo} alt={p.brand} className="w-6 h-6 rounded-lg object-cover" />
                <span className="text-xs font-semibold text-foreground truncate">{p.brand}</span>
              </div>
              <p className="text-[10px] text-muted-foreground line-clamp-1 mb-1.5">{p.title}</p>
              <span className={`text-[9px] font-semibold px-1.5 py-0.5 rounded-full border ${s.cls}`}>{s.label}</span>
            </motion.button>
          );
        })}
      </aside>

      <div className="flex-1 min-w-0 space-y-4">
        <div className="bg-white border border-border rounded-2xl p-4 shadow-sm">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-center gap-3">
              <img src={selected.logo} alt={selected.brand} className="w-10 h-10 rounded-xl object-cover" />
              <div>
                <h2 className="text-sm font-bold text-foreground">{selected.title}</h2>
                <p className="text-xs text-muted-foreground">With {selected.brand} · Due {selected.due}</p>
              </div>
            </div>
            <div className={`flex items-center gap-2 px-3 py-2 rounded-xl border ${selected.escrowHeld ? "bg-yellow-50 border-yellow-200" : "bg-emerald-50 border-emerald-200"}`}>
              <Shield size={13} className={selected.escrowHeld ? "text-yellow-600" : "text-emerald-600"} />
              <div>
                <p className="text-[9px] text-muted-foreground">Escrow</p>
                <p className={`text-xs font-bold ${selected.escrowHeld ? "text-yellow-700" : "text-emerald-700"}`}>${selected.payment}</p>
              </div>
            </div>
          </div>
          <div>
            <div className="flex justify-between text-[10px] mb-1"><span className="text-muted-foreground">Progress</span><span className="text-violet-700 font-semibold">{done}/{selected.milestones.length} steps</span></div>
            <div className="h-2 rounded-full bg-violet-100 overflow-hidden">
              <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.7 }} className="h-full rounded-full bg-gradient-to-r from-violet-500 to-purple-600" />
            </div>
          </div>
        </div>

        <div className="flex gap-1 bg-secondary p-1 rounded-xl border border-border w-fit">
          {(["milestones", "review", "files"] as const).map(t => (
            <button key={t} onClick={() => setActiveTab(t)} className={`px-4 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all ${activeTab === t ? "bg-white text-foreground shadow-sm border border-border" : "text-muted-foreground hover:text-foreground"}`}>
              {t === "review" ? "Draft Review" : t.charAt(0).toUpperCase() + t.slice(1)}
            </button>
          ))}
        </div>

        {activeTab === "milestones" && (
          <div className="bg-white border border-border rounded-2xl p-4 shadow-sm space-y-3">
            {selected.milestones.map((done, i) => (
              <motion.div key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.06 }}
                className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 shrink-0 ${done ? "border-violet-500 bg-violet-600" : "border-violet-200 bg-white"}`}>
                  {done ? <Check size={13} className="text-white" strokeWidth={2.5} /> : <div className="w-2 h-2 rounded-full bg-violet-200" />}
                </div>
                <div className={`flex-1 flex items-center justify-between py-2 px-3 rounded-xl border ${done ? "bg-violet-50 border-violet-100" : "bg-white border-border"}`}>
                  <span className={`text-sm ${done ? "text-muted-foreground line-through" : "text-foreground font-medium"}`}>{milestoneLabels[i]}</span>
                  {done ? <CheckCircle size={13} className="text-emerald-500" /> : <Clock size={13} className="text-muted-foreground" />}
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {activeTab === "review" && (
          <div className="bg-white border border-border rounded-2xl p-4 shadow-sm">
            <div className="flex items-center justify-between mb-4"><h3 className="text-sm font-bold text-foreground">Your Drafts</h3></div>
            {[{ v: "Draft v2", ts: "Jul 14, 10:05 AM", comments: 1 }, { v: "Draft v1", ts: "Jul 12, 2:14 PM", comments: 4 }].map((d, i) => (
              <div key={i} className="p-3 rounded-xl border border-border mb-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2"><Video size={13} className="text-violet-500" /><span className="text-sm font-semibold text-foreground">{d.v}</span></div>
                  <span className="text-[10px] text-muted-foreground">{d.ts}</span>
                </div>
                <div className="relative h-24 rounded-xl bg-violet-50 border border-violet-100 flex items-center justify-center mb-2 cursor-pointer">
                  <motion.div whileHover={{ scale: 1.1 }} className="w-9 h-9 rounded-full bg-violet-100 flex items-center justify-center">
                    <Play size={14} className="text-violet-600 fill-violet-600 ml-0.5" />
                  </motion.div>
                  <div className="absolute bottom-2 left-3 right-3 h-1 rounded-full bg-violet-100 overflow-hidden"><div className="h-full w-[40%] rounded-full bg-violet-400" /></div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-muted-foreground flex items-center gap-0.5"><MessageSquare size={9} />{d.comments} comments</span>
                  <motion.button whileTap={{ scale: 0.95 }} className="flex items-center gap-1 text-[10px] font-semibold text-violet-600 bg-violet-50 border border-violet-200 px-2 py-1 rounded-lg hover:bg-violet-100 transition-colors">
                    <Upload size={9} />Upload Revision
                  </motion.button>
                </div>
              </div>
            ))}
            <button className="w-full py-2.5 rounded-xl border-2 border-dashed border-violet-200 text-xs text-violet-500 hover:border-violet-400 hover:bg-violet-50 transition-colors flex items-center justify-center gap-1.5">
              <Upload size={12} />Upload new draft
            </button>
          </div>
        )}

        {activeTab === "files" && (
          <div className="bg-white border border-border rounded-2xl p-4 shadow-sm">
            {[
              { name: "brief_novaskin_spf.pdf", size: "248 KB", icon: <FileText size={13} className="text-blue-500" /> },
              { name: "draft_v2_tiktok.mp4", size: "91 MB", icon: <Video size={13} className="text-violet-500" /> },
              { name: "raw_footage.zip", size: "412 MB", icon: <Package size={13} className="text-orange-500" /> },
            ].map((f, i) => (
              <div key={i} className="flex items-center gap-3 py-2.5 border-b border-border last:border-0">
                <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center shrink-0">{f.icon}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground truncate">{f.name}</p>
                  <p className="text-[10px] text-muted-foreground">{f.size}</p>
                </div>
                <button className="text-[10px] text-violet-600 font-semibold px-2 py-1 rounded-lg border border-violet-200 hover:bg-violet-50 transition-colors">Download</button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// BRAND DASHBOARD
// ══════════════════════════════════════════════════════════════════════════════

type BrandTab = "home" | "discover" | "campaigns" | "analytics" | "billing";

const campaigns = [
  {
    id: 1, title: "SPF Launch — TikTok UGC", status: "active" as const,
    budget: 2400, spent: 960, creators: 3, pending: 1, approved: 1,
    logo: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=40&h=40&fit=crop&auto=format",
    deadline: "Jul 28",
  },
  {
    id: 2, title: "60-Day Fitness Series", status: "active" as const,
    budget: 1800, spent: 600, creators: 2, pending: 0, approved: 2,
    logo: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=40&h=40&fit=crop&auto=format",
    deadline: "Aug 30",
  },
  {
    id: 3, title: "Spring Home Styling", status: "completed" as const,
    budget: 920, spent: 920, creators: 2, pending: 0, approved: 4,
    logo: "https://images.unsplash.com/photo-1490750967868-88df5691cc81?w=40&h=40&fit=crop&auto=format",
    deadline: "Jul 20",
  },
];

const pendingApprovals = [
  { creator: "Sofia Reyes", avatar: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=40&h=40&fit=crop&auto=format", campaign: "SPF Launch", draft: "Draft v2", submitted: "Jul 14" },
  { creator: "Khalid Al-Rashid", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&auto=format", campaign: "SPF Launch", draft: "Draft v1", submitted: "Jul 12" },
];

function BrandHome() {
  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "Total Spent", val: "$5,120", change: "+$1,560 this month", icon: <DollarSign size={16} className="text-orange-500" />, bg: "bg-orange-50 border-orange-100", valColor: "text-orange-700" },
          { label: "Active Campaigns", val: "2", change: "1 needs approval", icon: <Target size={16} className="text-violet-600" />, bg: "bg-violet-50 border-violet-100", valColor: "text-violet-700" },
          { label: "Creators Hired", val: "7", change: "across 3 campaigns", icon: <Users size={16} className="text-blue-500" />, bg: "bg-blue-50 border-blue-100", valColor: "text-blue-700" },
          { label: "Avg ROAS", val: "4.2×", change: "+0.8 vs last quarter", icon: <BarChart2 size={16} className="text-emerald-500" />, bg: "bg-emerald-50 border-emerald-100", valColor: "text-emerald-700" },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
            className={`bg-white border rounded-2xl p-4 shadow-sm ${s.bg}`}>
            <div className="flex items-center justify-between mb-2">{s.icon}<span className="text-[10px] text-emerald-600 font-semibold">{s.change}</span></div>
            <p className={`text-2xl font-extrabold mb-0.5 ${s.valColor}`}>{s.val}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Campaigns */}
        <div className="lg:col-span-2 bg-white border border-border rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-foreground">Active Campaigns</h3>
            <button className="text-xs text-orange-600 font-semibold hover:text-orange-800">+ New Campaign</button>
          </div>
          <div className="space-y-3">
            {campaigns.map((c, i) => {
              const pct = Math.round((c.spent / c.budget) * 100);
              return (
                <motion.div key={c.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.08 }}
                  className="p-3 rounded-xl border border-border hover:border-orange-200 hover:bg-orange-50/20 transition-all">
                  <div className="flex items-center gap-3 mb-2">
                    <img src={c.logo} alt="" className="w-8 h-8 rounded-xl object-cover border border-border shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-xs font-bold text-foreground truncate">{c.title}</p>
                        <span className={`shrink-0 text-[9px] font-semibold px-1.5 py-0.5 rounded-full border ${c.status === "active" ? "bg-emerald-100 text-emerald-700 border-emerald-200" : "bg-secondary text-muted-foreground border-border"}`}>{c.status}</span>
                      </div>
                      <div className="flex items-center gap-3 text-[9px] text-muted-foreground mt-0.5">
                        <span>{c.creators} creators</span>
                        <span>{c.approved} approved</span>
                        {c.pending > 0 && <span className="text-orange-600 font-semibold">{c.pending} awaiting review</span>}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-xs font-bold text-foreground">${c.spent}<span className="text-[9px] text-muted-foreground font-normal">/${c.budget}</span></p>
                      <p className="text-[9px] text-muted-foreground">Due {c.deadline}</p>
                    </div>
                  </div>
                  <div className="h-1.5 rounded-full bg-orange-100 overflow-hidden">
                    <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.7, delay: i * 0.1 }}
                      className="h-full rounded-full bg-gradient-to-r from-orange-400 to-orange-600" />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Pending approvals */}
        <div className="space-y-3">
          <div className="bg-white border border-orange-200 rounded-2xl p-4 shadow-sm">
            <div className="flex items-center gap-1.5 mb-3">
              <AlertCircle size={14} className="text-orange-500" />
              <p className="text-xs font-bold text-foreground">Pending Approvals</p>
              <span className="ml-auto w-5 h-5 rounded-full bg-orange-500 text-[9px] font-bold text-white flex items-center justify-center">{pendingApprovals.length}</span>
            </div>
            {pendingApprovals.map((a, i) => (
              <div key={i} className="p-2.5 rounded-xl bg-orange-50 border border-orange-100 mb-2 last:mb-0">
                <div className="flex items-center gap-2 mb-2">
                  <img src={a.avatar} alt={a.creator} className="w-7 h-7 rounded-full object-cover" />
                  <div className="min-w-0">
                    <p className="text-[11px] font-bold text-foreground">{a.creator}</p>
                    <p className="text-[9px] text-muted-foreground">{a.draft} · {a.submitted}</p>
                  </div>
                </div>
                <div className="flex gap-1.5">
                  <button className="flex-1 py-1 text-[10px] font-semibold text-orange-700 bg-white border border-orange-200 rounded-lg hover:bg-orange-50 transition-colors">Revise</button>
                  <button className="flex-1 py-1 text-[10px] font-semibold text-white bg-emerald-600 border border-emerald-600 rounded-lg hover:bg-emerald-700 transition-colors">Approve</button>
                </div>
              </div>
            ))}
          </div>
          <div className="bg-gradient-to-br from-orange-500 to-amber-600 rounded-2xl p-4 text-white shadow-lg shadow-orange-200">
            <Sparkles size={15} className="text-white/80 mb-2" />
            <p className="text-xs font-bold mb-1">Post a New Brief</p>
            <p className="text-[10px] text-white/70 mb-3">Let Gulf creators apply to your campaign</p>
            <button className="w-full py-1.5 text-xs font-semibold rounded-xl bg-white/20 hover:bg-white/30 transition-colors">Post Brief →</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function BrandDiscover() {
  const [selectedCreator, setSelectedCreator] = useState<Creator | null>(null);
  const [activeNiche, setActiveNiche] = useState("All");
  const niches = ["All", "Beauty", "Tech", "Fashion", "Fitness", "Food", "Home"];
  const filtered = creators.filter(c => activeNiche === "All" || c.niche.includes(activeNiche));

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-foreground">Find Gulf Creators</h2>
          <p className="text-xs text-muted-foreground">Browse and hire verified UGC talent across the Gulf region</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white border border-border">
            <Search size={12} className="text-muted-foreground" />
            <input className="bg-transparent text-xs outline-none text-foreground placeholder:text-muted-foreground w-36" placeholder="Search creators..." />
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white border border-border cursor-pointer hover:border-orange-300 transition-colors">
            <Filter size={11} className="text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Filter</span>
            <ChevronDown size={11} className="text-muted-foreground" />
          </div>
        </div>
      </div>

      <div className="flex gap-1.5 flex-wrap">
        {niches.map(n => (
          <motion.button key={n} whileTap={{ scale: 0.93 }} onClick={() => setActiveNiche(n)}
            className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${activeNiche === n ? "bg-orange-500 text-white shadow-sm shadow-orange-200" : "bg-white border border-border text-muted-foreground hover:border-orange-300"}`}>
            {n}
          </motion.button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3.5">
        {filtered.map((c, i) => (
          <motion.div key={c.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
            whileHover={{ y: -4 }}
            className="bg-white border border-border rounded-2xl overflow-hidden group shadow-sm hover:shadow-xl hover:shadow-orange-50 hover:border-orange-200 transition-all duration-300">
            <div className="relative overflow-hidden h-40 bg-secondary">
              <img src={c.thumbnail} alt={c.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              <div className="absolute bottom-2.5 left-3 flex gap-1">
                {c.niche.map(n => <span key={n} className="text-[9px] font-semibold px-2 py-0.5 rounded-full bg-black/50 text-white">{n}</span>)}
              </div>
              <div className="absolute top-2.5 right-2.5">
                {c.verified && <div className="w-6 h-6 rounded-full bg-orange-500 flex items-center justify-center shadow"><Check size={10} className="text-white" strokeWidth={3} /></div>}
              </div>
            </div>
            <div className="p-3.5">
              <div className="flex items-center gap-2 mb-2">
                <img src={c.avatar} alt={c.name} className="w-8 h-8 rounded-full object-cover border-2 border-orange-200" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-foreground">{c.name}</p>
                  <p className="text-[10px] text-muted-foreground">{c.country} {c.location} · {c.followers}</p>
                </div>
                <div className="text-right">
                  <p className="text-[9px] text-muted-foreground">from</p>
                  <p className="text-sm font-bold text-orange-600">${c.packages[0].price}</p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-1.5 mb-3 p-2 rounded-xl bg-orange-50 border border-orange-100">
                {[
                  { val: c.stats.engagement, label: "engage", color: "text-orange-600" },
                  { val: c.stats.views, label: "views", color: "text-violet-600" },
                  { val: c.stats.delivery, label: "delivery", color: "text-emerald-600" },
                ].map((s, j) => (
                  <div key={j} className={`text-center ${j > 0 ? "border-l border-orange-100" : ""}`}>
                    <p className={`text-[11px] font-bold ${s.color}`}>{s.val}</p>
                    <p className="text-[9px] text-muted-foreground">{s.label}</p>
                  </div>
                ))}
              </div>
              <div className="flex gap-1.5">
                <motion.button whileTap={{ scale: 0.96 }} onClick={() => setSelectedCreator(c)} className="flex-1 py-1.5 text-[11px] font-semibold rounded-xl border border-border text-muted-foreground hover:border-orange-300 hover:text-orange-700 hover:bg-orange-50 transition-colors">View Profile</motion.button>
                <motion.button whileTap={{ scale: 0.96 }} className="flex-1 py-1.5 text-[11px] font-semibold rounded-xl bg-orange-500 hover:bg-orange-600 text-white transition-colors shadow-sm shadow-orange-200">Hire Now</motion.button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>{selectedCreator && <ProfileModal creator={selectedCreator} onClose={() => setSelectedCreator(null)} />}</AnimatePresence>
    </div>
  );
}

function BrandAnalytics() {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"];
  const spend = [1200, 1800, 1400, 2100, 1900, 2600, 960];
  const roas = [3.1, 3.8, 3.4, 4.5, 4.0, 5.2, 4.2];
  const maxSpend = Math.max(...spend);

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-base font-bold text-foreground">Campaign Analytics</h2>
        <p className="text-xs text-muted-foreground">Performance across all your UGC campaigns</p>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "Total UGC Spend", val: "$12,060", color: "text-orange-700", bg: "bg-orange-50 border-orange-100" },
          { label: "Avg ROAS", val: "4.2×", color: "text-emerald-700", bg: "bg-emerald-50 border-emerald-100" },
          { label: "Videos Produced", val: "34", color: "text-violet-700", bg: "bg-violet-50 border-violet-100" },
          { label: "Total Reach", val: "18.4M", color: "text-blue-700", bg: "bg-blue-50 border-blue-100" },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
            className={`bg-white border rounded-2xl p-4 shadow-sm ${s.bg}`}>
            <p className={`text-2xl font-extrabold mb-0.5 ${s.color}`}>{s.val}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white border border-border rounded-2xl p-4 shadow-sm">
          <p className="text-xs font-bold text-foreground mb-4">Monthly UGC Spend (USD)</p>
          <div className="flex items-end gap-2 h-28">
            {months.map((m, i) => (
              <div key={m} className="flex-1 flex flex-col items-center gap-1">
                <motion.div initial={{ height: 0 }} animate={{ height: `${(spend[i] / maxSpend) * 100}%` }} transition={{ delay: i * 0.06, duration: 0.5 }}
                  className={`w-full rounded-t-lg ${i === months.length - 1 ? "bg-orange-200" : "bg-orange-500"}`} />
                <span className="text-[9px] text-muted-foreground">{m}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white border border-border rounded-2xl p-4 shadow-sm">
          <p className="text-xs font-bold text-foreground mb-3">Top Performing Creators</p>
          <div className="space-y-2.5">
            {[
              { name: "Layla Hassan", roas: "5.8×", spend: "$420", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=32&h=32&fit=crop&auto=format" },
              { name: "Sofia Reyes", roas: "4.9×", spend: "$480", avatar: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=32&h=32&fit=crop&auto=format" },
              { name: "Omar Nasser", roas: "3.7×", spend: "$200", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=32&h=32&fit=crop&auto=format" },
            ].map((c, i) => (
              <div key={i} className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-muted-foreground w-4">{i + 1}</span>
                <img src={c.avatar} alt={c.name} className="w-7 h-7 rounded-full object-cover" />
                <div className="flex-1 min-w-0"><p className="text-xs font-semibold text-foreground truncate">{c.name}</p></div>
                <span className="text-xs font-bold text-emerald-600">{c.roas}</span>
                <span className="text-[10px] text-muted-foreground">{c.spend}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white border border-border rounded-2xl p-4 shadow-sm">
        <p className="text-xs font-bold text-foreground mb-3">Campaign Performance</p>
        <div className="space-y-3">
          {campaigns.map((c, i) => {
            const pct = Math.round((c.spent / c.budget) * 100);
            return (
              <div key={i} className="flex items-center gap-3">
                <img src={c.logo} alt="" className="w-8 h-8 rounded-xl object-cover border border-border shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-semibold text-foreground truncate">{c.title}</span>
                    <span className="text-muted-foreground shrink-0">${c.spent}/${c.budget}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-orange-100 overflow-hidden">
                    <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ delay: i * 0.1, duration: 0.6 }}
                      className="h-full rounded-full bg-gradient-to-r from-orange-400 to-orange-600" />
                  </div>
                </div>
                <span className="text-xs font-bold text-orange-600 shrink-0">{pct}%</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function BrandDashboard({ onSignOut }: { onSignOut: () => void }) {
  const [tab, setTab] = useState<BrandTab>("home");

  const navItems: { id: BrandTab; label: string; icon: React.ReactNode }[] = [
    { id: "home", label: "Dashboard", icon: <Home size={16} /> },
    { id: "discover", label: "Find Creators", icon: <Search size={16} /> },
    { id: "campaigns", label: "Campaigns", icon: <Target size={16} /> },
    { id: "analytics", label: "Analytics", icon: <BarChart2 size={16} /> },
    { id: "billing", label: "Billing", icon: <Wallet size={16} /> },
  ];

  return (
    <div className="min-h-screen bg-background flex" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      {/* Sidebar — orange theme for brands */}
      <aside className="w-56 shrink-0 border-r border-border bg-white flex flex-col sticky top-0 h-screen">
        <div className="p-5 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center shadow-sm shadow-orange-200">
              <Zap size={14} className="text-white fill-white" />
            </div>
            <span className="font-extrabold text-foreground text-sm tracking-tight">UGC <span className="text-orange-500">GULF</span></span>
          </div>
        </div>

        {/* Brand profile */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-100 to-amber-100 border border-orange-200 flex items-center justify-center shrink-0">
              <Briefcase size={16} className="text-orange-600" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-foreground truncate">NovaSkin Co.</p>
              <p className="text-[10px] text-orange-600 font-semibold">Brand Account</p>
              <p className="text-[9px] text-muted-foreground mt-0.5">Dubai, UAE 🇦🇪</p>
            </div>
          </div>
          <div className="mt-3 p-2 rounded-xl bg-orange-50 border border-orange-100">
            <p className="text-[9px] text-muted-foreground">Campaign Budget Left</p>
            <p className="text-sm font-bold text-orange-700">$1,440 remaining</p>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-0.5">
          {navItems.map((item) => (
            <motion.button key={item.id} whileTap={{ scale: 0.97 }} onClick={() => setTab(item.id)}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm transition-all ${tab === item.id ? "bg-orange-500 text-white font-semibold shadow-sm shadow-orange-200" : "text-muted-foreground hover:bg-orange-50 hover:text-orange-700"}`}>
              {item.icon}<span>{item.label}</span>
              {item.id === "campaigns" && <span className="ml-auto w-4 h-4 rounded-full bg-red-500 text-[9px] font-bold text-white flex items-center justify-center">2</span>}
            </motion.button>
          ))}
        </nav>

        <div className="p-3 border-t border-border space-y-0.5">
          <button className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm text-muted-foreground hover:bg-secondary hover:text-foreground transition-all">
            <Settings size={15} />Settings
          </button>
          <button onClick={onSignOut} className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm text-rose-500 hover:bg-rose-50 transition-all">
            <LogOut size={15} />Sign out
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 min-w-0">
        <div className="sticky top-0 z-30 bg-white/80 backdrop-blur-xl border-b border-border px-6 h-13 flex items-center justify-between py-2.5 shadow-sm">
          <div>
            <h1 className="text-sm font-bold text-foreground">{tab === "home" ? "Brand Dashboard" : navItems.find(n => n.id === tab)?.label}</h1>
            <p className="text-[10px] text-muted-foreground">NovaSkin Co. · Beauty & Skincare</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-orange-50 border border-orange-100">
              <Briefcase size={12} className="text-orange-600" />
              <span className="text-[11px] font-semibold text-orange-700">Brand</span>
            </div>
            <motion.button whileTap={{ scale: 0.96 }} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-semibold transition-colors shadow-sm shadow-orange-200">
              <PlusCircle size={12} />New Brief
            </motion.button>
            <button className="w-7 h-7 rounded-xl bg-secondary border border-border flex items-center justify-center text-muted-foreground hover:text-foreground relative">
              <Bell size={13} /><span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-red-500" />
            </button>
          </div>
        </div>

        <div className="p-6">
          <AnimatePresence mode="wait">
            <motion.div key={tab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.18 }}>
              {tab === "home" && <BrandHome />}
              {tab === "discover" && <BrandDiscover />}
              {tab === "campaigns" && <BrandCampaigns />}
              {tab === "analytics" && <BrandAnalytics />}
              {tab === "billing" && <BrandBilling />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

function BrandCampaigns() {
  const [selectedCampaign, setSelectedCampaign] = useState(campaigns[0]);
  const milestoneLabels = ["Brief posted", "Creators confirmed", "Products shipped", "Drafts received", "Final approved"];
  const done = [true, true, true, true, false];

  return (
    <div className="flex gap-5">
      <aside className="w-60 shrink-0 space-y-2">
        <div className="flex items-center justify-between mb-1">
          <p className="text-xs font-bold text-foreground">Campaigns</p>
          <button className="text-[10px] text-orange-600 font-semibold hover:text-orange-800">+ New</button>
        </div>
        {campaigns.map(c => (
          <motion.button key={c.id} whileTap={{ scale: 0.98 }} onClick={() => setSelectedCampaign(c)}
            className={`w-full text-left p-3 rounded-xl border transition-all ${selectedCampaign.id === c.id ? "border-orange-400 bg-orange-50 shadow-sm" : "border-border bg-white hover:border-orange-200"}`}>
            <div className="flex items-center gap-2 mb-1.5">
              <img src={c.logo} alt="" className="w-6 h-6 rounded-lg object-cover" />
              <span className={`text-[9px] font-semibold px-1.5 py-0.5 rounded-full border ${c.status === "active" ? "bg-emerald-100 text-emerald-700 border-emerald-200" : "bg-secondary text-muted-foreground border-border"}`}>{c.status}</span>
            </div>
            <p className="text-xs font-semibold text-foreground line-clamp-1 mb-1">{c.title}</p>
            <p className="text-[9px] text-muted-foreground">{c.creators} creators · Due {c.deadline}</p>
          </motion.button>
        ))}
      </aside>

      <div className="flex-1 min-w-0 space-y-4">
        <div className="bg-white border border-border rounded-2xl p-4 shadow-sm">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-center gap-3">
              <img src={selectedCampaign.logo} alt="" className="w-10 h-10 rounded-xl object-cover" />
              <div>
                <h2 className="text-sm font-bold text-foreground">{selectedCampaign.title}</h2>
                <p className="text-xs text-muted-foreground">{selectedCampaign.creators} creators · Due {selectedCampaign.deadline}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-orange-50 border border-orange-200">
              <DollarSign size={13} className="text-orange-600" />
              <div>
                <p className="text-[9px] text-muted-foreground">Budget used</p>
                <p className="text-xs font-bold text-orange-700">${selectedCampaign.spent} / ${selectedCampaign.budget}</p>
              </div>
            </div>
          </div>
          <div className="h-2 rounded-full bg-orange-100 overflow-hidden">
            <motion.div initial={{ width: 0 }} animate={{ width: `${Math.round((selectedCampaign.spent / selectedCampaign.budget) * 100)}%` }} transition={{ duration: 0.7 }}
              className="h-full rounded-full bg-gradient-to-r from-orange-400 to-orange-600" />
          </div>
        </div>

        {/* Pending approvals */}
        {pendingApprovals.length > 0 && (
          <div className="bg-white border border-orange-200 rounded-2xl p-4 shadow-sm">
            <div className="flex items-center gap-1.5 mb-3"><AlertCircle size={14} className="text-orange-500" /><p className="text-xs font-bold text-foreground">Drafts Awaiting Your Review</p></div>
            {pendingApprovals.map((a, i) => (
              <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-orange-50 border border-orange-100 mb-2">
                <img src={a.avatar} alt={a.creator} className="w-9 h-9 rounded-full object-cover" />
                <div className="flex-1">
                  <p className="text-xs font-bold text-foreground">{a.creator}</p>
                  <p className="text-[10px] text-muted-foreground">{a.draft} · Submitted {a.submitted}</p>
                </div>
                <div className="flex gap-1.5">
                  <button className="px-2.5 py-1 text-[10px] font-semibold text-orange-700 bg-white border border-orange-200 rounded-lg hover:bg-orange-50 flex items-center gap-1 transition-colors">
                    <Play size={9} />Preview
                  </button>
                  <button className="px-2.5 py-1 text-[10px] font-semibold text-orange-700 bg-white border border-orange-200 rounded-lg hover:bg-orange-50 transition-colors">Revise</button>
                  <button className="px-2.5 py-1 text-[10px] font-semibold text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 flex items-center gap-1 transition-colors">
                    <ThumbsUp size={9} />Approve
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Campaign milestones */}
        <div className="bg-white border border-border rounded-2xl p-4 shadow-sm">
          <p className="text-xs font-bold text-foreground mb-4">Campaign Milestones</p>
          <div className="space-y-3">
            {milestoneLabels.map((label, i) => (
              <motion.div key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.06 }}
                className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 shrink-0 ${done[i] ? "border-orange-400 bg-orange-500" : "border-orange-200 bg-white"}`}>
                  {done[i] ? <Check size={13} className="text-white" strokeWidth={2.5} /> : <div className="w-2 h-2 rounded-full bg-orange-200" />}
                </div>
                <div className={`flex-1 flex items-center justify-between py-2 px-3 rounded-xl border ${done[i] ? "bg-orange-50 border-orange-100" : "bg-white border-border"}`}>
                  <span className={`text-sm ${done[i] ? "text-muted-foreground line-through" : "text-foreground font-medium"}`}>{label}</span>
                  {done[i] ? <CheckCircle size={13} className="text-emerald-500" /> : <Clock size={13} className="text-muted-foreground" />}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function BrandBilling() {
  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-base font-bold text-foreground">Billing & Payments</h2>
        <p className="text-xs text-muted-foreground">Manage escrow, invoices, and payment methods</p>
      </div>
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Total Spent", val: "$12,060", color: "text-orange-700", bg: "bg-orange-50 border-orange-100" },
          { label: "In Escrow (Held)", val: "$1,560", color: "text-yellow-700", bg: "bg-yellow-50 border-yellow-100" },
          { label: "Pending Release", val: "$780", color: "text-violet-700", bg: "bg-violet-50 border-violet-100" },
        ].map((s) => (
          <div key={s.label} className={`bg-white border rounded-2xl p-4 shadow-sm ${s.bg}`}>
            <p className={`text-2xl font-extrabold mb-0.5 ${s.color}`}>{s.val}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>
      <div className="bg-white border border-border rounded-2xl p-4 shadow-sm">
        <p className="text-xs font-bold text-foreground mb-3">Escrow Payments</p>
        {[
          { creator: "Sofia Reyes", campaign: "SPF Launch", amount: 480, status: "held" },
          { creator: "Khalid Al-Rashid", campaign: "SPF Launch", amount: 480, status: "held" },
          { creator: "Omar Nasser", campaign: "Fitness Series", amount: 300, status: "held" },
          { creator: "Layla Hassan", campaign: "Spring Styling", amount: 460, status: "released" },
        ].map((p, i) => (
          <div key={i} className="flex items-center justify-between py-2.5 border-b border-border last:border-0">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${p.status === "released" ? "bg-emerald-500" : "bg-yellow-400"}`} />
              <div>
                <p className="text-xs font-semibold text-foreground">{p.creator}</p>
                <p className="text-[9px] text-muted-foreground">{p.campaign}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <p className="text-sm font-bold text-foreground">${p.amount}</p>
              <span className={`text-[9px] font-semibold px-1.5 py-0.5 rounded-full border capitalize ${p.status === "released" ? "bg-emerald-100 text-emerald-700 border-emerald-200" : "bg-yellow-100 text-yellow-700 border-yellow-200"}`}>{p.status}</span>
              {p.status === "held" && <button className="text-[10px] text-orange-600 font-semibold hover:text-orange-800 px-2 py-1 rounded-lg border border-orange-200 hover:bg-orange-50 transition-colors">Release</button>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Animated word cycler ─────────────────────────────────────────────────────

const cyclingWords = ["Creators", "Agencies", "Brands", "Studios", "Talents"];

function WordCycler() {
  const [index, setIndex] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setIndex((i) => (i + 1) % cyclingWords.length), 2000);
    return () => clearInterval(t);
  }, []);
  return (
    <span className="relative inline-block overflow-hidden" style={{ minWidth: "220px" }}>
      <AnimatePresence mode="wait">
        <motion.span key={index} initial={{ y: 36, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -36, opacity: 0 }}
          transition={{ duration: 0.35, ease: [0.25, 0.1, 0.25, 1] }}
          className="inline-block text-violet-600 bg-violet-100 px-3 rounded-xl">
          {cyclingWords[index]}
        </motion.span>
      </AnimatePresence>
    </span>
  );
}

// ─── Floating creator cards ───────────────────────────────────────────────────

const floatingCards = [
  { name: "Layla Hassan", stat: "11.3% engagement", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=40&h=40&fit=crop&auto=format", niche: "Fashion · Cairo 🇪🇬" },
  { name: "Omar Nasser", stat: "2.4M avg views", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&auto=format", niche: "Fitness · Abu Dhabi 🇦🇪" },
  { name: "Sofia Reyes", stat: "4.98 ★ rating", avatar: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=40&h=40&fit=crop&auto=format", niche: "Beauty · Dubai 🇦🇪" },
  { name: "Khalid Al-Rashid", stat: "89.2K followers", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&auto=format", niche: "Tech · Riyadh 🇸🇦" },
];

function FloatingCard({ card, delay, x, y }: { card: typeof floatingCards[0]; delay: number; x: number; y: number }) {
  return (
    <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1, y: [0, -10, 0] }}
      transition={{ opacity: { delay, duration: 0.5 }, scale: { delay, duration: 0.5 }, y: { delay: delay + 0.5, duration: 3.5, repeat: Infinity, ease: "easeInOut" } }}
      style={{ left: x, top: y }}
      className="absolute bg-white/90 backdrop-blur-sm border border-violet-100 rounded-2xl p-2.5 shadow-xl flex items-center gap-2.5 w-48">
      <img src={card.avatar} alt={card.name} className="w-8 h-8 rounded-full object-cover border border-violet-200 shrink-0" />
      <div className="min-w-0">
        <p className="text-xs font-bold text-foreground truncate">{card.name}</p>
        <p className="text-[9px] text-violet-600 font-semibold">{card.stat}</p>
        <p className="text-[9px] text-muted-foreground truncate">{card.niche}</p>
      </div>
    </motion.div>
  );
}

// ─── Landing ──────────────────────────────────────────────────────────────────

function LandingView({ onSelect }: { onSelect: (role: Role) => void }) {
  const [hovered, setHovered] = useState<Role>(null);

  return (
    <div className="min-h-screen bg-background overflow-x-hidden" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      <motion.nav initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.5 }}
        className="sticky top-0 z-40 bg-white/80 backdrop-blur-xl border-b border-border shadow-sm">
        <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-violet-600 to-purple-700 flex items-center justify-center shadow-sm shadow-violet-200">
              <Zap size={15} className="text-white fill-white" />
            </div>
            <span className="font-extrabold text-foreground text-base tracking-tight">UGC <span className="text-violet-600">GULF</span></span>
          </div>
          <div className="hidden md:flex items-center gap-6 text-sm text-muted-foreground">
            <button className="hover:text-foreground transition-colors">Solutions</button>
            <button className="hover:text-foreground transition-colors">Pricing</button>
            <button className="hover:text-foreground transition-colors">For Creators</button>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => onSelect("creator")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">Log In</button>
            <motion.button whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }} onClick={() => onSelect("company")} className="px-4 py-2 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-sm font-semibold shadow-md shadow-violet-200 transition-colors">
              Get a Demo
            </motion.button>
          </div>
        </div>
      </motion.nav>

      <section className="relative max-w-6xl mx-auto px-6 pt-20 pb-10 text-center overflow-visible">
        <div className="hidden lg:block">
          <FloatingCard card={floatingCards[0]} delay={0.8} x={-60} y={30} />
          <FloatingCard card={floatingCards[1]} delay={1.0} x={-40} y={200} />
          <FloatingCard card={floatingCards[2]} delay={0.9} x={720} y={50} />
          <FloatingCard card={floatingCards[3]} delay={1.1} x={700} y={210} />
        </div>

        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-violet-100 border border-violet-200 text-violet-700 text-xs font-semibold mb-5">
            <TrendingUp size={11} />The Gulf's #1 UGC Creator Marketplace
          </span>
        </motion.div>

        <motion.h1 initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.6 }}
          className="text-4xl md:text-6xl font-extrabold text-foreground leading-[1.1] mb-4 tracking-tight">
          Hire Gulf <WordCycler />,<br />Influence Your Brand.
        </motion.h1>

        <motion.p initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }}
          className="text-base text-muted-foreground max-w-lg mx-auto mb-9 leading-relaxed">
          Find UGC creators across UAE, KSA, Egypt, and the Gulf — manage campaigns, review drafts, and pay securely in one place.
        </motion.p>

        {/* Dual CTA — with distinct visual identities */}
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto mb-14">
          {/* Creator CTA */}
          <motion.button onMouseEnter={() => setHovered("creator")} onMouseLeave={() => setHovered(null)} onClick={() => onSelect("creator")}
            whileHover={{ y: -4, scale: 1.01 }} whileTap={{ scale: 0.98 }}
            className={`relative p-6 rounded-3xl border text-left overflow-hidden transition-all duration-300 ${hovered === "creator" ? "border-violet-400 shadow-xl shadow-violet-100" : "border-border shadow-sm hover:shadow-lg"} bg-white`}>
            <motion.div animate={{ scale: hovered === "creator" ? 1.4 : 1 }} transition={{ duration: 0.4 }}
              className="absolute top-0 right-0 w-36 h-36 rounded-full bg-violet-100/70 translate-x-12 -translate-y-12" />
            <div className="flex items-start justify-between mb-4 relative">
              <div className="w-11 h-11 rounded-2xl bg-violet-100 flex items-center justify-center border border-violet-200">
                <Camera size={20} className="text-violet-600" />
              </div>
              <motion.div animate={{ x: hovered === "creator" ? 4 : 0 }}>
                <ArrowRight size={16} className={hovered === "creator" ? "text-violet-600" : "text-muted-foreground"} />
              </motion.div>
            </div>
            <h2 className="text-lg font-bold text-foreground mb-1.5 relative">I&apos;m a Creator</h2>
            <p className="text-xs text-muted-foreground leading-relaxed mb-4 relative">Showcase your work, find brand deals, submit drafts, and get paid via escrow.</p>
            <div className="flex flex-wrap gap-1.5 relative">
              {["Portfolio builder", "Find gigs", "Track earnings"].map(t => (
                <span key={t} className="flex items-center gap-1 text-[10px] text-foreground/70 bg-violet-50 px-2 py-0.5 rounded-full border border-violet-100">
                  <Check size={9} className="text-violet-500" />{t}
                </span>
              ))}
            </div>
          </motion.button>

          {/* Brand CTA */}
          <motion.button onMouseEnter={() => setHovered("company")} onMouseLeave={() => setHovered(null)} onClick={() => onSelect("company")}
            whileHover={{ y: -4, scale: 1.01 }} whileTap={{ scale: 0.98 }}
            className={`relative p-6 rounded-3xl border text-left overflow-hidden transition-all duration-300 ${hovered === "company" ? "border-orange-400 shadow-xl shadow-orange-100" : "border-border shadow-sm hover:shadow-lg"} bg-white`}>
            <motion.div animate={{ scale: hovered === "company" ? 1.4 : 1 }} transition={{ duration: 0.4 }}
              className="absolute top-0 right-0 w-36 h-36 rounded-full bg-orange-100/70 translate-x-12 -translate-y-12" />
            <div className="flex items-start justify-between mb-4 relative">
              <div className="w-11 h-11 rounded-2xl bg-orange-100 flex items-center justify-center border border-orange-200">
                <Briefcase size={20} className="text-orange-600" />
              </div>
              <motion.div animate={{ x: hovered === "company" ? 4 : 0 }}>
                <ArrowRight size={16} className={hovered === "company" ? "text-orange-600" : "text-muted-foreground"} />
              </motion.div>
            </div>
            <h2 className="text-lg font-bold text-foreground mb-1.5 relative">I&apos;m a Brand / Agency</h2>
            <p className="text-xs text-muted-foreground leading-relaxed mb-4 relative">Browse creators, post briefs, manage campaigns, and approve content with escrow protection.</p>
            <div className="flex flex-wrap gap-1.5 relative">
              {["Browse creators", "Post briefs", "Campaign analytics"].map(t => (
                <span key={t} className="flex items-center gap-1 text-[10px] text-foreground/70 bg-orange-50 px-2 py-0.5 rounded-full border border-orange-100">
                  <Check size={9} className="text-orange-500" />{t}
                </span>
              ))}
            </div>
          </motion.button>
        </motion.div>
      </section>

      {/* Creator photo strip */}
      <section className="pb-16">
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9 }}
          className="text-center text-sm text-muted-foreground mb-6">
          Join <strong className="text-foreground">12,400+</strong> verified Gulf UGC creators
        </motion.p>
        <div className="relative overflow-hidden">
          <motion.div animate={{ x: [0, -1200] }} transition={{ duration: 28, repeat: Infinity, ease: "linear" }} className="flex gap-3 w-max px-6">
            {[...heroPhotos, ...heroPhotos, ...heroPhotos].map((src, i) => (
              <div key={i} className="relative w-[140px] h-[190px] rounded-2xl overflow-hidden shadow-md border border-violet-50 shrink-0">
                <img src={src} alt="Creator" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
              </div>
            ))}
          </motion.div>
          <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-background to-transparent pointer-events-none z-10" />
          <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-background to-transparent pointer-events-none z-10" />
        </div>
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.0 }}
          className="flex items-center justify-center gap-8 mt-10 flex-wrap">
          {[
            { icon: <Users size={14} className="text-violet-500" />, val: "12,400+", label: "creators" },
            { icon: <Briefcase size={14} className="text-orange-500" />, val: "3,200+", label: "brands" },
            { icon: <Star size={14} className="fill-amber-500 text-amber-500" />, val: "4.9/5", label: "avg rating" },
            { icon: <Shield size={14} className="text-emerald-500" />, val: "100%", label: "escrow protected" },
            { icon: <Globe size={14} className="text-blue-500" />, val: "12", label: "Gulf countries" },
          ].map((s) => (
            <div key={s.label} className="flex items-center gap-2 text-sm text-muted-foreground">
              {s.icon}<span><strong className="text-foreground">{s.val}</strong> {s.label}</span>
            </div>
          ))}
        </motion.div>
      </section>
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [view, setView] = useState<"landing" | "feed">("landing");
  const [role, setRole] = useState<Role>(null);

  const handleSelect = (r: Role) => { setRole(r); setView("feed"); };
  const handleSignOut = () => { setView("landing"); setRole(null); };

  if (view === "feed" && role === "creator") return <CreatorDashboard onSignOut={handleSignOut} />;
  if (view === "feed" && role === "company") return <BrandDashboard onSignOut={handleSignOut} />;
  return <LandingView onSelect={handleSelect} />;
}
